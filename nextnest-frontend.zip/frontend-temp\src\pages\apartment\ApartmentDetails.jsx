import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import useAuth from "../../hooks/useAuth";

import MainLayout from "../../layouts/MainLayout";
import apartmentService from "../../services/apartmentService";
import inquiryService from "../../services/inquiryService";

function ApartmentDetails() {

    const { id } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();

    const [loading, setLoading] = useState(true);
    const [apartment, setApartment] = useState(null);
    const [selectedImage, setSelectedImage] = useState("");
    const [showInquiry, setShowInquiry] = useState(false);
    const [message, setMessage] = useState("");

    useEffect(() => {
        loadApartment();
    }, [id]);

    // --------------------------------
    // Load Apartment
    // --------------------------------

    const loadApartment = async () => {

        try {

            const response =
                await apartmentService.getApartmentById(id);

            const data = response.data;

            setApartment(data);

            if (data.coverImage) {

                setSelectedImage(
                    data.coverImage.startsWith("http")
                        ? data.coverImage
                        : `http://localhost:8080/uploads/${data.coverImage}`
                );

            } else if (
                data.images &&
                data.images.length > 0
            ) {

                setSelectedImage(data.images[0]);

            }

        } catch (error) {

            console.error(
                "Failed to load apartment:",
                error
            );

        } finally {

            setLoading(false);

        }
    };

    // --------------------------------
    // Owner Check
    // --------------------------------

    const isOwner =
        user &&
        Number(user.userId) ===
        Number(apartment?.ownerId);

    // --------------------------------
    // Inquiry
    // --------------------------------

    const handleInquiryClick = () => {

        if (!user) {

            alert(
                "Please login first to contact the apartment owner."
            );

            navigate("/login");

            return;
        }

        if (isOwner) {

            alert(
                "You cannot send an inquiry for your own apartment."
            );

            return;
        }

        setShowInquiry(true);
    };

    const handleInquirySubmit = async (e) => {

        e.preventDefault();

        if (!user) {

            alert(
                "Please login first to send an inquiry."
            );

            navigate("/login");

            return;
        }

        if (isOwner) {

            alert(
                "You cannot send an inquiry for your own apartment."
            );

            setShowInquiry(false);

            return;
        }

        try {

            await inquiryService.createInquiry({

                apartmentId: apartment.id,

                message

            });

            alert(
                "Inquiry Sent Successfully."
            );

            setMessage("");

            setShowInquiry(false);

        } catch (error) {

            console.error(error);

            alert(
                error?.response?.data?.message ||
                "Failed to Send Inquiry."
            );
        }
    };

    // --------------------------------
    // Loading
    // --------------------------------

    if (loading) {

        return (

            <MainLayout>

                <div className="text-center mt-5">

                    <div
                        className="spinner-border text-primary"
                        role="status"
                    />

                </div>

            </MainLayout>
        );
    }

    // --------------------------------
    // Not Found
    // --------------------------------

    if (!apartment) {

        return (

            <MainLayout>

                <div className="container py-5">

                    <div className="alert alert-danger">

                        <h4>
                            Apartment Not Found
                        </h4>

                        <p className="mb-0">
                            The requested property could not be found.
                        </p>

                    </div>

                </div>

            </MainLayout>
        );
    }

    return (

        <MainLayout>

            {/* =========================================
                INQUIRY MODAL
            ========================================= */}

            {showInquiry && !isOwner && (

                <div
                    className="modal d-block"
                    tabIndex="-1"
                    style={{
                        backgroundColor:
                            "rgba(0,0,0,0.5)"
                    }}
                >

                    <div className="modal-dialog">

                        <div className="modal-content">

                            <div className="modal-header">

                                <h5 className="modal-title">
                                    📩 Send Inquiry
                                </h5>

                                <button
                                    type="button"
                                    className="btn-close"
                                    onClick={() =>
                                        setShowInquiry(false)
                                    }
                                />

                            </div>

                            <form
                                onSubmit={
                                    handleInquirySubmit
                                }
                            >

                                <div className="modal-body">

                                    <textarea
                                        rows="5"
                                        className="form-control"
                                        placeholder="Write your message..."
                                        value={message}
                                        onChange={(e) =>
                                            setMessage(
                                                e.target.value
                                            )
                                        }
                                        required
                                    />

                                </div>

                                <div className="modal-footer">

                                    <button
                                        type="button"
                                        className="btn btn-secondary"
                                        onClick={() =>
                                            setShowInquiry(false)
                                        }
                                    >
                                        Cancel
                                    </button>

                                    <button
                                        type="submit"
                                        className="btn btn-primary"
                                    >
                                        Send Inquiry
                                    </button>

                                </div>

                            </form>

                        </div>

                    </div>

                </div>
            )}

            {/* =========================================
                MAIN PROPERTY SECTION
            ========================================= */}

            <div className="container py-4">

                <div className="row g-4">

                    {/* =================================
                        IMAGES
                    ================================= */}

                    <div className="col-lg-7">

                        <div className="card shadow border-0 rounded-4 overflow-hidden">

                            <img
                                src={
                                    selectedImage ||
                                    "https://picsum.photos/900/600"
                                }
                                className="img-fluid w-100"
                                alt={apartment.title}
                                style={{
                                    height: "450px",
                                    objectFit: "cover"
                                }}
                            />

                            {apartment.images &&
                                apartment.images.length > 0 && (

                                    <div className="p-3">

                                        <div className="d-flex flex-wrap gap-2">

                                            {apartment.images.map(
                                                (image, index) => (

                                                    <img
                                                        key={index}
                                                        src={image}
                                                        alt={`Apartment ${index + 1}`}
                                                        onClick={() =>
                                                            setSelectedImage(
                                                                image
                                                            )
                                                        }
                                                        className="rounded"
                                                        style={{
                                                            width: "100px",
                                                            height: "75px",
                                                            objectFit:
                                                                "cover",
                                                            cursor:
                                                                "pointer",
                                                            border:
                                                                selectedImage ===
                                                                image
                                                                    ? "3px solid #0d6efd"
                                                                    : "1px solid #ddd"
                                                        }}
                                                    />

                                                )
                                            )}

                                        </div>

                                    </div>
                                )}

                        </div>

                    </div>

                    {/* =================================
                        PROPERTY SUMMARY
                    ================================= */}

                    <div className="col-lg-5">

                        <div className="card shadow border-0 rounded-4">

                            <div className="card-body p-4">

                                <h2 className="fw-bold">
                                    {apartment.title}
                                </h2>

                                <h2 className="text-primary fw-bold my-3">

                                    ৳{" "}
                                    {apartment.price?.toLocaleString()}

                                </h2>

                                {/* Badges */}

                                <div className="d-flex flex-wrap gap-2 mb-3">

                                    <span
                                        className={`badge fs-6 ${
                                            apartment.purpose === "SALE"
                                                ? "bg-danger"
                                                : "bg-success"
                                        }`}
                                    >
                                        {apartment.purpose}
                                    </span>

                                    {
    apartment.featured && (

        <span
            className="badge bg-warning text-dark fs-6"
        >
            ⭐ Featured
        </span>

    )
}

                                    <span
                                        className={`badge fs-6 ${
                                            apartment.status ===
                                            "AVAILABLE"
                                                ? "bg-primary"
                                                : "bg-secondary"
                                        }`}
                                    >
                                        {apartment.status}
                                    </span>

                                    {apartment.negotiable && (

                                        <span className="badge bg-warning text-dark fs-6">

                                            Negotiable

                                        </span>
                                    )}

                                    <span
                                        className={`badge fs-6 ${
                                            apartment.available
                                                ? "bg-success"
                                                : "bg-danger"
                                        }`}
                                    >
                                        {apartment.available
                                            ? "Available"
                                            : "Unavailable"}
                                    </span>

                                </div>

                                <hr />

                                {/* Location */}

                                <p className="text-muted mb-4">

                                    📍{" "}

                                    {apartment.locationName ||
                                        apartment.address ||
                                        "Location not specified"}

                                </p>

                                {/* =================================
                                    BASIC FEATURES
                                ================================= */}

                                <div className="row text-center g-3 mb-4">

                                    <div className="col-4">

                                        <div className="border rounded p-3 h-100">

                                            <h5>🛏</h5>

                                            <strong>
                                                {apartment.bedrooms ??
                                                    "-"}
                                            </strong>

                                            <div className="small text-muted">
                                                Bedrooms
                                            </div>

                                        </div>

                                    </div>

                                    <div className="col-4">

                                        <div className="border rounded p-3 h-100">

                                            <h5>🛁</h5>

                                            <strong>
                                                {apartment.bathrooms ??
                                                    "-"}
                                            </strong>

                                            <div className="small text-muted">
                                                Bathrooms
                                            </div>

                                        </div>

                                    </div>

                                    <div className="col-4">

                                        <div className="border rounded p-3 h-100">

                                            <h5>📐</h5>

                                            <strong>
                                                {apartment.sizeSqFt ??
                                                    "-"}
                                            </strong>

                                            <div className="small text-muted">
                                                Sq Ft
                                            </div>

                                        </div>

                                    </div>

                                </div>

                                {/* =================================
                                    PROPERTY INFORMATION
                                ================================= */}

                                <table className="table table-bordered">

                                    <tbody>

                                        <tr>

                                            <th width="45%">
                                                Property Type
                                            </th>

                                            <td>
                                                {apartment.propertyType ||
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Listing Scope
                                            </th>

                                            <td>

                                                {apartment.listingScope ||
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Size
                                            </th>

                                            <td>

                                                {apartment.sizeSqFt ??
                                                    "-"}{" "}
                                                Sq Ft

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Floor
                                            </th>

                                            <td>

                                                {apartment.floorNo ??
                                                    "-"}{" "}
                                                /{" "}
                                                {apartment.totalFloor ??
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Total Units
                                            </th>

                                            <td>

                                                {apartment.totalUnits ??
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Land Area
                                            </th>

                                            <td>

                                                {apartment.landAreaSqFt
                                                    ? `${apartment.landAreaSqFt.toLocaleString()} Sq Ft`
                                                    : "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Year Built
                                            </th>

                                            <td>

                                                {apartment.yearBuilt ??
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Balconies
                                            </th>

                                            <td>

                                                {apartment.balconies ??
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Parking
                                            </th>

                                            <td>

                                                {apartment.parkingSpaces ??
                                                    0}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Furnishing
                                            </th>

                                            <td>

                                                {apartment.furnishing ||
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Location
                                            </th>

                                            <td>

                                                {apartment.locationName ||
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Address
                                            </th>

                                            <td>

                                                {apartment.address ||
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Postal Code
                                            </th>

                                            <td>

                                                {apartment.postalCode ||
                                                    "-"}

                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Available From
                                            </th>

                                            <td>

                                                {apartment.availableFrom
                                                    ? new Date(
                                                        apartment.availableFrom
                                                    ).toLocaleDateString()
                                                    : "-"}

                                            </td>

                                        </tr>

                                    </tbody>

                                </table>

                                {/* =================================
                                    CONTACT
                                ================================= */}

                                <hr />

                                <h5 className="mb-3">
                                    👤 Contact Information
                                </h5>

                                <p>
                                    <strong>Name:</strong>{" "}
                                    {apartment.contactName ||
                                        "-"}
                                </p>

                                <p>
                                    <strong>Phone:</strong>{" "}
                                    {apartment.contactPhone ||
                                        "-"}
                                </p>

                                <p>
                                    <strong>Email:</strong>{" "}
                                    {apartment.contactEmail ||
                                        "-"}
                                </p>

                                {/* =================================
                                    INQUIRY BUTTON
                                ================================= */}

                                {isOwner ? (

                                    <button
                                        className="btn btn-secondary btn-lg w-100 mt-3"
                                        disabled
                                    >
                                        🏠 Your Apartment
                                    </button>

                                ) : (

                                    <button
                                        className="btn btn-success btn-lg w-100 mt-3"
                                        onClick={
                                            handleInquiryClick
                                        }
                                    >
                                        📩 Send Inquiry
                                    </button>

                                )}

                            </div>

                        </div>

                    </div>

                </div>

                {/* =========================================
                    DESCRIPTION
                ========================================= */}

                <div className="card shadow border-0 rounded-4 mt-5">

                    <div className="card-body p-4">

                        <h3 className="mb-3">
                            📝 Description
                        </h3>

                        <p className="mb-0">

                            {apartment.description ||
                                "No description has been provided for this property."}

                        </p>

                    </div>

                </div>

                {/* =========================================
                    PROPERTY FEATURES
                ========================================= */}

                <div className="card shadow border-0 rounded-4 mt-5">

                    <div className="card-body p-4">

                        <div className="d-flex align-items-center mb-4">

                            <div
                                className="bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-3"
                                style={{
                                    width: "50px",
                                    height: "50px"
                                }}
                            >
                                ✨
                            </div>

                            <div>

                                <h3 className="mb-0 fw-bold">
                                    Property Features
                                </h3>

                                <small className="text-muted">
                                    Amenities and facilities available
                                </small>

                            </div>

                        </div>

                        {apartment.features &&
                        apartment.features.length > 0 ? (

                            <div className="row g-3">

                                {apartment.features.map(
                                    (feature) => (

                                        <div
                                            className="col-md-4 col-sm-6"
                                            key={feature}
                                        >

                                            <div className="d-flex align-items-center p-3 rounded-3 border bg-light h-100">

                                                <span
                                                    className="text-success fw-bold me-2"
                                                    style={{
                                                        fontSize:
                                                            "20px"
                                                    }}
                                                >
                                                    ✓
                                                </span>

                                                <span className="fw-semibold">

                                                    {feature
                                                        .replaceAll(
                                                            "_",
                                                            " "
                                                        )}

                                                </span>

                                            </div>

                                        </div>

                                    )
                                )}

                            </div>

                        ) : (

                            <div className="text-center py-4">

                                <div
                                    className="mb-2"
                                    style={{
                                        fontSize: "35px"
                                    }}
                                >
                                    🏠
                                </div>

                                <p className="text-muted mb-0">

                                    No additional features have
                                    been specified for this property.

                                </p>

                            </div>

                        )}

                    </div>

                </div>

                {/* =========================================
                    MAP + QUICK INFO
                ========================================= */}

                <div className="row mt-5 g-4">

                    <div className="col-lg-8">

                        <div className="card shadow border-0 rounded-4">

                            <div className="card-body">

                                <h3 className="mb-3">
                                    🗺 Location Map
                                </h3>

                                {apartment.latitude &&
                                apartment.longitude ? (

                                    <iframe
                                        title="Apartment Location"
                                        width="100%"
                                        height="400"
                                        style={{
                                            border: 0,
                                            borderRadius:
                                                "12px"
                                        }}
                                        loading="lazy"
                                        allowFullScreen
                                        src={`https://maps.google.com/maps?q=${apartment.latitude},${apartment.longitude}&z=15&output=embed`}
                                    />

                                ) : (

                                    <div className="alert alert-warning mb-0">

                                        Location coordinates are
                                        not available.

                                    </div>

                                )}

                            </div>

                        </div>

                    </div>

                    <div className="col-lg-4">

                        <div className="card shadow border-0 rounded-4 h-100">

                            <div className="card-body">

                                <h3 className="mb-4">
                                    📌 Quick Info
                                </h3>

                                <table className="table">

                                    <tbody>

                                        <tr>

                                            <th>
                                                Property ID
                                            </th>

                                            <td>
                                                #{apartment.id}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Property Type
                                            </th>

                                            <td>
                                                {apartment.propertyType ||
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Listing Scope
                                            </th>

                                            <td>
                                                {apartment.listingScope ||
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Status
                                            </th>

                                            <td>
                                                {apartment.status ||
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Purpose
                                            </th>

                                            <td>
                                                {apartment.purpose ||
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Total Units
                                            </th>

                                            <td>
                                                {apartment.totalUnits ??
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Year Built
                                            </th>

                                            <td>
                                                {apartment.yearBuilt ??
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Latitude
                                            </th>

                                            <td>
                                                {apartment.latitude ??
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Longitude
                                            </th>

                                            <td>
                                                {apartment.longitude ??
                                                    "-"}
                                            </td>

                                        </tr>

                                        <tr>

                                            <th>
                                                Created
                                            </th>

                                            <td>

                                                {apartment.createdAt
                                                    ? new Date(
                                                        apartment.createdAt
                                                    ).toLocaleDateString()
                                                    : "-"}

                                            </td>

                                        </tr>

                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                </div>

                {/* =========================================
                    FOOTER MESSAGE
                ========================================= */}

                <div className="text-center mt-5 mb-3">

                    <hr />

                    <h4 className="fw-bold text-primary">

                        🏡 Thank you for exploring this property!

                    </h4>

                    <p className="text-muted">

                        {isOwner ? (

                            "This is your apartment listing."

                        ) : (

                            <>
                                Interested in this property?
                                Click the{" "}
                                <strong>
                                    "Send Inquiry"
                                </strong>{" "}
                                button above to contact the owner
                                directly.
                            </>

                        )}

                    </p>

                </div>

            </div>

        </MainLayout>
    );
}

export default ApartmentDetails;