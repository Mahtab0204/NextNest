import { useEffect, useState } from "react";

import MainLayout from "../../layouts/MainLayout";
import ApartmentCard from "../../components/ApartmentCard";
import wishlistService from "../../services/wishlistService";

function MyWishlist() {

    const [apartments, setApartments] =
        useState([]);

    const [loading, setLoading] =
        useState(true);

    useEffect(() => {

        loadWishlist();

    }, []);

    const loadWishlist =
        async () => {

            try {

                setLoading(true);

                const res =
                    await wishlistService
                        .getMyWishlist();

                setApartments(
                    res.data
                );

            } catch (err) {

                console.error(err);

            } finally {

                setLoading(false);
            }
        };

    const removeWishlist =
        async (apartmentId) => {

            try {

                await wishlistService
                    .removeFromWishlist(
                        apartmentId
                    );

                setApartments(

                    apartments.filter(
                        apartment =>
                            apartment.id !==
                            apartmentId
                    )
                );

            } catch (err) {

                console.error(err);

                alert(
                    "Failed to remove apartment."
                );
            }
        };

    return (

        <MainLayout>

            <div className="d-flex justify-content-between align-items-center mb-4">

                <div>

                    <h2 className="fw-bold mb-1">

                        ❤️ My Wishlist

                    </h2>

                    <p className="text-muted mb-0">

                        Saved apartments you like

                    </p>

                </div>

                <span className="badge bg-danger fs-6">

                    {apartments.length} Saved

                </span>

            </div>

            {
                loading ? (

                    <div className="text-center py-5">

                        <div className="spinner-border text-danger" />

                    </div>

                ) : apartments.length > 0 ? (

                    <div className="row">

                        {
                            apartments.map(
                                apartment => (

                                    <div
                                        key={apartment.id}
                                        className="col-12"
                                    >

                                        <div className="position-relative">

                                            <ApartmentCard
                                                apartment={apartment}
                                            />

                                            <button
                                                className="btn btn-danger position-absolute top-0 end-0 m-3"
                                                onClick={() =>
                                                    removeWishlist(
                                                        apartment.id
                                                    )
                                                }
                                            >
                                                ♥ Remove
                                            </button>

                                        </div>

                                    </div>

                                )
                            )
                        }

                    </div>

                ) : (

                    <div className="text-center py-5">

                        <h3 className="mb-3">

                            ❤️ No Saved Apartments

                        </h3>

                        <p className="text-muted">

                            Start exploring apartments and save your favorites.

                        </p>

                    </div>

                )
            }

        </MainLayout>
    );
}

export default MyWishlist;