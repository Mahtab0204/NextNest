import {
    useState,
    useEffect
} from "react";

import {
    useLocation,
    useNavigate
} from "react-router-dom";

import { toast } from "react-toastify";

import MainLayout from "../../layouts/MainLayout";
import authService from "../../services/authService";

function ResetPassword() {

    const navigate = useNavigate();

    const location = useLocation();

    const email =
        location.state?.email || "";

    const [formData, setFormData] =
        useState({

            otp: "",

            newPassword: "",

            confirmPassword: ""

        });

    useEffect(() => {

        if (!email) {

            navigate(
                "/forgot-password"
            );

        }

    }, [email, navigate]);

    const handleChange = (e) => {

        setFormData({

            ...formData,

            [e.target.name]:
                e.target.value

        });
    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        if (
            formData.newPassword !==
            formData.confirmPassword
        ) {

            toast.error(
                "Passwords do not match"
            );

            return;
        }

        try {

            await authService.resetPassword({

                email,

                otp: formData.otp,

                newPassword:
                    formData.newPassword

            });

            toast.success(
                "Password changed successfully"
            );

            navigate("/login");

        } catch (error) {

            toast.error(
                error?.response?.data?.message ||
                "Failed to reset password"
            );
        }
    };

    return (

        <MainLayout>

            <div className="row justify-content-center">

                <div className="col-md-5">

                    <div className="card shadow">

                        <div className="card-body p-4">

                            <h2 className="text-center mb-4">

                                Reset Password

                            </h2>

                            <p className="text-muted text-center">

                                {email}

                            </p>

                            <form
                                onSubmit={handleSubmit}
                            >

                                <div className="mb-3">

                                    <label>
                                        OTP
                                    </label>

                                    <input
                                        type="text"
                                        name="otp"
                                        className="form-control"
                                        value={formData.otp}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label>
                                        New Password
                                    </label>

                                    <input
                                        type="password"
                                        name="newPassword"
                                        className="form-control"
                                        value={
                                            formData.newPassword
                                        }
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label>
                                        Confirm Password
                                    </label>

                                    <input
                                        type="password"
                                        name="confirmPassword"
                                        className="form-control"
                                        value={
                                            formData.confirmPassword
                                        }
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-success w-100"
                                >
                                    Reset Password
                                </button>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default ResetPassword;