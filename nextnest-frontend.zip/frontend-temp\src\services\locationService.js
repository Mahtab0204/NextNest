import axiosInstance from "../api/axios";

const getLocations = () => {
    return axiosInstance.get("/locations");
};

const getLocationById = (id) => {
    return axiosInstance.get(`/locations/${id}`);
};

const createLocation = (location) => {
    return axiosInstance.post(
        "/locations",
        location
    );
};

const updateLocation = (
    id,
    location
) => {
    return axiosInstance.put(
        `/locations/${id}`,
        location
    );
};

const deleteLocation = (id) => {
    return axiosInstance.delete(
        `/locations/${id}`
    );
};

const locationService = {
    getLocations,
    getLocationById,
    createLocation,
    updateLocation,
    deleteLocation
};

export default locationService;