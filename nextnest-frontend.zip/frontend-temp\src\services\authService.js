import api from "../api/axios";

const login = async (loginData) => {
    const response = await api.post(
        "/auth/login",
        loginData
    );

    return response.data;
};

const registerCustomer = async (registerData) => {
    const response = await api.post(
        "/auth/register/customer",
        registerData
    );

    return response.data;
};

const registerOwner = async (registerData) => {
    const response = await api.post(
        "/auth/register/owner",
        registerData
    );

    return response.data;
};

const verifyEmail = async (data) => {

    const response = await api.post(
        "/auth/verify-email",
        data
    );

    return response.data;
};

const resendOtp = async (email) => {

    const response = await api.post(
        "/auth/resend-otp",
        {
            email
        }
    );

    return response.data;
};

const forgotPassword = async (email) => {

    const response = await api.post(
        "/auth/forgot-password",
        {
            email
        }
    );

    return response.data;
};

const resetPassword = async (data) => {

    const response = await api.post(
        "/auth/reset-password",
        data
    );

    return response.data;
};

const authService = {
    login,
    registerCustomer,
    registerOwner,
    verifyEmail,
    resendOtp,
    forgotPassword,
    resetPassword
};


export default authService;