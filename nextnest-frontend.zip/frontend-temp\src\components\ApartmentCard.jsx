import { Link } from "react-router-dom";
import { useEffect, useState } from "react";

import wishlistService from "../services/wishlistService";
import useAuth from "../hooks/useAuth";

function ApartmentCard({ apartment }) {

    const { user } = useAuth();

    const [saved, setSaved] = useState(false);

    const isOwner =
        Number(user?.userId) === Number(apartment?.ownerId);

    const isBuilding =
        apartment?.listingScope === "BUILDING";

    useEffect(() => {

        if (!user || isOwner || !apartment?.id) {
            return;
        }

        loadWishlistStatus();

    }, [user, apartment?.id, isOwner]);

    const loadWishlistStatus = async () => {

        try {

            const res =
                await wishlistService.isWishlisted(
                    apartment.id
                );

            setSaved(res.data);

        } catch (error) {

            console.error(
                "Failed to load wishlist status:",
                error
            );

        }

    };

    const handleWishlist = async () => {

        if (!user) {

            alert("Please login first.");

            return;
        }

        if (isOwner) {

            alert(
                "You cannot add your own property to wishlist."
            );

            return;
        }

        try {

            if (saved) {

                await wishlistService.removeFromWishlist(
                    apartment.id
                );

                setSaved(false);

            } else {

                await wishlistService.addToWishlist(
                    apartment.id
                );

                setSaved(true);
            }

        } catch (error) {

            console.error(
                "Wishlist operation failed:",
                error
            );

            alert(
                "Failed to update wishlist."
            );
        }
    };

  
const image =
    apartment?.coverImage
        ? apartment.coverImage.startsWith("http")
            ? apartment.coverImage
            : `http://localhost:8080/uploads/${apartment.coverImage}`
        : apartment?.images?.[0] ||
          "https://picsum.photos/600/400";

    const formatNumber = (value) => {

        if (
            value === null ||
            value === undefined ||
            value === ""
        ) {
            return "N/A";
        }

        return Number(value).toLocaleString();
    };

    const formatFeature = (feature) => {

        if (!feature) {
            return "";
        }

        return feature
            .replaceAll("_", " ")
            .toLowerCase()
            .replace(/\b\w/g, char =>
                char.toUpperCase()
            );
    };

    return (

    <div className="col-lg-4 col-md-6 mb-4">

        <div
            className="card h-100 shadow border-0 rounded-4 overflow-hidden"
        >

            {/* ================= IMAGE ================= */}

            <div className="position-relative">

                <img
                    src={image}
                    alt={apartment.title}
                    className="card-img-top"
                    style={{
                        height: "240px",
                        objectFit: "cover"
                    }}
                />

                {/* Purpose - Top Left */}

                <span
                    className={`badge position-absolute top-0 start-0 m-3 ${
                        apartment.purpose === "SALE"
                            ? "bg-danger"
                            : "bg-success"
                    }`}
                >
                    {apartment.purpose}
                </span>


                {/* Featured - Top Right */}

                {apartment.featured && (

                    <span
                        className="badge bg-warning text-dark position-absolute top-0 end-0 m-3"
                    >
                        ⭐ Featured
                    </span>

                )}


                {/* Listing Scope - Bottom Left */}

                <span
                    className="badge bg-dark position-absolute bottom-0 start-0 m-3"
                >
                    {isBuilding
                        ? "🏢 Building"
                        : "🏠 Unit"}
                </span>


                {/* Status - Bottom Right */}

                <span
                    className={`badge position-absolute bottom-0 end-0 m-3 ${
                        apartment.status === "AVAILABLE"
                            ? "bg-primary"
                            : "bg-secondary"
                    }`}
                >
                    {apartment.status}
                </span>

            </div>


            {/* ================= BODY ================= */}

            <div className="card-body">

                {/* Title */}

                <h5 className="fw-bold mb-2">
                    {apartment.title}
                </h5>


                {/* Price */}

                <h4 className="text-primary fw-bold mb-2">

                    ৳ {formatNumber(apartment.price)}

                </h4>


                {/* Location */}

                <p className="text-muted mb-3">

                    📍{" "}

                    {apartment.locationName ||
                        apartment.address ||
                        "Location not specified"}

                </p>


                {/* ================= UNIT INFO ================= */}

                {!isBuilding && (

                    <div className="row text-center mb-3">

                        <div className="col-4">

                            <div className="fs-5">
                                🛏
                            </div>

                            <small>
                                {formatNumber(
                                    apartment.bedrooms
                                )}{" "}
                                Beds
                            </small>

                        </div>


                        <div className="col-4">

                            <div className="fs-5">
                                🚿
                            </div>

                            <small>
                                {formatNumber(
                                    apartment.bathrooms
                                )}{" "}
                                Baths
                            </small>

                        </div>


                        <div className="col-4">

                            <div className="fs-5">
                                📐
                            </div>

                            <small>
                                {formatNumber(
                                    apartment.sizeSqFt
                                )}{" "}
                                sqft
                            </small>

                        </div>

                    </div>

                )}


                {/* ================= BUILDING INFO ================= */}

                {isBuilding && (

                    <div className="row text-center mb-3">

                        <div className="col-4">

                            <div className="fs-5">
                                🏠
                            </div>

                            <small>
                                {formatNumber(
                                    apartment.totalUnits
                                )}{" "}
                                Units
                            </small>

                        </div>


                        <div className="col-4">

                            <div className="fs-5">
                                🏢
                            </div>

                            <small>
                                {formatNumber(
                                    apartment.totalFloor
                                )}{" "}
                                Floors
                            </small>

                        </div>


                        <div className="col-4">

                            <div className="fs-5">
                                📐
                            </div>

                            <small>
                                {formatNumber(
                                    apartment.landAreaSqFt
                                )}{" "}
                                sqft
                            </small>

                        </div>

                    </div>

                )}


                <hr />


                {/* ================= DETAILS ================= */}

                <div className="small">

                    {/* Property */}

                    <div className="d-flex justify-content-between mb-2">

                        <span>
                            🏠 Property
                        </span>

                        <strong>
                            {apartment.propertyType ||
                                "N/A"}
                        </strong>

                    </div>


                    {/* Furnishing */}

                    {!isBuilding && (

                        <div className="d-flex justify-content-between mb-2">

                            <span>
                                🛋 Furnishing
                            </span>

                            <strong>
                                {apartment.furnishing ||
                                    "N/A"}
                            </strong>

                        </div>

                    )}


                    {/* Parking */}

                    <div className="d-flex justify-content-between mb-2">

                        <span>
                            🚗 Parking
                        </span>

                        <strong>
                            {formatNumber(
                                apartment.parkingSpaces
                            )}
                        </strong>

                    </div>


                    {/* Building / Unit specific information */}

                    {isBuilding ? (

                        <div className="d-flex justify-content-between mb-2">

                            <span>
                                🏗 Built
                            </span>

                            <strong>
                                {apartment.yearBuilt ||
                                    "N/A"}
                            </strong>

                        </div>

                    ) : (

                        <div className="d-flex justify-content-between mb-2">

                            <span>
                                🏢 Floor
                            </span>

                            <strong>

                                {apartment.floorNo ??
                                    "N/A"}

                                {" / "}

                                {apartment.totalFloor ??
                                    "N/A"}

                            </strong>

                        </div>

                    )}

                </div>


                {/* ================= FEATURES ================= */}

                {apartment.features &&
                    apartment.features.length > 0 && (

                        <div className="mt-3">

                            <div className="small fw-bold mb-2">
                                ✨ Features
                            </div>

                            <div className="d-flex flex-wrap gap-1">

                                {apartment.features
                                    .slice(0, 4)
                                    .map(feature => (

                                        <span
                                            key={feature}
                                            className="badge bg-light text-dark border"
                                        >
                                            {formatFeature(
                                                feature
                                            )}
                                        </span>

                                    ))}


                                {apartment.features.length > 4 && (

                                    <span className="badge bg-light text-primary border">

                                        +{apartment.features.length - 4}

                                    </span>

                                )}

                            </div>

                        </div>

                    )}


                {/* ================= STATUS INFO ================= */}

                <div className="mt-3">

                    {/* Negotiable */}

                    {apartment.negotiable && (

                        <span className="badge bg-warning text-dark me-2">

                            Negotiable

                        </span>

                    )}


                    {/* Available */}

                    {apartment.available ? (

                        <span className="badge bg-success">

                            Available

                        </span>

                    ) : (

                        <span className="badge bg-danger">

                            Unavailable

                        </span>

                    )}

                </div>

            </div>


            {/* ================= FOOTER ================= */}

            <div className="card-footer bg-white border-0">

                <div className="d-flex gap-2">

                    {/* View Details */}

                    <Link
                        to={`/apartments/${apartment.id}`}
                        className="btn btn-primary rounded-pill flex-grow-1"
                    >
                        View Details →
                    </Link>


                    {/* Wishlist */}

                    {!isOwner && (

                        <button
                            type="button"
                            className={
                                saved
                                    ? "btn btn-danger rounded-pill"
                                    : "btn btn-outline-danger rounded-pill"
                            }
                            onClick={handleWishlist}
                            title={
                                saved
                                    ? "Remove from wishlist"
                                    : "Add to wishlist"
                            }
                        >
                            {saved ? "♥" : "♡"}
                        </button>

                    )}


                    {/* Owner Listing */}

                    {isOwner && (

                        <span
                            className="badge bg-light text-dark d-flex align-items-center px-3"
                        >
                            Your Listing
                        </span>

                    )}

                </div>

            </div>

        </div>

    </div>

);
}

export default ApartmentCard;