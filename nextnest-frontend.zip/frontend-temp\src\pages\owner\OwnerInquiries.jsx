import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import inquiryService from "../../services/inquiryService";

function OwnerInquiries() {

    const [inquiries, setInquiries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [statusFilter, setStatusFilter] = useState("ALL");

    useEffect(() => {
        loadInquiries();
    }, []);

    const loadInquiries = async () => {
        try {
            setLoading(true);

            const response =
                await inquiryService.getOwnerInquiries();

            setInquiries(response.data);

        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleStatusChange = async (
        inquiryId,
        status
    ) => {
        try {

            await inquiryService.updateInquiryStatus(
                inquiryId,
                status
            );

            loadInquiries();

        } catch (error) {
            console.error(error);
        }
    };

    const filteredInquiries =
        statusFilter === "ALL"
            ? inquiries
            : inquiries.filter(
                inquiry =>
                    inquiry.status === statusFilter
            );

    const getStatusBadge = (status) => {

        switch (status) {

            case "PENDING":
                return (
                    <span className="badge bg-warning text-dark">
                        Pending
                    </span>
                );

            case "ACCEPTED":
                return (
                    <span className="badge bg-success">
                        Accepted
                    </span>
                );

            case "REJECTED":
                return (
                    <span className="badge bg-danger">
                        Rejected
                    </span>
                );

            default:
                return (
                    <span className="badge bg-secondary">
                        {status}
                    </span>
                );
        }
    };

    return (

        <MainLayout>

            <div className="container py-4">

                <div className="d-flex justify-content-between align-items-center mb-4">

                    <div>
                        <h2 className="fw-bold mb-1">
                            Owner Inquiries
                        </h2>

                        <p className="text-muted mb-0">
                            Manage customer inquiries for your apartments.
                        </p>
                    </div>

                    <select
                        className="form-select w-auto"
                        value={statusFilter}
                        onChange={(e) =>
                            setStatusFilter(
                                e.target.value
                            )
                        }
                    >

                        <option value="ALL">
                            All
                        </option>

                        <option value="PENDING">
                            Pending
                        </option>

                        <option value="ACCEPTED">
                            Accepted
                        </option>

                        <option value="REJECTED">
                            Rejected
                        </option>

                    </select>

                </div>

                {
                    loading ? (

                        <div className="text-center py-5">

                            <div
                                className="spinner-border text-primary"
                            />

                        </div>

                    ) : (

                        <div className="card shadow-sm border-0">

                            <div className="card-body">

                                <div className="table-responsive">

                                    <table className="table table-hover align-middle">

                                        <thead>

                                            <tr>

                                                <th>
                                                    Apartment
                                                </th>

                                                <th>
                                                    Customer
                                                </th>

                                                <th>
                                                    Email
                                                </th>

                                                <th>
                                                    Message
                                                </th>

                                                <th>
                                                    Status
                                                </th>

                                                <th>
                                                    Actions
                                                </th>

                                            </tr>

                                        </thead>

                                        <tbody>

                                            {
                                                filteredInquiries.length > 0 ? (

                                                    filteredInquiries.map(
                                                        inquiry => (

                                                            <tr
                                                                key={
                                                                    inquiry.id
                                                                }
                                                            >

                                                                <td className="fw-semibold">
                                                                    {
                                                                        inquiry.apartmentTitle
                                                                    }
                                                                </td>

                                                                <td>
                                                                    {
                                                                        inquiry.customerName
                                                                    }
                                                                </td>

                                                                <td>
                                                                    {
                                                                        inquiry.customerEmail
                                                                    }
                                                                </td>

                                                                <td
                                                                    style={{
                                                                        maxWidth: "300px"
                                                                    }}
                                                                >
                                                                    <span className="text-muted">
                                                                        {
                                                                            inquiry.message
                                                                        }
                                                                    </span>
                                                                </td>

                                                                <td>
                                                                    {
                                                                        getStatusBadge(
                                                                            inquiry.status
                                                                        )
                                                                    }
                                                                </td>

                                                                <td>

                                                                    <div className="d-flex gap-2 flex-wrap">

                                                                        {
                                                                            inquiry.status ===
                                                                            "PENDING" && (

                                                                                <>
                                                                                    <button
                                                                                        className="btn btn-success btn-sm"
                                                                                        onClick={() =>
                                                                                            handleStatusChange(
                                                                                                inquiry.id,
                                                                                                "ACCEPTED"
                                                                                            )
                                                                                        }
                                                                                    >
                                                                                        Accept
                                                                                    </button>

                                                                                    <button
                                                                                        className="btn btn-danger btn-sm"
                                                                                        onClick={() =>
                                                                                            handleStatusChange(
                                                                                                inquiry.id,
                                                                                                "REJECTED"
                                                                                            )
                                                                                        }
                                                                                    >
                                                                                        Reject
                                                                                    </button>
                                                                                </>

                                                                            )
                                                                        }

                                                                        {
                                                                            inquiry.status ===
                                                                            "ACCEPTED" && (

                                                                                <Link
                                                                                    to={`/messages/${inquiry.id}`}
                                                                                    className="btn btn-primary btn-sm"
                                                                                >
                                                                                    Open Chat
                                                                                </Link>

                                                                            )
                                                                        }

                                                                        {
                                                                            inquiry.status ===
                                                                            "REJECTED" && (

                                                                                <span className="text-muted small">
                                                                                    Rejected
                                                                                </span>

                                                                            )
                                                                        }

                                                                    </div>

                                                                </td>

                                                            </tr>

                                                        )
                                                    )

                                                ) : (

                                                    <tr>

                                                        <td
                                                            colSpan="6"
                                                            className="text-center text-muted py-4"
                                                        >
                                                            No inquiries found.
                                                        </td>

                                                    </tr>

                                                )
                                            }

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                    )
                }

            </div>

        </MainLayout>
    );
}

export default OwnerInquiries;