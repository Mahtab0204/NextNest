import axiosInstance from "../api/axios";

const getDashboardStats = () => {

    return axiosInstance.get(
        "/admin/dashboard/stats"
    );
};
const getRecentPendingApartments = () =>
    axiosInstance.get(
        "/admin/apartments/pending/recent"
    );

const searchApartments = (keyword) => {
    return axiosInstance.get(
        `/admin/apartments/search?keyword=${keyword}`
    );
};

const getApartmentsByStatus = (
    status
) => {

    return axiosInstance.get(
        `/admin/apartments/status/${status}`
    );
};
const adminService = {

    getDashboardStats,
    getRecentPendingApartments,
    searchApartments,
    getApartmentsByStatus
};




export default adminService;