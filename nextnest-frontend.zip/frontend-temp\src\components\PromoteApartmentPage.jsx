import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";

import MainLayout from "../layouts/MainLayout";
import featuredService from "../services/featuredService";

function PromoteApartmentPage() {

    const location = useLocation();
    const navigate = useNavigate();

    const { apartment, plan, amount } =
        location.state || {};

    const [loading, setLoading] =
        useState(false);

    const [paymentMethod, setPaymentMethod] =
        useState("BKASH");

    const [transactionId, setTransactionId] =
        useState("");

    const [paymentNumber, setPaymentNumber] =
        useState("");

    const [paymentError, setPaymentError] =
        useState("");

    const paymentMethods = [

        {
            id: "BKASH",
            name: "bKash",
            icon: "📱",
            description: "Pay using bKash",
            color: "danger"
        },

        {
            id: "NAGAD",
            name: "Nagad",
            icon: "💳",
            description: "Pay using Nagad",
            color: "warning"
        },

        {
            id: "BANK",
            name: "Bank / Card",
            icon: "🏦",
            description: "Bank or card payment",
            color: "primary"
        }

    ];

    const handlePaymentMethod =
        (method) => {

            setPaymentMethod(method);

            setPaymentError("");

            setTransactionId("");

            setPaymentNumber("");
        };

    const handlePayment = async () => {

        setPaymentError("");

        if (!apartment?.id || !plan) {

            setPaymentError(
                "Invalid promotion request."
            );

            return;
        }

        if (!paymentNumber.trim()) {

            setPaymentError(
                `Please enter your ${
                    paymentMethod === "BKASH"
                        ? "bKash"
                        : paymentMethod === "NAGAD"
                        ? "Nagad"
                        : "payment"
                } number.`
            );

            return;
        }

        if (!transactionId.trim()) {

            setPaymentError(
                "Please enter the transaction ID."
            );

            return;
        }

        try {

            setLoading(true);

            /*
             * FUTURE PAYMENT INTEGRATION
             *
             * In the real implementation, this section
             * will call the bKash/Nagad/Bank payment gateway.
             *
             * Currently the transaction ID is only collected
             * for demonstration purposes.
             */

            await featuredService.promoteApartment({

                apartmentId: apartment.id,

                plan: plan,

                paymentMethod: paymentMethod,

                transactionId: transactionId,

                paymentNumber: paymentNumber

            });

            alert(
                "Payment recorded successfully. Apartment promotion activated."
            );

            navigate(
                "/owner/apartments"
            );

        } catch (error) {

            console.error(
                "Promotion payment error:",
                error
            );

            setPaymentError(

                error?.response?.data?.message ||

                "Payment could not be processed."

            );

        } finally {

            setLoading(false);

        }
    };

    if (!apartment) {

        return (

            <MainLayout>

                <div className="container py-5">

                    <div className="row justify-content-center">

                        <div className="col-lg-7">

                            <div className="card border-0 shadow-lg rounded-4">

                                <div className="card-body p-5 text-center">

                                    <div
                                        className="mb-3"
                                        style={{
                                            fontSize: "60px"
                                        }}
                                    >
                                        ⚠️
                                    </div>

                                    <h4 className="fw-bold">

                                        Invalid Promotion Request

                                    </h4>

                                    <p className="text-muted">

                                        No apartment information
                                        was provided.

                                    </p>

                                    <button
                                        className="btn btn-primary rounded-pill px-4"
                                        onClick={() =>
                                            navigate(
                                                "/owner/apartments"
                                            )
                                        }
                                    >
                                        ← Back to My Apartments
                                    </button>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </MainLayout>
        );
    }

    return (

        <MainLayout>

            <div
                className="container py-5"
                style={{
                    maxWidth: "1100px"
                }}
            >

                {/* ================= HEADER ================= */}

                <div className="text-center mb-5">

                    <div
                        className="d-inline-flex align-items-center justify-content-center rounded-circle bg-warning mb-3"
                        style={{
                            width: "70px",
                            height: "70px",
                            fontSize: "32px"
                        }}
                    >
                        ⭐
                    </div>

                    <h2 className="fw-bold mb-2">

                        Promote Your Apartment

                    </h2>

                    <p className="text-muted mb-0">

                        Boost your property's visibility
                        and reach more potential customers.

                    </p>

                </div>


                <div className="row g-4">

                    {/* ================= LEFT SIDE ================= */}

                    <div className="col-lg-7">

                        {/* Apartment Summary */}

                        <div
                            className="card border-0 shadow-sm rounded-4 mb-4"
                        >

                            <div className="card-body p-4">

                                <div className="d-flex align-items-center mb-4">

                                    <div
                                        className="rounded-3 bg-light d-flex align-items-center justify-content-center me-3"
                                        style={{
                                            width: "55px",
                                            height: "55px",
                                            fontSize: "26px"
                                        }}
                                    >
                                        🏠
                                    </div>

                                    <div>

                                        <h5 className="fw-bold mb-1">

                                            {apartment.title}

                                        </h5>

                                        <small className="text-muted">

                                            Apartment #{apartment.id}

                                        </small>

                                    </div>

                                </div>

                                <div className="row g-3">

                                    <div className="col-6">

                                        <div className="bg-light rounded-3 p-3">

                                            <small className="text-muted d-block">
                                                Promotion Plan
                                            </small>

                                            <strong className="text-primary">
                                                {plan}
                                            </strong>

                                        </div>

                                    </div>

                                    <div className="col-6">

                                        <div className="bg-light rounded-3 p-3">

                                            <small className="text-muted d-block">
                                                Total Amount
                                            </small>

                                            <strong className="text-success fs-5">

                                                ৳
                                                {Number(
                                                    amount || 0
                                                ).toLocaleString()}

                                            </strong>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>


                        {/* ================= PAYMENT METHODS ================= */}

                        <div
                            className="card border-0 shadow-sm rounded-4"
                        >

                            <div className="card-body p-4">

                                <div className="d-flex justify-content-between align-items-center mb-3">

                                    <div>

                                        <h5 className="fw-bold mb-1">

                                            💳 Choose Payment Method

                                        </h5>

                                        <small className="text-muted">

                                            Select your preferred
                                            payment method.

                                        </small>

                                    </div>

                                </div>


                                <div className="row g-3 mb-4">

                                    {paymentMethods.map(
                                        method => (

                                            <div
                                                className="col-md-4"
                                                key={method.id}
                                            >

                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        handlePaymentMethod(
                                                            method.id
                                                        )
                                                    }
                                                    className={`w-100 h-100 text-start border rounded-4 p-3 bg-white ${
                                                        paymentMethod ===
                                                        method.id
                                                            ? "border-primary shadow-sm"
                                                            : ""
                                                    }`}
                                                    style={{
                                                        transition:
                                                            "all 0.2s ease"
                                                    }}
                                                >

                                                    <div className="d-flex align-items-center mb-2">

                                                        <span
                                                            style={{
                                                                fontSize:
                                                                    "28px"
                                                            }}
                                                            className="me-2"
                                                        >
                                                            {
                                                                method.icon
                                                            }
                                                        </span>

                                                        <strong>

                                                            {
                                                                method.name
                                                            }

                                                        </strong>

                                                    </div>

                                                    <small className="text-muted">

                                                        {
                                                            method.description
                                                        }

                                                    </small>

                                                    {paymentMethod ===
                                                        method.id && (

                                                        <div className="mt-2">

                                                            <span className="badge bg-primary">

                                                                ✓ Selected

                                                            </span>

                                                        </div>

                                                    )}

                                                </button>

                                            </div>

                                        )
                                    )}

                                </div>


                                {/* ================= PAYMENT FORM ================= */}

                                <div className="border-top pt-4">

                                    <h6 className="fw-bold mb-3">

                                        Payment Information

                                    </h6>

                                    <div className="mb-3">

                                        <label className="form-label fw-semibold">

                                            {paymentMethod ===
                                            "BKASH"
                                                ? "bKash Number"
                                                : paymentMethod ===
                                                  "NAGAD"
                                                ? "Nagad Number"
                                                : "Account / Card Number"}

                                        </label>

                                        <input
                                            type="text"
                                            className="form-control form-control-lg"
                                            placeholder={
                                                paymentMethod ===
                                                "BKASH"
                                                    ? "01XXXXXXXXX"
                                                    : paymentMethod ===
                                                      "NAGAD"
                                                    ? "01XXXXXXXXX"
                                                    : "Enter account/card number"
                                            }
                                            value={
                                                paymentNumber
                                            }
                                            onChange={(e) =>
                                                setPaymentNumber(
                                                    e.target.value
                                                )
                                            }
                                        />

                                    </div>


                                    <div className="mb-3">

                                        <label className="form-label fw-semibold">

                                            Transaction ID

                                        </label>

                                        <input
                                            type="text"
                                            className="form-control form-control-lg"
                                            placeholder="Example: TXN8A72K91"
                                            value={
                                                transactionId
                                            }
                                            onChange={(e) =>
                                                setTransactionId(
                                                    e.target.value
                                                )
                                            }
                                        />

                                        <small className="text-muted">

                                            Enter the transaction ID
                                            you would receive after
                                            completing the payment.

                                        </small>

                                    </div>


                                    {/* Demo Notice */}

                                    <div className="alert alert-info border-0 rounded-4">

                                        <div className="d-flex">

                                            <div
                                                className="me-3"
                                                style={{
                                                    fontSize:
                                                        "25px"
                                                }}
                                            >
                                                ℹ️
                                            </div>

                                            <div>

                                                <strong>
                                                    Payment Gateway
                                                    Preview
                                                </strong>

                                                <p className="mb-0 mt-1 small">

                                                    This interface is
                                                    prepared for future
                                                    bKash, Nagad and
                                                    banking integration.
                                                    No real money will be
                                                    transferred from this
                                                    page yet.

                                                </p>

                                            </div>

                                        </div>

                                    </div>


                                    {paymentError && (

                                        <div className="alert alert-danger rounded-3">

                                            ⚠️{" "}

                                            {paymentError}

                                        </div>

                                    )}


                                    {/* Buttons */}

                                    <div className="d-flex gap-3 mt-4">

                                        <button
                                            type="button"
                                            className="btn btn-outline-secondary rounded-pill px-4"
                                            onClick={() =>
                                                navigate(
                                                    "/owner/apartments"
                                                )
                                            }
                                            disabled={loading}
                                        >

                                            ← Cancel

                                        </button>

                                        <button
                                            type="button"
                                            className="btn btn-success rounded-pill flex-grow-1"
                                            onClick={
                                                handlePayment
                                            }
                                            disabled={loading}
                                        >

                                            {loading ? (

                                                <>

                                                    <span
                                                        className="spinner-border spinner-border-sm me-2"
                                                    />

                                                    Processing Payment...

                                                </>

                                            ) : (

                                                <>
                                                    🔒 Confirm Payment
                                                    ৳
                                                    {Number(
                                                        amount || 0
                                                    ).toLocaleString()}
                                                </>

                                            )}

                                        </button>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>


                    {/* ================= RIGHT SIDE ================= */}

                    <div className="col-lg-5">

                        {/* Order Summary */}

                        <div
                            className="card border-0 shadow-sm rounded-4 sticky-top"
                            style={{
                                top: "20px"
                            }}
                        >

                            <div className="card-body p-4">

                                <h5 className="fw-bold mb-4">

                                    🧾 Payment Summary

                                </h5>

                                <div className="d-flex justify-content-between mb-3">

                                    <span className="text-muted">
                                        Apartment
                                    </span>

                                    <strong className="text-end ms-3">

                                        {apartment.title}

                                    </strong>

                                </div>

                                <div className="d-flex justify-content-between mb-3">

                                    <span className="text-muted">
                                        Plan
                                    </span>

                                    <strong>
                                        {plan}
                                    </strong>

                                </div>

                                <div className="d-flex justify-content-between mb-3">

                                    <span className="text-muted">
                                        Payment Method
                                    </span>

                                    <strong>
                                        {
                                            paymentMethods.find(
                                                method =>
                                                    method.id ===
                                                    paymentMethod
                                            )?.name
                                        }
                                    </strong>

                                </div>

                                <hr />

                                <div className="d-flex justify-content-between align-items-center">

                                    <span className="fw-bold">
                                        Total
                                    </span>

                                    <span className="text-success fw-bold fs-3">

                                        ৳
                                        {Number(
                                            amount || 0
                                        ).toLocaleString()}

                                    </span>

                                </div>


                                <div className="mt-4 p-3 bg-light rounded-4">

                                    <div className="d-flex mb-2">

                                        <span className="me-2">
                                            🔐
                                        </span>

                                        <small>

                                            Secure payment flow
                                            prepared for future
                                            gateway integration.

                                        </small>

                                    </div>

                                    <div className="d-flex">

                                        <span className="me-2">
                                            ⚡
                                        </span>

                                        <small>

                                            Promotion will be activated
                                            after successful payment
                                            verification.

                                        </small>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default PromoteApartmentPage;