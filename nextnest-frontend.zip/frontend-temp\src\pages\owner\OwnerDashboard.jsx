import { Link } from "react-router-dom";
import MainLayout from "../../layouts/MainLayout";

function OwnerDashboard() {

    const actions = [
        {
            icon: "🏢",
            title: "My Apartments",
            description: "View, edit and manage all your property listings.",
            link: "/owner/apartments",
            button: "Manage Apartments",
            color: "primary"
        },
        {
            icon: "➕",
            title: "Create Apartment",
            description: "Add a new apartment listing and publish your property.",
            link: "/owner/create-apartment",
            button: "Create Listing",
            color: "warning"
        },
        {
            icon: "💬",
            title: "View Inquiries",
            description: "Review customer inquiries and communicate with potential buyers or tenants.",
            link: "/owner/inquiries",
            button: "View Inquiries",
            color: "success"
        },
        {
            icon: "👤",
            title: "My Profile",
            description: "View and update your personal information and account settings.",
            link: "/profile",
            button: "Open Profile",
            color: "info"
        }
    ];

    return (
        <MainLayout>

            <div className="container py-5">

                {/* Welcome Header */}
                <div
                    className="rounded-4 shadow-sm p-4 p-md-5 mb-5 text-white"
                    style={{
                        background:
                            "linear-gradient(135deg, #0d6efd 0%, #4338ca 100%)"
                    }}
                >

                    <div className="row align-items-center">

                        <div className="col-md-8">

                            <span className="badge bg-white text-primary px-3 py-2 rounded-pill mb-3">
                                🏢 NextNest Owner
                            </span>

                            <h1 className="fw-bold mb-2">
                                Welcome back, Owner!
                            </h1>

                            <p className="mb-0 fs-5 opacity-75">
                                Manage your properties, respond to inquiries
                                and keep your listings up to date.
                            </p>

                        </div>

                        <div className="col-md-4 text-center mt-4 mt-md-0">

                            <div
                                className="bg-white bg-opacity-25 rounded-circle d-inline-flex align-items-center justify-content-center"
                                style={{
                                    width: "125px",
                                    height: "125px",
                                    fontSize: "60px"
                                }}
                            >
                                🏠
                            </div>

                        </div>

                    </div>

                </div>

                {/* Quick Overview */}
                <div className="mb-4">

                    <h4 className="fw-bold mb-1">
                        Owner Overview
                    </h4>

                    <p className="text-muted">
                        Manage your NextNest activities from one place.
                    </p>

                </div>

                <div className="row g-3 mb-5">

                    <div className="col-md-4">

                        <div className="card border-0 shadow-sm rounded-4 h-100">

                            <div className="card-body p-4 d-flex align-items-center">

                                <div
                                    className="rounded-3 bg-primary bg-opacity-10 d-flex align-items-center justify-content-center me-3"
                                    style={{
                                        width: "55px",
                                        height: "55px",
                                        fontSize: "25px"
                                    }}
                                >
                                    🏢
                                </div>

                                <div>
                                    <small className="text-muted">
                                        Manage
                                    </small>

                                    <h5 className="fw-bold mb-0">
                                        Properties
                                    </h5>
                                </div>

                            </div>

                        </div>

                    </div>

                    <div className="col-md-4">

                        <div className="card border-0 shadow-sm rounded-4 h-100">

                            <div className="card-body p-4 d-flex align-items-center">

                                <div
                                    className="rounded-3 bg-success bg-opacity-10 d-flex align-items-center justify-content-center me-3"
                                    style={{
                                        width: "55px",
                                        height: "55px",
                                        fontSize: "25px"
                                    }}
                                >
                                    💬
                                </div>

                                <div>
                                    <small className="text-muted">
                                        Communicate
                                    </small>

                                    <h5 className="fw-bold mb-0">
                                        Inquiries
                                    </h5>
                                </div>

                            </div>

                        </div>

                    </div>

                    <div className="col-md-4">

                        <div className="card border-0 shadow-sm rounded-4 h-100">

                            <div className="card-body p-4 d-flex align-items-center">

                                <div
                                    className="rounded-3 bg-info bg-opacity-10 d-flex align-items-center justify-content-center me-3"
                                    style={{
                                        width: "55px",
                                        height: "55px",
                                        fontSize: "25px"
                                    }}
                                >
                                    👤
                                </div>

                                <div>
                                    <small className="text-muted">
                                        Account
                                    </small>

                                    <h5 className="fw-bold mb-0">
                                        My Profile
                                    </h5>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

                {/* Actions */}
                <div className="mb-4">

                    <h4 className="fw-bold mb-1">
                        Quick Actions
                    </h4>

                    <p className="text-muted mb-0">
                        Everything you need to manage your properties.
                    </p>

                </div>

                <div className="row g-4">

                    {actions.map((action, index) => (

                        <div
                            className="col-md-6 col-lg-3"
                            key={index}
                        >

                            <div
                                className="card border-0 shadow-sm rounded-4 h-100"
                                style={{
                                    transition: "all 0.2s ease"
                                }}
                            >

                                <div className="card-body p-4 d-flex flex-column">

                                    <div
                                        className={`rounded-4 bg-${action.color} bg-opacity-10 d-flex align-items-center justify-content-center mb-4`}
                                        style={{
                                            width: "65px",
                                            height: "65px",
                                            fontSize: "30px"
                                        }}
                                    >
                                        {action.icon}
                                    </div>

                                    <h5 className="fw-bold mb-2">
                                        {action.title}
                                    </h5>

                                    <p className="text-muted flex-grow-1">
                                        {action.description}
                                    </p>

                                    <Link
                                        to={action.link}
                                        className={`btn btn-${action.color} rounded-3 w-100`}
                                    >
                                        {action.button} →
                                    </Link>

                                </div>

                            </div>

                        </div>

                    ))}

                </div>

                {/* Owner CTA */}
                <div className="card border-0 shadow-sm rounded-4 mt-5">

                    <div className="card-body p-4 p-md-5">

                        <div className="row align-items-center">

                            <div className="col-md-8">

                                <span className="badge bg-warning bg-opacity-10 text-warning px-3 py-2 rounded-pill mb-3">
                                    PROPERTY MANAGEMENT
                                </span>

                                <h4 className="fw-bold mb-2">
                                    Ready to add another property?
                                </h4>

                                <p className="text-muted mb-md-0">
                                    Create a new apartment listing and connect
                                    with potential customers through NextNest.
                                </p>

                            </div>

                            <div className="col-md-4 text-md-end mt-4 mt-md-0">

                                <Link
                                    to="/owner/create-apartment"
                                    className="btn btn-warning btn-lg rounded-3 px-4"
                                >
                                    + Create Apartment
                                </Link>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default OwnerDashboard;