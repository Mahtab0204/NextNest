import axiosInstance from "../api/axios";


const getApartmentsByPurpose = (
    purpose
) => {

    return axiosInstance.get(
        `/apartments/purpose/${purpose}`
    );
};
const getApartments = (
    page = 0,
    size = 12,
    sortBy = "createdAt",
    sortDir = "desc"
) => {

    return axiosInstance.get(
        `/apartments?page=${page}&size=${size}&sortBy=${sortBy}&sortDir=${sortDir}`
    );
};

const getApartmentById = (id) => {

    return axiosInstance.get(
        `/apartments/${id}`
    );
};

const getOwnerApartments = (ownerId) => {
    return axiosInstance.get(
        `/apartments/owner/${ownerId}`
    );
};

const deleteApartment = (id) => {
    return axiosInstance.delete(
        `/apartments/${id}`
    );
};

const searchApartments = (keyword) => {

    return axiosInstance.get(
        `/apartments/search?keyword=${keyword}`
    );
};

const createApartment = (apartmentData) => {

    return axiosInstance.post(
        "/apartments",
        apartmentData
    );
};

const uploadImage = (id, formData) => {
    return axiosInstance.post(
        `/apartments/${id}/images`,
        formData,
        {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        }
    );
};

const updateApartment = (
    id,
    apartmentData
) => {

    return axiosInstance.put(
        `/apartments/${id}`,
        apartmentData
    );
};

const getApartmentImages = (id) => {

    return axiosInstance.get(
        `/apartments/${id}/images`
    );
};

const deleteImage = (imageId) => {

    return axiosInstance.delete(
        `/apartments/images/${imageId}`
    );
};

const setCoverImage = (imageId) => {

    return axiosInstance.patch(
        `/apartments/images/${imageId}/cover`
    );
};

const approveApartment = (id) => {
    return axiosInstance.put(
        `/admin/apartments/${id}/approve`
    );
};

const rejectApartment = (
    id,
    reason
) => {

    return axiosInstance.post(
        `/admin/apartments/${id}/reject`,
        {
            reason
        }
    );
};

const getAdminApartmentDetails = (id) => {

    return axiosInstance.get(
        `/admin/apartments/${id}`
    );
};

const getApartmentsByArea = (area,purpose) => {
    return axiosInstance.get(
        "/apartments/area",
        {
            params: { area,purpose }
        }
    );
};

const getHomepageApartments = () => {
    return axiosInstance.get(
        "/apartments/homepage"
    );
};

const filterApartments = (
    purpose,
    bedrooms,
    minPrice,
    maxPrice
) => {

    let url = "/apartments/filter?";

    if (purpose) {
        url += `purpose=${purpose}&`;
    }

    if (bedrooms) {
        url += `bedrooms=${bedrooms}&`;
    }

    if (minPrice) {
        url += `minPrice=${minPrice}&`;
    }

    if (maxPrice) {
        url += `maxPrice=${maxPrice}`;
    }

    return axiosInstance.get(url);
};

const apartmentService = {
    getApartments,
    getApartmentById,
    getApartmentsByPurpose,
    searchApartments,
    filterApartments,
    createApartment,
    updateApartment,
    uploadImage,
    getApartmentImages,
    getOwnerApartments,
    deleteApartment,
    deleteImage,
    setCoverImage,
    approveApartment,
    rejectApartment,
    getAdminApartmentDetails,
    getApartmentsByArea,
    getHomepageApartments
};


export default apartmentService;