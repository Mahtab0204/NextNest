import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import apartmentService from "../../services/apartmentService";
import PromoteApartmentModal from "../../components/PromoteApartmentModal";

function MyApartments() {

    const [apartments, setApartments] = useState([]);
    const [loading, setLoading] = useState(true);

    const [showPromote, setShowPromote] = useState(false);
    const [selectedApartment, setSelectedApartment] = useState(null);

    useEffect(() => {
        loadApartments();
    }, []);

    const loadApartments = async () => {

        try {

            const user = JSON.parse(
                localStorage.getItem("user")
            );

            if (!user?.userId) {
                console.error("User not found.");
                return;
            }

            const response =
                await apartmentService.getOwnerApartments(
                    user.userId
                );

            setApartments(response.data);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }
    };

    const handleDelete = async (id) => {

        if (!window.confirm("Delete this apartment?")) {
            return;
        }

        try {

            await apartmentService.deleteApartment(id);

            alert("Apartment deleted successfully.");

            loadApartments();

        } catch (error) {

            console.error(error);

            alert("Failed to delete apartment.");

        }
    };

    const handlePromote = (apartment) => {

        setSelectedApartment(apartment);
        setShowPromote(true);

    };

    const closePromoteModal = () => {

        setShowPromote(false);
        setSelectedApartment(null);

    };

    return (

        <MainLayout>

            <div className="container-fluid py-4">

                {/* =========================
                    PAGE HEADER
                ========================== */}

                <div className="d-flex justify-content-between align-items-center mb-4">

                    <div>

                        <h2 className="fw-bold mb-1">
                            🏠 My Apartments
                        </h2>

                        <p className="text-muted mb-0">
                            Manage your property listings.
                        </p>

                    </div>

                    <Link
                        to="/owner/create-apartment"
                        className="btn btn-primary px-4"
                    >
                        + Add Apartment
                    </Link>

                </div>

                {/* =========================
                    LOADING
                ========================== */}

                {loading ? (

                    <div className="text-center mt-5">

                        <div
                            className="spinner-border text-primary"
                            role="status"
                        />

                        <p className="text-muted mt-3">
                            Loading your apartments...
                        </p>

                    </div>

                ) : apartments.length === 0 ? (

                    /* =========================
                       EMPTY STATE
                    ========================== */

                    <div className="card shadow-sm border-0 rounded-4 text-center p-5">

                        <div
                            className="mb-3"
                            style={{
                                fontSize: "60px"
                            }}
                        >
                            🏠
                        </div>

                        <h4 className="fw-bold">
                            No Apartments Yet
                        </h4>

                        <p className="text-muted mb-4">
                            You haven't added any properties yet.
                        </p>

                        <Link
                            to="/owner/create-apartment"
                            className="btn btn-primary px-4"
                        >
                            + Add Your First Apartment
                        </Link>

                    </div>

                ) : (

                    /* =========================
                       APARTMENT TABLE
                    ========================== */

                    <div className="card border-0 shadow-sm rounded-4">

                        <div className="card-header bg-white border-0 py-3">

                            <div className="d-flex justify-content-between align-items-center">

                                <div>

                                    <h5 className="fw-bold mb-1">
                                        Property Listings
                                    </h5>

                                    <small className="text-muted">
                                        {apartments.length}{" "}
                                        {apartments.length === 1
                                            ? "property"
                                            : "properties"}
                                    </small>

                                </div>

                            </div>

                        </div>

                        <div className="card-body p-0">

                            <div className="table-responsive">

                                <table className="table table-hover align-middle mb-0">

                                    <thead className="table-light">

                                        <tr>

                                            <th className="px-3">
                                                ID
                                            </th>

                                            <th>
                                                Property
                                            </th>

                                            <th>
                                                Purpose
                                            </th>

                                            <th>
                                                Price
                                            </th>

                                            <th>
                                                Status
                                            </th>

                                            <th>
                                                Approval
                                            </th>

                                            <th>
                                                Featured
                                            </th>

                                            <th>
                                                Expiry
                                            </th>

                                            <th>
                                                Rejection Reason
                                            </th>

                                            <th>
                                                Actions
                                            </th>

                                        </tr>

                                    </thead>

                                    <tbody>

                                        {apartments.map(
                                            (apartment) => (

                                                <tr
                                                    key={apartment.id}
                                                >

                                                    {/* ID */}

                                                    <td className="px-3 fw-semibold">

                                                        #{apartment.id}

                                                    </td>

                                                    {/* PROPERTY */}

                                                    <td>

                                                        <div>

                                                            <strong>
                                                                {
                                                                    apartment.title
                                                                }
                                                            </strong>

                                                            {apartment.featured && (

                                                                <span className="badge bg-warning text-dark ms-2">

                                                                    ⭐ Featured

                                                                </span>

                                                            )}

                                                        </div>

                                                    </td>

                                                    {/* PURPOSE */}

                                                    <td>

                                                        <span className="badge bg-info text-dark">

                                                            {
                                                                apartment.purpose
                                                            }

                                                        </span>

                                                    </td>

                                                    {/* PRICE */}

                                                    <td className="fw-semibold">

                                                        ৳{" "}
                                                        {apartment.price?.toLocaleString()}

                                                    </td>

                                                    {/* STATUS */}

                                                    <td>

                                                        <span
                                                            className={`badge ${
                                                                apartment.status ===
                                                                "AVAILABLE"
                                                                    ? "bg-success"
                                                                    : "bg-secondary"
                                                            }`}
                                                        >

                                                            {
                                                                apartment.status
                                                            }

                                                        </span>

                                                    </td>

                                                    {/* APPROVAL */}

                                                    <td>

                                                        <span
                                                            className={`badge ${
                                                                apartment.approvalStatus ===
                                                                "APPROVED"
                                                                    ? "bg-success"
                                                                    : apartment.approvalStatus ===
                                                                      "REJECTED"
                                                                    ? "bg-danger"
                                                                    : "bg-warning text-dark"
                                                            }`}
                                                        >

                                                            {
                                                                apartment.approvalStatus
                                                            }

                                                        </span>

                                                    </td>

                                                    {/* FEATURED */}

                                                    <td>

                                                        {apartment.featured ? (

                                                            <span className="badge bg-warning text-dark">

                                                                ⭐{" "}
                                                                {
                                                                    apartment.featuredPlan ||
                                                                    "Featured"
                                                                }

                                                            </span>

                                                        ) : (

                                                            <span className="text-muted">

                                                                Normal

                                                            </span>

                                                        )}

                                                    </td>

                                                    {/* EXPIRY */}

                                                    <td>

                                                        {apartment.featuredEndDate

                                                            ? new Date(
                                                                apartment.featuredEndDate
                                                            ).toLocaleDateString()

                                                            : "-"
                                                        }

                                                    </td>

                                                    {/* REJECTION */}

                                                    <td>

                                                        {apartment.approvalStatus ===
                                                        "REJECTED" ? (

                                                            <small className="text-danger fw-semibold">

                                                                {
                                                                    apartment.rejectionReason ||
                                                                    "No reason provided"
                                                                }

                                                            </small>

                                                        ) : (

                                                            <span className="text-muted">
                                                                —
                                                            </span>

                                                        )}

                                                    </td>

                                                    {/* ACTIONS */}

                                                    <td>

                                                        <div className="d-flex gap-2 flex-wrap">

                                                            {/* VIEW */}

                                                            <Link
                                                                to={`/apartments/${apartment.id}`}
                                                                className="btn btn-info btn-sm"
                                                            >
                                                                👁 View
                                                            </Link>

                                                            {/* EDIT */}

                                                            <Link
                                                                to={`/owner/apartments/edit/${apartment.id}`}
                                                                className="btn btn-warning btn-sm"
                                                            >
                                                                ✏ Edit
                                                            </Link>

                                                            {/* IMAGES */}

                                                            <Link
                                                                to={`/owner/apartments/${apartment.id}/images`}
                                                                className="btn btn-success btn-sm"
                                                            >
                                                                🖼 Images
                                                            </Link>

                                                            {/* PROMOTE */}

                                                            {apartment.approvalStatus ===
                                                            "APPROVED" && (

                                                                <button
                                                                    type="button"
                                                                    className={`btn btn-sm ${
                                                                        apartment.featured
                                                                            ? "btn-secondary"
                                                                            : "btn-primary"
                                                                    }`}
                                                                    onClick={() =>
                                                                        handlePromote(
                                                                            apartment
                                                                        )
                                                                    }
                                                                >

                                                                    {apartment.featured
                                                                        ? "⭐ Featured"
                                                                        : "🚀 Promote"
                                                                    }

                                                                </button>

                                                            )}

                                                            {/* DELETE */}

                                                            <button
                                                                type="button"
                                                                className="btn btn-danger btn-sm"
                                                                onClick={() =>
                                                                    handleDelete(
                                                                        apartment.id
                                                                    )
                                                                }
                                                            >
                                                                🗑 Delete
                                                            </button>

                                                        </div>

                                                    </td>

                                                </tr>

                                            )
                                        )}

                                    </tbody>

                                </table>

                            </div>

                        </div>

                    </div>

                )}

                {/* =========================
                    PROMOTE MODAL
                ========================== */}

                {showPromote &&
                    selectedApartment && (

                        <PromoteApartmentModal

                            apartment={
                                selectedApartment
                            }

                            onClose={
                                closePromoteModal
                            }

                            onSuccess={() => {

                                closePromoteModal();

                                loadApartments();

                            }}

                        />

                    )}

            </div>

        </MainLayout>

    );

}

export default MyApartments;