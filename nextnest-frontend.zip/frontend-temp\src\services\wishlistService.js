import axiosInstance from "../api/axios";

const addToWishlist = (apartmentId) => {
    return axiosInstance.post(
        `/wishlist/${apartmentId}`
    );
};

const removeFromWishlist = (apartmentId) => {
    return axiosInstance.delete(
        `/wishlist/${apartmentId}`
    );
};

const getMyWishlist = () => {
    return axiosInstance.get(
        "/wishlist/my"
    );
};

const isWishlisted = (apartmentId) => {
    return axiosInstance.get(
        `/wishlist/check/${apartmentId}`
    );
};


const wishlistService = {
    addToWishlist,
    removeFromWishlist,
    getMyWishlist,
    isWishlisted
};

export default wishlistService;