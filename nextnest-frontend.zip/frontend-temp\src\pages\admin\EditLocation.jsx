import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import locationService from "../../services/locationService";

function EditLocation() {

    const { id } = useParams();

    const navigate =
        useNavigate();

    const [loading, setLoading] =
        useState(true);

    const [formData, setFormData] =
        useState({

            city: "",
            area: "",
            subArea: ""

        });

    useEffect(() => {

        loadLocation();

    }, [id]);

    const loadLocation = async () => {

        try {

            const response =
                await locationService
                    .getLocationById(id);

            setFormData(
                response.data
            );

        } catch (error) {

            console.error(error);

            alert(
                "Failed to load location"
            );

        } finally {

            setLoading(false);
        }
    };

    const handleChange = (e) => {

        const {
            name,
            value
        } = e.target;

        setFormData({

            ...formData,

            [name]: value
        });
    };

    const handleSubmit =
        async (e) => {

            e.preventDefault();

            try {

                await locationService
                    .updateLocation(
                        id,
                        formData
                    );

                alert(
                    "Location updated successfully"
                );

                navigate(
                    "/admin/locations"
                );

            } catch (error) {

                console.error(error);

                alert(
                    "Failed to update location"
                );
            }
        };

    if (loading) {

        return (

            <MainLayout>

                <div className="text-center mt-5">

                    <div className="spinner-border text-primary" />

                </div>

            </MainLayout>

        );
    }

    return (

        <MainLayout>

            <div className="container">

                <div className="card shadow">

                    <div className="card-body">

                        <h2 className="mb-4">
                            Edit Location
                        </h2>

                        <form
                            onSubmit={handleSubmit}
                        >

                            <div className="mb-3">

                                <label>
                                    City
                                </label>

                                <input
                                    type="text"
                                    name="city"
                                    className="form-control"
                                    value={formData.city || ""}
                                    onChange={handleChange}
                                    required
                                />

                            </div>

                            <div className="mb-3">

                                <label>
                                    Area
                                </label>

                                <input
                                    type="text"
                                    name="area"
                                    className="form-control"
                                    value={formData.area || ""}
                                    onChange={handleChange}
                                    required
                                />

                            </div>

                            <div className="mb-4">

                                <label>
                                    Sub Area
                                </label>

                                <input
                                    type="text"
                                    name="subArea"
                                    className="form-control"
                                    value={formData.subArea || ""}
                                    onChange={handleChange}
                                />

                            </div>

                            <button
                                type="submit"
                                className="btn btn-primary me-2"
                            >
                                Update Location
                            </button>

                            <button
                                type="button"
                                className="btn btn-secondary"
                                onClick={() =>
                                    navigate(
                                        "/admin/locations"
                                    )
                                }
                            >
                                Cancel
                            </button>

                        </form>

                    </div>

                </div>

            </div>

        </MainLayout>

    );
}

export default EditLocation;