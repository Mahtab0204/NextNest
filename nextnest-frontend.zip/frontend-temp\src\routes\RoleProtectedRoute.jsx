import { Navigate } from "react-router-dom";
import useAuth from "../hooks/useAuth";

function RoleProtectedRoute({
    children,
    allowedRoles
}) {

    const {
        user,
        loading
    } = useAuth();

    console.log("User:", user);
    console.log("Loading:", loading);

    if (loading) {

        return (
            <div className="text-center mt-5">
                Loading...
            </div>
        );
    }

    if (!user) {

        return (
            <Navigate
                to="/login"
                replace
            />
        );
    }

    if (
        !allowedRoles.includes(
            user.role
        )
    ) {

        return (
            <Navigate
                to="/"
                replace
            />
        );
    }

    return children;
}

export default RoleProtectedRoute;