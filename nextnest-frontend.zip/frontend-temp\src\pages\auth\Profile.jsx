import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import MainLayout from "../../layouts/MainLayout";
import api from "../../api/axios";

function Profile() {
    const [profile, setProfile] = useState({
        fullName: "", email: "", phone: "", address: "", gender: "",
        dateOfBirth: "", profileImage: "", role: "", verified: false,
        accountStatus: ""
    });

    const [selectedImage, setSelectedImage] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [changingPassword, setChangingPassword] = useState(false);

    const [passwordData, setPasswordData] = useState({
        currentPassword: "", newPassword: "", confirmPassword: ""
    });

    useEffect(() => { loadProfile(); }, []);

    const loadProfile = async () => {
        try {
            const response = await api.get("/users/me");
            setProfile(response.data);
        } catch (error) {
            console.error(error);
            toast.error("Failed to load profile");
        } finally {
            setLoading(false);
        }
    };

    const handleChange = e => {
        const { name, value } = e.target;
        setProfile(prev => ({ ...prev, [name]: value }));
    };

    const handleUpdateProfile = async e => {
        e.preventDefault();
        try {
            setSaving(true);
            await api.put("/users/me", {
                fullName: profile.fullName,
                phone: profile.phone,
                address: profile.address,
                gender: profile.gender,
                dateOfBirth: profile.dateOfBirth
            });
            toast.success("Profile updated successfully");
            await loadProfile();
        } catch (error) {
            console.error(error);
            toast.error(error?.response?.data?.message || "Failed to update profile");
        } finally {
            setSaving(false);
        }
    };

    const handleImageUpload = async () => {
        if (!selectedImage) return toast.warning("Select an image first");

        try {
            setUploading(true);
            const formData = new FormData();
            formData.append("image", selectedImage);

            await api.post("/users/me/profile-image", formData, {
                headers: { "Content-Type": "multipart/form-data" }
            });

            toast.success("Profile photo updated");
            setSelectedImage(null);
            await loadProfile();
        } catch (error) {
            console.error(error);
            toast.error("Failed to upload image");
        } finally {
            setUploading(false);
        }
    };

    const handlePasswordChange = async e => {
        e.preventDefault();

        if (passwordData.newPassword !== passwordData.confirmPassword)
            return toast.error("Passwords do not match");

        if (passwordData.newPassword.length < 6)
            return toast.error("Password must contain at least 6 characters");

        try {
            setChangingPassword(true);

            await api.put("/users/me/change-password", passwordData);

            toast.success("Password changed successfully");
            setPasswordData({
                currentPassword: "", newPassword: "", confirmPassword: ""
            });
        } catch (error) {
            console.error(error);
            toast.error(
                error?.response?.data?.message || "Failed to change password"
            );
        } finally {
            setChangingPassword(false);
        }
    };

    const completionFields = [
        profile.fullName,
        profile.phone,
        profile.address,
        profile.gender,
        profile.dateOfBirth,
        profile.profileImage
    ];

    const completion = Math.round(
        completionFields.filter(Boolean).length /
        completionFields.length * 100
    );

    if (loading) {
        return (
            <MainLayout>
                <div className="container py-5 text-center">
                    <div className="spinner-border text-primary" />
                    <p className="text-muted mt-3">Loading your profile...</p>
                </div>
            </MainLayout>
        );
    }

    return (
        <MainLayout>
            <div className="container py-4 pb-5">

                {/* Header */}
                <div className="mb-4">
                    <h2 className="fw-bold mb-1">My Profile</h2>
                    <p className="text-muted mb-0">
                        Manage your personal information and account security.
                    </p>
                </div>

                <div className="row g-4">

                    {/* LEFT PROFILE CARD */}
                    <div className="col-lg-4">

                        <div className="card border-0 shadow-sm rounded-4 overflow-hidden">

                            <div
                                className="position-relative"
                                style={{
                                    height: "110px",
                                    background:
                                        "linear-gradient(135deg,#0d6efd,#6f42c1)"
                                }}
                            />

                            <div className="card-body text-center pt-0">

                                {/* Avatar */}
                                <div
                                    className="position-relative d-inline-block"
                                    style={{ marginTop: "-65px" }}
                                >
                                    <img
                                        src={
                                            profile.profileImage ||
                                            "https://via.placeholder.com/180"
                                        }
                                        alt="Profile"
                                        className="rounded-circle border border-4 border-white shadow"
                                        style={{
                                            width: "130px",
                                            height: "130px",
                                            objectFit: "cover"
                                        }}
                                    />

                                    <label
                                        htmlFor="profileImage"
                                        className="position-absolute bottom-0 end-0 bg-primary text-white rounded-circle d-flex align-items-center justify-content-center shadow"
                                        style={{
                                            width: "38px",
                                            height: "38px",
                                            cursor: "pointer"
                                        }}
                                        title="Change photo"
                                    >
                                        📷
                                    </label>

                                    <input
                                        id="profileImage"
                                        type="file"
                                        accept="image/*"
                                        hidden
                                        onChange={e =>
                                            setSelectedImage(
                                                e.target.files?.[0] || null
                                            )
                                        }
                                    />
                                </div>

                                <h4 className="fw-bold mt-3 mb-1">
                                    {profile.fullName || "User"}
                                </h4>

                                <p className="text-muted mb-2">
                                    {profile.email}
                                </p>

                                <div className="d-flex justify-content-center gap-2 mb-4 flex-wrap">
                                    <span className="badge bg-primary-subtle text-primary px-3 py-2">
                                        {profile.role || "USER"}
                                    </span>

                                    <span className={`badge px-3 py-2 ${
                                        profile.verified
                                            ? "bg-success-subtle text-success"
                                            : "bg-warning-subtle text-warning-emphasis"
                                    }`}>
                                        {profile.verified
                                            ? "✓ Verified"
                                            : "⚠ Not Verified"}
                                    </span>
                                </div>

                                {selectedImage && (
                                    <div className="alert alert-light border small">
                                        <strong>{selectedImage.name}</strong>
                                        <button
                                            className="btn btn-primary btn-sm w-100 mt-2"
                                            onClick={handleImageUpload}
                                            disabled={uploading}
                                        >
                                            {uploading
                                                ? "Uploading..."
                                                : "Upload New Photo"}
                                        </button>
                                    </div>
                                )}

                                {/* Account Status */}
                                <div className="text-start border-top pt-3">
                                    <div className="d-flex justify-content-between mb-3">
                                        <span className="text-muted">
                                            Account Status
                                        </span>
                                        <span className="badge bg-success-subtle text-success">
                                            ● {profile.accountStatus || "ACTIVE"}
                                        </span>
                                    </div>

                                    <div className="d-flex justify-content-between">
                                        <span className="text-muted">
                                            Member Email
                                        </span>
                                        <strong className="small">
                                            {profile.email}
                                        </strong>
                                    </div>
                                </div>

                            </div>
                        </div>

                        {/* Profile Completion */}
                        <div className="card border-0 shadow-sm rounded-4 mt-4">
                            <div className="card-body">

                                <div className="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <h6 className="fw-bold mb-1">
                                            Profile Completion
                                        </h6>
                                        <small className="text-muted">
                                            Complete your profile
                                        </small>
                                    </div>

                                    <strong className="text-primary">
                                        {completion}%
                                    </strong>
                                </div>

                                <div
                                    className="progress"
                                    style={{ height: "8px" }}
                                >
                                    <div
                                        className="progress-bar"
                                        style={{ width: `${completion}%` }}
                                    />
                                </div>

                                {completion < 100 && (
                                    <small className="text-muted d-block mt-2">
                                        Add missing information to complete
                                        your profile.
                                    </small>
                                )}

                            </div>
                        </div>

                    </div>

                    {/* RIGHT SIDE */}
                    <div className="col-lg-8">

                        {/* Personal Information */}
                        <div className="card border-0 shadow-sm rounded-4 mb-4">
                            <div className="card-body p-4">

                                <div className="d-flex align-items-center mb-4">
                                    <div
                                        className="bg-primary-subtle text-primary rounded-3 d-flex align-items-center justify-content-center me-3"
                                        style={{
                                            width: "45px",
                                            height: "45px"
                                        }}
                                    >
                                        👤
                                    </div>

                                    <div>
                                        <h5 className="fw-bold mb-0">
                                            Personal Information
                                        </h5>
                                        <small className="text-muted">
                                            Update your personal details
                                        </small>
                                    </div>
                                </div>

                                <form onSubmit={handleUpdateProfile}>

                                    <div className="row">

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                Full Name
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                name="fullName"
                                                value={profile.fullName || ""}
                                                onChange={handleChange}
                                                placeholder="Enter your name"
                                            />
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                Phone Number
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                name="phone"
                                                value={profile.phone || ""}
                                                onChange={handleChange}
                                                placeholder="01XXXXXXXXX"
                                            />
                                        </div>

                                        <div className="col-12 mb-3">
                                            <label className="form-label fw-semibold">
                                                Address
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                name="address"
                                                value={profile.address || ""}
                                                onChange={handleChange}
                                                placeholder="Enter your address"
                                            />
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                Gender
                                            </label>
                                            <select
                                                className="form-select"
                                                name="gender"
                                                value={profile.gender || ""}
                                                onChange={handleChange}
                                            >
                                                <option value="">
                                                    Select Gender
                                                </option>
                                                <option value="MALE">Male</option>
                                                <option value="FEMALE">Female</option>
                                            </select>
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                Date of Birth
                                            </label>
                                            <input
                                                type="date"
                                                className="form-control"
                                                name="dateOfBirth"
                                                value={profile.dateOfBirth || ""}
                                                onChange={handleChange}
                                            />
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                Email Address
                                            </label>
                                            <input
                                                type="email"
                                                className="form-control bg-light"
                                                value={profile.email || ""}
                                                disabled
                                            />
                                            <small className="text-muted">
                                                Email cannot be changed.
                                            </small>
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                Account Role
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control bg-light"
                                                value={profile.role || ""}
                                                disabled
                                            />
                                        </div>

                                    </div>

                                    <div className="d-flex justify-content-end mt-2">
                                        <button
                                            type="submit"
                                            className="btn btn-primary px-4 rounded-3"
                                            disabled={saving}
                                        >
                                            {saving ? (
                                                <>
                                                    <span className="spinner-border spinner-border-sm me-2" />
                                                    Saving...
                                                </>
                                            ) : (
                                                <>✓ Save Changes</>
                                            )}
                                        </button>
                                    </div>

                                </form>
                            </div>
                        </div>

                        {/* Security */}
                        <div className="card border-0 shadow-sm rounded-4">
                            <div className="card-body p-4">

                                <div className="d-flex align-items-center mb-4">
                                    <div
                                        className="bg-warning-subtle text-warning-emphasis rounded-3 d-flex align-items-center justify-content-center me-3"
                                        style={{
                                            width: "45px",
                                            height: "45px"
                                        }}
                                    >
                                        🔐
                                    </div>

                                    <div>
                                        <h5 className="fw-bold mb-0">
                                            Account Security
                                        </h5>
                                        <small className="text-muted">
                                            Keep your account protected
                                        </small>
                                    </div>
                                </div>

                                <form onSubmit={handlePasswordChange}>

                                    <div className="row">

                                        <div className="col-12 mb-3">
                                            <label className="form-label fw-semibold">
                                                Current Password
                                            </label>
                                            <input
                                                type="password"
                                                className="form-control"
                                                value={passwordData.currentPassword}
                                                onChange={e =>
                                                    setPasswordData(prev => ({
                                                        ...prev,
                                                        currentPassword:
                                                            e.target.value
                                                    }))
                                                }
                                                required
                                                placeholder="Enter current password"
                                            />
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                New Password
                                            </label>
                                            <input
                                                type="password"
                                                className="form-control"
                                                value={passwordData.newPassword}
                                                onChange={e =>
                                                    setPasswordData(prev => ({
                                                        ...prev,
                                                        newPassword:
                                                            e.target.value
                                                    }))
                                                }
                                                required
                                                placeholder="Minimum 6 characters"
                                            />
                                        </div>

                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-semibold">
                                                Confirm Password
                                            </label>
                                            <input
                                                type="password"
                                                className="form-control"
                                                value={passwordData.confirmPassword}
                                                onChange={e =>
                                                    setPasswordData(prev => ({
                                                        ...prev,
                                                        confirmPassword:
                                                            e.target.value
                                                    }))
                                                }
                                                required
                                                placeholder="Repeat new password"
                                            />
                                        </div>

                                    </div>

                                    <div className="d-flex justify-content-end">
                                        <button
                                            type="submit"
                                            className="btn btn-warning px-4 rounded-3"
                                            disabled={changingPassword}
                                        >
                                            {changingPassword ? (
                                                <>
                                                    <span className="spinner-border spinner-border-sm me-2" />
                                                    Updating...
                                                </>
                                            ) : (
                                                <>🔑 Change Password</>
                                            )}
                                        </button>
                                    </div>

                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </MainLayout>
    );
}

export default Profile;