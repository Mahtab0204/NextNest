import { Link } from "react-router-dom";

function CustomerDashboard() {
    const actions = [
        {
            icon: "👤",
            title: "My Profile",
            description: "Manage your personal information, contact details and account settings.",
            link: "/profile",
            button: "Open Profile",
            color: "primary"
        },
        {
            icon: "❤️",
            title: "My Wishlist",
            description: "View and manage apartments you have saved for later.",
            link: "/customer/wishlist",
            button: "View Wishlist",
            color: "danger"
        },
        {
            icon: "🏠",
            title: "Browse Apartments",
            description: "Discover available apartments for rent and sale that match your needs.",
            link: "/apartments",
            button: "Explore Apartments",
            color: "success"
        },
        {
            icon: "💬",
            title: "My Inquiries",
            description: "Track your inquiries and communicate with apartment owners.",
            link: "/customer/inquiries",
            button: "View Inquiries",
            color: "info"
        },
        {
            icon: "🕘",
            title: "Recently Viewed",
            description: "Quickly access apartments you have recently explored.",
            link: "/customer/recently-viewed",
            button: "View History",
            color: "dark"
        },
        {
            icon: "🔍",
            title: "Find Your Home",
            description: "Search and filter apartments based on price, location and preferences.",
            link: "/apartments",
            button: "Start Searching",
            color: "primary"
        }
    ];

    return (
        <div className="container py-5">

            {/* Welcome Header */}
            <div
                className="rounded-4 shadow-sm p-4 p-md-5 mb-4 text-white"
                style={{
                    background: "linear-gradient(135deg, #0d6efd 0%, #4f46e5 100%)"
                }}
            >
                <div className="row align-items-center">

                    <div className="col-md-8">
                        <span className="badge bg-white text-primary px-3 py-2 rounded-pill mb-3">
                            🏠 NextNest
                        </span>

                        <h1 className="fw-bold mb-2">
                            Welcome back!
                        </h1>

                        <p className="mb-0 opacity-75 fs-5">
                            Find your perfect apartment, manage your inquiries
                            and keep your account up to date.
                        </p>
                    </div>

                    <div className="col-md-4 text-center mt-4 mt-md-0">
                        <div
                            className="bg-white bg-opacity-25 rounded-circle d-inline-flex align-items-center justify-content-center"
                            style={{
                                width: "130px",
                                height: "130px",
                                fontSize: "62px"
                            }}
                        >
                            🏡
                        </div>
                    </div>

                </div>
            </div>

            {/* Quick Overview */}
            <div className="row g-3 mb-5">

                <div className="col-md-4">
                    <div className="card border-0 shadow-sm rounded-4 h-100">
                        <div className="card-body p-4 d-flex align-items-center">
                            <div
                                className="rounded-3 bg-primary bg-opacity-10 d-flex align-items-center justify-content-center me-3"
                                style={{
                                    width: "55px",
                                    height: "55px",
                                    fontSize: "25px"
                                }}
                            >
                                🏢
                            </div>
                            <div>
                                <small className="text-muted">
                                    Explore
                                </small>
                                <h5 className="fw-bold mb-0">
                                    Apartments
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="card border-0 shadow-sm rounded-4 h-100">
                        <div className="card-body p-4 d-flex align-items-center">
                            <div
                                className="rounded-3 bg-success bg-opacity-10 d-flex align-items-center justify-content-center me-3"
                                style={{
                                    width: "55px",
                                    height: "55px",
                                    fontSize: "25px"
                                }}
                            >
                                💬
                            </div>
                            <div>
                                <small className="text-muted">
                                    Track
                                </small>
                                <h5 className="fw-bold mb-0">
                                    My Inquiries
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="card border-0 shadow-sm rounded-4 h-100">
                        <div className="card-body p-4 d-flex align-items-center">
                            <div
                                className="rounded-3 bg-warning bg-opacity-10 d-flex align-items-center justify-content-center me-3"
                                style={{
                                    width: "55px",
                                    height: "55px",
                                    fontSize: "25px"
                                }}
                            >
                                👤
                            </div>
                            <div>
                                <small className="text-muted">
                                    Account
                                </small>
                                <h5 className="fw-bold mb-0">
                                    My Profile
                                </h5>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            {/* Quick Actions */}
            <div className="mb-4">
                <h4 className="fw-bold mb-1">
                    Quick Actions
                </h4>

                <p className="text-muted mb-0">
                    Everything you need to manage your NextNest experience.
                </p>
            </div>

            {/* Action Cards */}
            <div className="row g-4">

                {actions.map((action, index) => (
                    <div
                        className="col-md-6 col-lg-4"
                        key={index}
                    >
                        <div
                            className="card border-0 shadow-sm rounded-4 h-100"
                            style={{
                                transition: "all 0.2s ease"
                            }}
                        >
                            <div className="card-body p-4 d-flex flex-column">

                                <div
                                    className={`rounded-4 bg-${action.color} bg-opacity-10 d-flex align-items-center justify-content-center mb-4`}
                                    style={{
                                        width: "65px",
                                        height: "65px",
                                        fontSize: "30px"
                                    }}
                                >
                                    {action.icon}
                                </div>

                                <h4 className="fw-bold mb-2">
                                    {action.title}
                                </h4>

                                <p className="text-muted flex-grow-1">
                                    {action.description}
                                </p>

                                <Link
                                    to={action.link}
                                    className={`btn btn-${action.color} rounded-3 px-4 align-self-start`}
                                >
                                    {action.button} →
                                </Link>

                            </div>
                        </div>
                    </div>
                ))}

            </div>

            {/* Getting Started */}
            <div className="card border-0 shadow-sm rounded-4 mt-5">

                <div className="card-body p-4 p-md-5">

                    <div className="row align-items-center">

                        <div className="col-md-8">

                            <span className="badge bg-primary bg-opacity-10 text-primary px-3 py-2 rounded-pill mb-3">
                                GET STARTED
                            </span>

                            <h4 className="fw-bold mb-2">
                                Looking for your next home?
                            </h4>

                            <p className="text-muted mb-md-0">
                                Browse available properties, compare your
                                options and contact owners directly through
                                NextNest.
                            </p>

                        </div>

                        <div className="col-md-4 text-md-end mt-4 mt-md-0">

                            <Link
                                to="/apartments"
                                className="btn btn-primary btn-lg rounded-3 px-4"
                            >
                                Find a Home 🏠
                            </Link>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    );
}

export default CustomerDashboard;