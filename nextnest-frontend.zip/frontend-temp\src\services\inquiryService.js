import api from "../api/axios";

const createInquiry = (data) => {
    return api.post("/inquiries", data);
};

const getMyInquiries = () => {
    return api.get("/inquiries/my");
};

const getOwnerInquiries = () => {
    return api.get("/inquiries/owner");
};

const updateInquiryStatus = (
    inquiryId,
    status
) => {
    return api.patch(
        `/inquiries/${inquiryId}/status`,
        { status }
    );
};

const inquiryService = {
    createInquiry,
    getMyInquiries,
    getOwnerInquiries,
    updateInquiryStatus
};

export default inquiryService;