
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance from '../../api/axios';

import MainLayout from "../../layouts/MainLayout";
import ApartmentCard from "../../components/ApartmentCard";

import apartmentService from "../../services/apartmentService";
import locationService from "../../services/locationService";

import "../../assets/css/Home.css";

function Home() {

    const navigate = useNavigate();

    const [apartments, setApartments] = useState([]);
    const [locations, setLocations] = useState([]);

    const [keyword, setKeyword] = useState("");
    const [area, setArea] = useState("");
    const [purpose, setPurpose] = useState("RENT");
    const [bedrooms, setBedrooms] = useState("");
    const [aiQuery, setAiQuery] = useState("");
    const [isSearchingAi, setIsSearchingAi] = useState(false);
    const [searchMode, setSearchMode] = useState("ai"); 

    // Hero background images
    const heroImages = [
        "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=2000&q=85",
        "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=2000&q=85",
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=2000&q=85",
        "https://images.unsplash.com/photo-1600607688969-a5bfcd646154?auto=format&fit=crop&w=2000&q=85",
        "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=2000&q=85"
    ];

    const [currentImage, setCurrentImage] = useState(0);

    // Automatically change hero background
    useEffect(() => {

        const interval = setInterval(() => {

            setCurrentImage(
                previous =>
                    (previous + 1) % heroImages.length
            );

        }, 5000);

        return () => clearInterval(interval);

    }, []);

    useEffect(() => {

        loadApartments();
        loadLocations();

    }, []);

    const loadApartments = async () => {

    try {

        const res =
            await apartmentService.getHomepageApartments();

        setApartments(
            res.data || []
        );

    } catch (err) {

        console.error(
            "Failed to load apartments",
            err
        );

    }
};

    const loadLocations = async () => {

        try {

            const res =
                await locationService.getLocations();

            setLocations(
                res.data || []
            );

        } catch (err) {

            console.error(err);

        }

    };

    const handleSearch = () => {

        const params = new URLSearchParams();

        if (keyword.trim()) {

            params.append(
                "keyword",
                keyword.trim()
            );

        }

        if (area) {

            params.append(
                "area",
                area
            );

        }

        if (bedrooms) {

            params.append(
                "bedrooms",
                bedrooms
            );

        }

        params.append(
            "purpose",
            purpose
        );

        const targetPage =
            purpose === "RENT"
                ? "/rent"
                : "/buy";

        navigate(
            `${targetPage}?${params.toString()}`
        );

    };

    const handleAiSearch = async () => {
    if (!aiQuery.trim()) return; 
    setIsSearchingAi(true);
    
    try {
        const response = await axiosInstance.get(`/v1/ai/smart-search?query=${aiQuery}`);
        const aiFilters = response.data;
        
        console.log("AI Extracted Filters:", aiFilters);
        
       // Build the URL parameters based on what the AI extracted
const params = new URLSearchParams();

if (aiFilters.bedrooms) params.append("bedrooms", aiFilters.bedrooms);
if (aiFilters.maxPrice) params.append("maxPrice", aiFilters.maxPrice);
if (aiFilters.minPrice) params.append("minPrice", aiFilters.minPrice);
if (aiFilters.furnishing) params.append("furnishing", aiFilters.furnishing.toUpperCase());
if (aiFilters.locationKeyword) params.append("area", aiFilters.locationKeyword);


const queryText = aiQuery.toLowerCase();
const targetRoute = (queryText.includes("buy") || queryText.includes("sale") || queryText.includes("purchase")) 
    ? "/buy" 
    : "/rent";

navigate(`${targetRoute}?${params.toString()}`);
        
    } catch (error) {
        console.error("AI Smart Search failed", error);
    } finally {
        setIsSearchingAi(false);
    }
};

    const uniqueAreas = [
        ...new Set(
            locations
                .map(location => location.area)
                .filter(Boolean)
        )
    ];

    return (

        <MainLayout>

         {/* ================= HERO ================= */}
        <section
            className="home-hero position-relative"
            style={{
                backgroundImage: `
                    linear-gradient(
                        rgba(7, 18, 38, 0.72),
                        rgba(7, 18, 38, 0.55)
                    ),
                    url("${heroImages[currentImage]}")
                `,
                backgroundSize: "cover",
                backgroundPosition: "center",
                paddingBottom: "80px" // Extra padding to accommodate the overlapping search box
            }}
        >
            <div className="hero-overlay">
                <div className="container">
                    <div className="hero-content text-center py-5">
                        <span className="hero-badge mb-3 d-inline-block">
                            🏡 FIND YOUR NEXT HOME
                        </span>
                        <h1 className="display-4 fw-bold text-white mb-3">
                            Find a Place You'll
                            <span className="text-primary"> Love to Live</span>
                        </h1>
                        <p className="lead text-light mb-4">
                            Discover beautiful apartments,
                            trusted owners and the perfect
                            place to call home.
                        </p>
                        <div className="hero-buttons d-flex justify-content-center gap-3">
                            <Link to="/apartments" className="btn btn-primary btn-lg px-4 shadow-sm">
                                🏠 Explore Properties
                            </Link>
                            <Link to="/register" className="btn btn-outline-light btn-lg px-4">
                                List Your Property
                            </Link>
                        </div>
                    </div>
                </div>

                {/* Background indicators */}
                <div className="hero-indicators">
                    {heroImages.map((_, index) => (
                        <button
                            key={index}
                            className={index === currentImage ? "active" : ""}
                            onClick={() => setCurrentImage(index)}
                        />
                    ))}
                </div>
            </div>
        </section>

        {/* ================= COMPACT OVERLAPPING SEARCH BOX ================= */}
        <div className="container position-relative" style={{ marginTop: "-60px", zIndex: 10 }}>
            <div className="hero-search shadow-lg rounded-4 p-4 bg-white border border-light">
                
                {/* Search Mode Toggle Tabs */}
                <div className="d-flex justify-content-center mb-4">
                    <ul className="nav nav-pills bg-light p-1 rounded-pill shadow-sm" role="tablist">
                        <li className="nav-item" role="presentation">
                            <button
                                className={`nav-link rounded-pill fw-bold px-4 ${searchMode === 'ai' ? 'active bg-primary text-white' : 'text-secondary'}`}
                                onClick={() => setSearchMode('ai')}
                                type="button"
                            >
                                ✨ AI Smart Search
                            </button>
                        </li>
                        <li className="nav-item" role="presentation">
                            <button
                                className={`nav-link rounded-pill fw-bold px-4 ${searchMode === 'standard' ? 'active bg-dark text-white' : 'text-secondary'}`}
                                onClick={() => setSearchMode('standard')}
                                type="button"
                            >
                                🔍 Standard Filters
                            </button>
                        </li>
                    </ul>
                </div>

                {/* AI Search View */}
                {searchMode === 'ai' && (
                    <div className="ai-search-section animate__animated animate__fadeIn">
                        <div className="input-group input-group-lg shadow-sm rounded-pill overflow-hidden border border-primary">
                            <input
                                type="text"
                                className="form-control border-0 fs-6 ps-4"
                                placeholder="E.g., Find me a furnished 2-bedroom flat under 30,000 BDT..."
                                value={aiQuery}
                                onChange={(e) => setAiQuery(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()}
                                disabled={isSearchingAi}
                            />
                            <button
                                className="btn btn-primary px-5 fw-bold"
                                type="button"
                                onClick={handleAiSearch}
                                disabled={isSearchingAi || !aiQuery.trim()}
                            >
                                {isSearchingAi ? (
                                    <>
                                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                        Thinking...
                                    </>
                                ) : (
                                    "Ask AI"
                                )}
                            </button>
                        </div>
                    </div>
                )}

                {/* Standard Search View */}
                {searchMode === 'standard' && (
                    <div className="standard-search-section animate__animated animate__fadeIn">
                        <div className="row g-3">
                            <div className="col-lg-3 col-md-6">
                                <div className="search-input input-group bg-light rounded-3 p-1">
                                    <span className="input-group-text bg-transparent border-0">🏠</span>
                                    <input
                                        type="text"
                                        className="form-control bg-transparent border-0 shadow-none ps-0"
                                        placeholder="Apartment name..."
                                        value={keyword}
                                        onChange={(e) => setKeyword(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="col-lg-3 col-md-6">
                                <select
                                    className="form-select bg-light border-0 rounded-3 py-3 shadow-none"
                                    value={area}
                                    onChange={(e) => setArea(e.target.value)}
                                >
                                    <option value="">📍 All Areas</option>
                                    {uniqueAreas.map(area => (
                                        <option key={area} value={area}>{area}</option>
                                    ))}
                                </select>
                            </div>

                            <div className="col-lg-2 col-md-6">
                                <select
                                    className="form-select bg-light border-0 rounded-3 py-3 shadow-none"
                                    value={purpose}
                                    onChange={(e) => setPurpose(e.target.value)}
                                >
                                    <option value="RENT">🏠 Rent</option>
                                    <option value="SALE">💰 Buy</option>
                                </select>
                            </div>

                            <div className="col-lg-2 col-md-6">
                                <select
                                    className="form-select bg-light border-0 rounded-3 py-3 shadow-none"
                                    value={bedrooms}
                                    onChange={(e) => setBedrooms(e.target.value)}
                                >
                                    <option value="">🛏 Any Beds</option>
                                    <option value="1">1 Bed</option>
                                    <option value="2">2 Beds</option>
                                    <option value="3">3 Beds</option>
                                    <option value="4">4+ Beds</option>
                                </select>
                            </div>

                            <div className="col-lg-2 col-md-12">
                                <button
                                    className="btn btn-dark w-100 py-3 rounded-3 fw-bold h-100 shadow-sm"
                                    onClick={handleSearch}
                                >
                                    Search
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>


            {/* ================= TRUST STATS ================= */}

            <section className="container home-stats">

                <div className="row g-3">

                    <div className="col-lg-3 col-md-6">

                        <div className="stat-card">

                            <div className="stat-icon blue">
                                🏢
                            </div>

                            <div>
                                <h3>500+</h3>
                                <p>Active Listings</p>
                            </div>

                        </div>

                    </div>

                    <div className="col-lg-3 col-md-6">

                        <div className="stat-card">

                            <div className="stat-icon green">
                                👨‍💼
                            </div>

                            <div>
                                <h3>100+</h3>
                                <p>Property Owners</p>
                            </div>

                        </div>

                    </div>

                    <div className="col-lg-3 col-md-6">

                        <div className="stat-card">

                            <div className="stat-icon red">
                                👥
                            </div>

                            <div>
                                <h3>1K+</h3>
                                <p>Happy Customers</p>
                            </div>

                        </div>

                    </div>

                    <div className="col-lg-3 col-md-6">

                        <div className="stat-card">

                            <div className="stat-icon orange">
                                📍
                            </div>

                            <div>
                                <h3>50+</h3>
                                <p>Locations</p>
                            </div>

                        </div>

                    </div>

                </div>

            </section>


            {/* ================= POPULAR LOCATIONS ================= */}

            <section className="container home-section">

                <div className="section-heading">

                    <div>

                        <span>
                            EXPLORE AREAS
                        </span>

                        <h2>
                            Popular Locations
                        </h2>

                        <p>
                            Discover properties in the most
                            desirable areas.
                        </p>

                    </div>

                    <Link
                        to="/apartments"
                        className="btn btn-outline-primary"
                    >
                        View All →
                    </Link>

                </div>

                <div className="row g-4">

                    {uniqueAreas
                        .slice(0, 8)
                        .map(
                            area => (

                                <div
                                    className="col-lg-3 col-md-6"
                                    key={area}
                                >

                                    <div
                                        className="location-card"
                                        onClick={() =>
                                            navigate(
                                                `/apartments?area=${encodeURIComponent(area)}`
                                            )
                                        }
                                    >

                                        <div className="location-image">

                                            <img
                                                src={`https://images.unsplash.com/photo-1444723121867-7a241cacace9?auto=format&fit=crop&w=700&q=80`}
                                                alt={area}
                                            />

                                            <div className="location-overlay">

                                                <span>
                                                    📍
                                                </span>

                                                <h5>
                                                    {area}
                                                </h5>

                                                <small>
                                                    Explore Properties →
                                                </small>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            )
                        )
                    }

                </div>

            </section>


            {/* ================= FEATURED APARTMENTS ================= */}

            <section className="container home-section">

                <div className="section-heading">

                    <div>

                        <span>
                            HANDPICKED FOR YOU
                        </span>

                        <h2>
                            Featured Apartments
                        </h2>

                        <p>
                            Explore some of our latest
                            available properties.
                        </p>

                    </div>

                    <Link
                        to="/apartments"
                        className="btn btn-outline-primary"
                    >
                        View All →
                    </Link>

                </div>

                <div className="row g-4">

                    {apartments.length > 0 ? (

                        apartments.map(
                            apartment => (

                                <ApartmentCard
                                    key={apartment.id}
                                    apartment={apartment}
                                />

                            )
                        )

                    ) : (

                        <div className="col-12">

                            <div className="empty-properties">

                                <div>
                                    🏠
                                </div>

                                <h5>
                                    No apartments available
                                </h5>

                                <p>
                                    Check back soon for new listings.
                                </p>

                            </div>

                        </div>

                    )}

                </div>

            </section>


            {/* ================= CTA ================= */}

            <section className="container">

                <div className="home-cta">

                    <div>

                        <span>
                            🏡 NEXTNEST
                        </span>

                        <h2>
                            Ready to find your next home?
                        </h2>

                        <p>
                            Browse thousands of possibilities and
                            discover a place that feels like home.
                        </p>

                    </div>

                    <div className="d-flex gap-2 flex-wrap">

                        <Link
                            to="/apartments"
                            className="btn btn-light btn-lg"
                        >
                            Explore Apartments
                        </Link>

                        <Link
                            to="/register"
                            className="btn btn-outline-light btn-lg"
                        >
                            Get Started
                        </Link>

                    </div>

                </div>

            </section>

        </MainLayout>

    );
}

export default Home;