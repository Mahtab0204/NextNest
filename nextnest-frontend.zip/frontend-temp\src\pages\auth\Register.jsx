import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import MainLayout from "../../layouts/MainLayout";
import authService from "../../services/authService";

function Register() {

    const navigate = useNavigate();

    const [role, setRole] = useState("CUSTOMER");

    const [formData, setFormData] = useState({
        fullName: "",
        email: "",
        phone: "",
        password: "",
        confirmPassword: ""
    });

    const passwordValidation = {
    minLength: formData.password.length >= 8,
    upperCase: /[A-Z]/.test(formData.password),
    lowerCase: /[a-z]/.test(formData.password),
    digit: /\d/.test(formData.password),
    special: /[!@#$%^&*(),.?":{}|<>]/.test(formData.password)
     };

    const handleChange = (e) => {

        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {

    e.preventDefault();

    const validPassword =
        passwordValidation.minLength &&
        passwordValidation.upperCase &&
        passwordValidation.lowerCase &&
        passwordValidation.digit &&
        passwordValidation.special;

    if (!validPassword) {
       toast.warning(
    "Password does not meet security requirements"
);
        return;
    }

    if (formData.password !== formData.confirmPassword) {
        toast.error(
    "Passwords do not match"
);
        return;
    }

    const registerData = {
        fullName: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        password: formData.password
    };

    try {

        if (role === "CUSTOMER") {
            await authService.registerCustomer(registerData);
        } else {
            await authService.registerOwner(registerData);
        }

      toast.success(
    "Verification code sent to your email"
);

navigate(
    "/verify-email",
    {
        state: {
            email: formData.email
        }
    }
);

    } catch (error) {

        console.error(error);

        toast.error(
    error?.response?.data?.message ||
    "Registration Failed"
);
    }
};

    return (
        <MainLayout>

            <div className="row justify-content-center">

                <div className="col-md-6">

                    <div className="card shadow">

                        <div className="card-body p-4">

                            <h2 className="text-center mb-4">
                                Create Account
                            </h2>

                            <form onSubmit={handleSubmit}>

                                <div className="mb-3">

                                    <label>Register As</label>

                                    <select
                                        className="form-select"
                                        value={role}
                                        onChange={(e)=>
                                            setRole(e.target.value)
                                        }
                                    >
                                        <option value="CUSTOMER">
                                            Customer
                                        </option>

                                        <option value="OWNER">
                                            Apartment Owner
                                        </option>

                                    </select>

                                </div>

                                <div className="mb-3">

                                    <label>Full Name</label>

                                    <input
                                        type="text"
                                        className="form-control"
                                        name="fullName"
                                        value={formData.fullName}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label>Email</label>

                                    <input
                                        type="email"
                                        className="form-control"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label>Phone</label>

                                    <input
                                        type="text"
                                        className="form-control"
                                        name="phone"
                                        value={formData.phone}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                        <label className="form-label">
                                                   Password
                                       </label>

                                    <input
                                       type="password"
                                       className="form-control"
                                       name="password"
                                       value={formData.password}
                                       onChange={handleChange}
                                        required
                                      />

                                  </div>

       {
    formData.password && (
        <div className="border rounded p-3 bg-light mt-2">

            <small className="fw-bold text-secondary">
                Password Requirements
            </small>

            <div className="mt-2">

                <div className={
                    passwordValidation.minLength
                        ? "text-success"
                        : "text-danger"
                }>
                    {passwordValidation.minLength ? "✔" : "✖"}
                    {" "}Minimum 8 characters
                </div>

                <div className={
                    passwordValidation.upperCase
                        ? "text-success"
                        : "text-danger"
                }>
                    {passwordValidation.upperCase ? "✔" : "✖"}
                    {" "}At least one uppercase letter
                </div>

                <div className={
                    passwordValidation.lowerCase
                        ? "text-success"
                        : "text-danger"
                }>
                    {passwordValidation.lowerCase ? "✔" : "✖"}
                    {" "}At least one lowercase letter
                </div>

                <div className={
                    passwordValidation.digit
                        ? "text-success"
                        : "text-danger"
                }>
                    {passwordValidation.digit ? "✔" : "✖"}
                    {" "}At least one number
                </div>

                <div className={
                    passwordValidation.special
                        ? "text-success"
                        : "text-danger"
                }>
                    {passwordValidation.special ? "✔" : "✖"}
                    {" "}At least one special character
                </div>

            </div>

        </div>
    )
}

{
    formData.password && (
        <div className="progress mt-3">

            <div
                className={`progress-bar ${
                    Object.values(passwordValidation).filter(Boolean).length <= 2
                        ? "bg-danger"
                        : Object.values(passwordValidation).filter(Boolean).length <= 4
                        ? "bg-warning"
                        : "bg-success"
                }`}
                role="progressbar"
                style={{
                    width: `${
                        (
                            Object.values(passwordValidation)
                                .filter(Boolean).length / 5
                        ) * 100
                    }%`
                }}
            />

        </div>
    )
}

                                <div className="mb-3">

                                    <label>Confirm Password</label>

                                    <input
                                        type="password"
                                        className="form-control"
                                        name="confirmPassword"
                                        value={formData.confirmPassword}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                {
    formData.confirmPassword &&
    (
        <small
            className={
                formData.password === formData.confirmPassword
                    ? "text-success"
                    : "text-danger"
            }
        >
            {
                formData.password === formData.confirmPassword
                    ? "✔ Passwords match"
                    : "✖ Passwords do not match"
            }
        </small>
    )
}

                                <button
                                    type="submit"
                                    className="btn btn-success w-100"
                                >
                                    Register
                                </button>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default Register;