import { useState } from "react";
import { useNavigate } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import locationService from "../../services/locationService";

function CreateLocation() {

    const navigate =
        useNavigate();

    const [formData, setFormData] =
        useState({

            city: "",
            area: "",
            subArea: ""

        });

    const handleChange = (e) => {

        const {
            name,
            value
        } = e.target;

        setFormData({

            ...formData,

            [name]: value
        });
    };

    const handleSubmit =
        async (e) => {

            e.preventDefault();

            try {

                await locationService
                    .createLocation(
                        formData
                    );

                alert(
                    "Location created successfully"
                );

                navigate(
                    "/admin/locations"
                );

            } catch (error) {

                console.error(error);

                alert(
                    "Failed to create location"
                );
            }
        };

    return (

        <MainLayout>

            <div className="container">

                <div className="card shadow">

                    <div className="card-body">

                        <h2 className="mb-4">
                            Add Location
                        </h2>

                        <form
                            onSubmit={handleSubmit}
                        >

                            <div className="mb-3">

                                <label>
                                    City
                                </label>

                                <input
                                    type="text"
                                    name="city"
                                    className="form-control"
                                    value={formData.city}
                                    onChange={handleChange}
                                    required
                                />

                            </div>

                            <div className="mb-3">

                                <label>
                                    Area
                                </label>

                                <input
                                    type="text"
                                    name="area"
                                    className="form-control"
                                    value={formData.area}
                                    onChange={handleChange}
                                    required
                                />

                            </div>

                            <div className="mb-3">

                                <label>
                                    Sub Area
                                </label>

                                <input
                                    type="text"
                                    name="subArea"
                                    className="form-control"
                                    value={formData.subArea}
                                    onChange={handleChange}
                                />

                            </div>

                            <button
                                type="submit"
                                className="btn btn-primary"
                            >
                                Save Location
                            </button>

                        </form>

                    </div>

                </div>

            </div>

        </MainLayout>

    );
}

export default CreateLocation;