import { Link, useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

import useAuth from "../hooks/useAuth";
import notificationService from "../services/notificationService";

function Navbar() {

    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();

    const [notifications, setNotifications] = useState([]);
    const [unreadCount, setUnreadCount] = useState(0);

    const handleLogout = () => {
        logout();
        navigate("/login");
    };

    useEffect(() => {

        if (!user) {
            setNotifications([]);
            setUnreadCount(0);
            return;
        }

        loadNotifications();

        const interval = setInterval(() => {
            loadNotifications();
        }, 30000);

        return () => clearInterval(interval);

    }, [user]);

    const loadNotifications = async () => {

        try {

            const notificationsResponse =
                await notificationService.getNotifications();

            const countResponse =
                await notificationService.getUnreadCount();

            setNotifications(
                notificationsResponse.data
            );

            setUnreadCount(
                countResponse.data.count
            );

        } catch (error) {

            console.error(error);

        }
    };

    const openNotification = async (notification) => {

        try {

            await notificationService.markAsRead(
                notification.id
            );

            loadNotifications();

            if (notification.targetUrl) {
                navigate(notification.targetUrl);
            }

        } catch (error) {

            console.error(error);

        }
    };

    const isActive = (path) =>
        location.pathname === path;

    const getDashboardPath = () => {

        if (user?.role === "OWNER")
            return "/owner/dashboard";

        if (user?.role === "ADMIN")
            return "/admin/dashboard";

        return "/customer/dashboard";
    };

    const getDashboardLabel = () => {

        if (user?.role === "OWNER")
            return "Owner Dashboard";

        if (user?.role === "ADMIN")
            return "Admin Dashboard";

        return "Dashboard";
    };

    return (

        <nav
            className="navbar navbar-expand-lg navbar-dark shadow-sm sticky-top"
            style={{
                background:
                    "linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%)"
            }}
        >

            <div className="container">

                {/* Logo */}

                <Link
                    to="/"
                    className="navbar-brand d-flex align-items-center gap-2 fw-bold"
                    style={{
                        fontSize: "1.35rem"
                    }}
                >

                    <span
                        className="d-flex align-items-center justify-content-center rounded-3 bg-white"
                        style={{
                            width: "40px",
                            height: "40px",
                            fontSize: "22px"
                        }}
                    >
                        🏠
                    </span>

                    <span>
                        NextNest
                    </span>

                </Link>

                {/* Mobile Toggle */}

                <button
                    className="navbar-toggler border-0 shadow-none"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarContent"
                    aria-controls="navbarContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>

                {/* Navigation */}

                <div
                    className="collapse navbar-collapse"
                    id="navbarContent"
                >

                    <ul className="navbar-nav ms-lg-4 me-auto gap-lg-1">

                        <li className="nav-item">

                            <Link
                                to="/"
                                className={`nav-link px-3 rounded-pill ${
                                    isActive("/")
                                        ? "active bg-white bg-opacity-10 fw-semibold"
                                        : ""
                                }`}
                            >
                                🏠 Home
                            </Link>

                        </li>

                        <li className="nav-item">

                            <Link
                                to="/rent"
                                className={`nav-link px-3 rounded-pill ${
                                    isActive("/rent")
                                        ? "active bg-white bg-opacity-10 fw-semibold"
                                        : ""
                                }`}
                            >
                                🏢 Rent
                            </Link>

                        </li>

                        <li className="nav-item">

                            <Link
                                to="/buy"
                                className={`nav-link px-3 rounded-pill ${
                                    isActive("/buy")
                                        ? "active bg-white bg-opacity-10 fw-semibold"
                                        : ""
                                }`}
                            >
                                🔑 Buy
                            </Link>

                        </li>

                    </ul>

                    {/* Right Side */}

                    <div className="d-flex align-items-center gap-2 mt-3 mt-lg-0">

                        {/* Guest */}

                        {!user && (

                            <>
                                <Link
                                    to="/login"
                                    className="btn btn-outline-light rounded-pill px-4"
                                >
                                    Login
                                </Link>

                                <Link
                                    to="/register"
                                    className="btn btn-warning rounded-pill px-4 fw-semibold"
                                >
                                    Get Started
                                </Link>
                            </>

                        )}

                        {/* Authenticated User */}

                        {user && (

                            <>

                                {/* Welcome */}

                                <div className="d-none d-xl-flex align-items-center text-white me-2">

                                    <div
                                        className="rounded-circle bg-white text-primary d-flex align-items-center justify-content-center me-2 fw-bold"
                                        style={{
                                            width: "36px",
                                            height: "36px"
                                        }}
                                    >
                                        {user.fullName
                                            ?.charAt(0)
                                            ?.toUpperCase()}
                                    </div>

                                    <div>

                                        <small
                                            className="d-block opacity-75"
                                            style={{
                                                lineHeight: "1"
                                            }}
                                        >
                                            Welcome
                                        </small>

                                        <span className="fw-semibold">
                                            {user.fullName}
                                        </span>

                                    </div>

                                </div>

                                {/* Notifications */}

                                <div className="dropdown">

                                    <button
                                        className="btn btn-light rounded-circle position-relative d-flex align-items-center justify-content-center"
                                        style={{
                                            width: "42px",
                                            height: "42px"
                                        }}
                                        data-bs-toggle="dropdown"
                                        aria-expanded="false"
                                    >

                                        🔔

                                        {unreadCount > 0 && (

                                            <span
                                                className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger border border-white"
                                                style={{
                                                    fontSize: "10px"
                                                }}
                                            >
                                                {unreadCount > 99
                                                    ? "99+"
                                                    : unreadCount}
                                            </span>

                                        )}

                                    </button>

                                    <ul
                                        className="dropdown-menu dropdown-menu-end shadow border-0 rounded-4 mt-2 p-2"
                                        style={{
                                            width: "360px",
                                            maxHeight: "420px",
                                            overflowY: "auto"
                                        }}
                                    >

                                        <li className="px-3 py-2">

                                            <div className="d-flex justify-content-between align-items-center">

                                                <strong>
                                                    Notifications
                                                </strong>

                                                {unreadCount > 0 && (

                                                    <span className="badge bg-danger">
                                                        {unreadCount} new
                                                    </span>

                                                )}

                                            </div>

                                        </li>

                                        <li>
                                            <hr className="dropdown-divider" />
                                        </li>

                                        {notifications.length === 0 ? (

                                            <li className="text-center py-4">

                                                <div
                                                    style={{
                                                        fontSize: "30px"
                                                    }}
                                                >
                                                    🔕
                                                </div>

                                                <small className="text-muted">
                                                    No notifications
                                                </small>

                                            </li>

                                        ) : (

                                            notifications.map(
                                                notification => (

                                                    <li
                                                        key={
                                                            notification.id
                                                        }
                                                    >

                                                        <button
                                                            className={`dropdown-item rounded-3 py-3 ${
                                                                !notification.isRead
                                                                    ? "bg-light fw-bold"
                                                                    : ""
                                                            }`}
                                                            onClick={() =>
                                                                openNotification(
                                                                    notification
                                                                )
                                                            }
                                                        >

                                                            <div className="d-flex gap-2">

                                                                <div>
                                                                    🔔
                                                                </div>

                                                                <div className="text-wrap">

                                                                    <div>
                                                                        {
                                                                            notification.title
                                                                        }
                                                                    </div>

                                                                    <small className="text-muted fw-normal">
                                                                        {
                                                                            notification.message
                                                                        }
                                                                    </small>

                                                                </div>

                                                            </div>

                                                        </button>

                                                    </li>

                                                )
                                            )

                                        )}

                                    </ul>

                                </div>

                                {/* Dashboard */}

                                <Link
                                    to={getDashboardPath()}
                                    className="btn btn-success rounded-pill px-3 fw-semibold"
                                >
                                    📊{" "}
                                    <span className="d-none d-md-inline">
                                        {getDashboardLabel()}
                                    </span>
                                    <span className="d-md-none">
                                        Dashboard
                                    </span>
                                </Link>

                                {/* Logout */}

                                <button
                                    className="btn btn-outline-light rounded-pill px-3"
                                    onClick={handleLogout}
                                >
                                    Logout
                                </button>

                            </>

                        )}

                    </div>

                </div>

            </div>

        </nav>
    );
}

export default Navbar;
