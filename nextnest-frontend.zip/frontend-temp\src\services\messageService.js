import api from "../api/axios";

const getConversations = () => {
    return api.get(
        "/messages/conversations"
    );
};

const getMessages = (inquiryId) => {
    return api.get(
        `/messages/inquiry/${inquiryId}`
    );
};

const sendMessage = (data) => {
    return api.post(
        "/messages",
        data
    );
};

const markAsRead = (messageId) => {
    return api.patch(
        `/messages/${messageId}/read`
    );
};

const getUnreadCount = (inquiryId) => {
    return api.get(
        `/messages/inquiry/${inquiryId}/unread-count`
    );
};

const messageService = {
    getConversations,
    getMessages,
    sendMessage,
    markAsRead,
    getUnreadCount
};

export default messageService;