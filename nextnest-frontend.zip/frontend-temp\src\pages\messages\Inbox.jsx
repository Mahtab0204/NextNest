import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import messageService from "../../services/messageService";

function Inbox() {

    const [conversations, setConversations] =
        useState([]);

    const [loading, setLoading] =
        useState(true);

    useEffect(() => {

        loadConversations();

    }, []);

    const loadConversations =
        async () => {

        try {

            const response =
                await messageService
                    .getConversations();

            setConversations(
                response.data
            );

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);
        }
    };

    return (

        <MainLayout>

            <div className="container py-4">

                <h2 className="fw-bold mb-4">
                    Inbox
                </h2>

                {
                    loading ? (

                        <div className="text-center">

                            <div className="spinner-border text-primary"/>

                        </div>

                    ) : (

                        <div className="row">

                            {
                                conversations.map(
                                    conversation => (

                                        <div
                                            key={
                                                conversation.inquiryId
                                            }
                                            className="col-md-6 mb-4"
                                        >

                                            <div className="card shadow-sm border-0 h-100">

                                                <div className="card-body">

                                                    <h5 className="fw-bold">

                                                        {
                                                            conversation.apartmentTitle
                                                        }

                                                    </h5>

                                                    <p className="mb-1">

                                                        <strong>
                                                            User:
                                                        </strong>{" "}

                                                        {
                                                            conversation.otherUserName
                                                        }

                                                    </p>

                                                    <p className="text-muted">

                                                        {
                                                            conversation.lastMessage
                                                        }

                                                    </p>

                                                    <small className="text-secondary">

                                                        {
                                                            new Date(
                                                                conversation.lastMessageTime
                                                            ).toLocaleString()
                                                        }

                                                    </small>

                                                    <div className="mt-3 d-flex justify-content-between align-items-center">

                                                        {
                                                            conversation.unreadCount > 0 && (

                                                                <span className="badge bg-danger">

                                                                    {
                                                                        conversation.unreadCount
                                                                    }

                                                                </span>
                                                            )
                                                        }

                                                        <Link
                                                            to={`/messages/${conversation.inquiryId}`}
                                                            className="btn btn-primary btn-sm"
                                                        >
                                                            Open Chat
                                                        </Link>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    )
                                )
                            }

                        </div>

                    )
                }

            </div>

        </MainLayout>
    );
}

export default Inbox;