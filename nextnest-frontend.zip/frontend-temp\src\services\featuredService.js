// src/services/featuredService.js

import axiosInstance from "../api/axios";

const promoteApartment = (data) => {
    return axiosInstance.post(
        "/apartments/promote",
        data
    );
};

const getOwnerFeaturedHistory = (ownerId) => {
    return axiosInstance.get(
        `/featured-payments/owner/${ownerId}`
    );
};

const featuredService = {
    promoteApartment,
    getOwnerFeaturedHistory
};

export default featuredService;