import { Routes, Route } from "react-router-dom";

import Home from "../pages/home/Home";
import Login from "../pages/auth/Login";
import Register from "../pages/auth/Register";
import CustomerDashboard from "../pages/customer/CustomerDashboard";
import OwnerDashboard from "../pages/owner/OwnerDashboard";
import AdminDashboard from "../pages/admin/AdminDashboard";
import ProtectedRoute from "./ProtectedRoute";
import RoleProtectedRoute from "./RoleProtectedRoute";
import ApartmentList from "../pages/apartment/ApartmentList";
import RentPage from "../pages/apartment/RentPage";
import BuyPage from "../pages/apartment/BuyPage";
import ApartmentDetails from "../pages/apartment/ApartmentDetails";
import OwnerInquiries from "../pages/owner/OwnerInquiries";
import MyInquiries from "../pages/customer/MyInquiries";
import CreateApartment from "../pages/owner/CreateApartment";
import MyApartments from "../pages/owner/MyApartments";
import EditApartment from "../pages/owner/EditApartment";
import UploadApartmentImage from "../pages/owner/UploadApartmentImage";
import LocationList from "../pages/admin/LocationList";
import CreateLocation from "../pages/admin/CreateLocation";
import EditLocation from "../pages/admin/EditLocation";
import UserList from "../pages/admin/UserList";
import VerifyEmail from "../pages/auth/VerifyEmail";
import ForgotPassword from "../pages/auth/ForgotPassword";
import ResetPassword from "../pages/auth/ResetPassword";
import Profile from "../pages/auth/Profile";
import AdminApartmentList from "../pages/admin/AdminApartmentList";
import AdminApartmentDetails from "../pages/admin/AdminApartmentDetails";
import Inbox from "../pages/messages/Inbox";
import ChatPage from "../pages/messages/ChatPage";
import BrowseApartmentsPage from "../pages/apartment/BrowseApartmentsPage";
import MyWishlist from "../pages/customer/MyWishlist";
import RecentlyViewed from "../pages/customer/RecentlyViewed";
import UserDetails from "../pages/admin/UserDetails";
import FeatureApartment from "../pages/owner/FeaturedApartment";
import PromoteApartmentPage from "../components/PromoteApartmentPage";


function AppRoutes() {
    return (
        <Routes>

            <Route path="/" element={<Home />} />

            <Route path="/login" element={<Login />} />

            <Route path="/register" element={<Register />} />

            <Route
                path="/customer/dashboard"
                element={
                    <RoleProtectedRoute
                        allowedRoles={["CUSTOMER"]}
                    >
                        <CustomerDashboard />
                    </RoleProtectedRoute>
                }
            />

            <Route
                path="/owner/dashboard"
                element={
                    <RoleProtectedRoute
                        allowedRoles={["OWNER"]}
                    >
                        <OwnerDashboard />
                    </RoleProtectedRoute>
                }
            />

            <Route
                path="/admin/dashboard"
                element={
                    <RoleProtectedRoute
                        allowedRoles={["ADMIN"]}
                    >
                        <AdminDashboard />
                    </RoleProtectedRoute>
                }
            />


           <Route
    path="/apartments"
    element={<BrowseApartmentsPage/>}
/>

            <Route
    path="/rent"
    element={<RentPage />}
/>

<Route
    path="/buy"
    element={<BuyPage />}
/>

<Route
    path="/apartments/:id"
    element={<ApartmentDetails />}
/>

<Route
    path="/owner/inquiries"
    element={
        <RoleProtectedRoute
            allowedRoles={["OWNER"]}
        >
            <OwnerInquiries />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/customer/inquiries"
    element={
        <RoleProtectedRoute
            allowedRoles={["CUSTOMER"]}
        >
            <MyInquiries />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/owner/create-apartment"
    element={
        <RoleProtectedRoute
            allowedRoles={["OWNER"]}
        >
            <CreateApartment />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/owner/apartments"
    element={
        <RoleProtectedRoute
            allowedRoles={["OWNER"]}
        >
            <MyApartments />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/owner/apartments/edit/:id"
    element={
        <RoleProtectedRoute
            allowedRoles={["OWNER"]}
        >
            <EditApartment />
        </RoleProtectedRoute>
    }
/>
<Route
    path="/owner/apartments/:id/images"
    element={
        <RoleProtectedRoute
            allowedRoles={["OWNER"]}
        >
            <UploadApartmentImage />
        </RoleProtectedRoute>
    }
/>
<Route
    path="/admin/locations"
    element={
        <RoleProtectedRoute
            allowedRoles={["ADMIN"]}
        >
            <LocationList />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/admin/locations/create"
    element={
        <RoleProtectedRoute
            allowedRoles={["ADMIN"]}
        >
            <CreateLocation />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/admin/locations/edit/:id"
    element={
        <RoleProtectedRoute
            allowedRoles={["ADMIN"]}
        >
            <EditLocation />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/admin/users"
    element={
        <RoleProtectedRoute
            allowedRoles={["ADMIN"]}
        >
            <UserList />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/verify-email"
    element={<VerifyEmail />}
/>

<Route
    path="/forgot-password"
    element={<ForgotPassword />}
/>

<Route
    path="/reset-password"
    element={<ResetPassword />}
/>

<Route
    path="/profile"
    element={
        <ProtectedRoute>
            <Profile />
        </ProtectedRoute>
    }
/>

<Route
    path="/admin/apartments"
    element={
        <RoleProtectedRoute
            allowedRoles={["ADMIN"]}
        >
            <AdminApartmentList />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/admin/apartments/:id"
    element={
        <RoleProtectedRoute
            allowedRoles={["ADMIN"]}
        >
            <AdminApartmentDetails />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/messages"
    element={
        <ProtectedRoute>
            <Inbox />
        </ProtectedRoute>
    }
/>

<Route
    path="/messages/:inquiryId"
    element={
        <ProtectedRoute>
            <ChatPage />
        </ProtectedRoute>
    }
/>

<Route
    path="/customer/wishlist"
    element={
        <RoleProtectedRoute
            allowedRoles={["CUSTOMER"]}
        >
            <MyWishlist />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/customer/recently-viewed"
    element={
        <RoleProtectedRoute
            allowedRoles={["CUSTOMER"]}
        >
            <RecentlyViewed />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/admin/users/:id"
    element={
        <RoleProtectedRoute
            allowedRoles={["ADMIN"]}
        >
            <UserDetails />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/owner/apartments/:id/feature"
    element={
        <RoleProtectedRoute
            allowedRoles={["CUSTOMER"]}
        >
           <FeatureApartment />
        </RoleProtectedRoute>
    }
/>

<Route
    path="/owner/promote/:apartmentId"
    element={<PromoteApartmentPage />}
/>
        </Routes>
    );
}

export default AppRoutes;