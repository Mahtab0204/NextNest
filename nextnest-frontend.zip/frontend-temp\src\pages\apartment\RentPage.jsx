import ApartmentList from "./ApartmentList";

function RentPage() {

    return (
        <ApartmentList
            purpose="RENT"
            pageTitle="Apartments For Rent"
        />
    );
}

export default RentPage;