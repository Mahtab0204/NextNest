import {createContext,useEffect,useState} from "react";

import {saveToken,removeToken} from "../utils/token";

export const AuthContext = createContext();

export const AuthProvider = ({children}) => {

    const [user, setUser] =
    useState(null);

    const [loading, setLoading] =
      useState(true);

   useEffect(() => {

    const savedUser =
        localStorage.getItem("user");

    if(savedUser){

        setUser(
            JSON.parse(savedUser)
        );
    }

    setLoading(false);

}, []);

    const login = (userData, token) => {

        saveToken(token);

        localStorage.setItem(
            "user",
            JSON.stringify(userData)
        );

        setUser(userData);
    };

    const logout = () => {

        removeToken();

        localStorage.removeItem(
            "user"
        );

        setUser(null);
    };

    return (
    <AuthContext.Provider
        value={{
            user,
            loading,
            login,
            logout
        }}
    >
        {children}
    </AuthContext.Provider>
);
};