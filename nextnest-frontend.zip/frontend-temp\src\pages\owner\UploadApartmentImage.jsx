import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import apartmentService from "../../services/apartmentService";

function UploadApartmentImage() {

    const { id } = useParams();

    const [image, setImage] =
        useState(null);

    const [loading, setLoading] =
        useState(false);

    const [images, setImages] =
    useState([]);

    useEffect(() => {

    loadImages();

}, []);

const loadImages = async () => {

    try {

        const response =
            await apartmentService
                .getApartmentImages(id);

        setImages(
            response.data
        );

    } catch (error) {

        console.error(error);
    }
};

    const handleUpload = async (e) => {

        e.preventDefault();

        if (!image) {

            alert("Select an image first");

            return;
        }

        if (image.size > 20 * 1024 * 1024) {

         alert("Image must be less than 20MB");

            return;
       }

        try {

            setLoading(true);

            const formData =
                new FormData();

            formData.append(
                "image",
                image
            );

            await apartmentService
                .uploadImage(
                    id,
                    formData
                );
                await loadImages();
            alert(
                "Image uploaded successfully"
            );

            setImage(null);

        } catch (error) {

            console.error(error);

            alert(
                "Failed to upload image"
            );

        } finally {

            setLoading(false);
        }
    };

    const handleDeleteImage =
    async (imageId) => {

        const confirmDelete =
            window.confirm(
                "Delete this image?"
            );

        if (!confirmDelete)
            return;

        try {

            await apartmentService
                .deleteImage(imageId);

            alert(
                "Image deleted successfully"
            );

            loadImages();

        } catch (error) {

            console.error(error);

            alert(
                "Failed to delete image"
            );
        }
    };

    const handleSetCover =
    async (imageId) => {

        try {

            await apartmentService
                .setCoverImage(
                    imageId
                );

            alert(
                "Cover image updated"
            );

            loadImages();

        } catch (error) {

            console.error(error);

            alert(
                "Failed to update cover image"
            );
        }
    };

    return (

    <MainLayout>

        <div className="container">

            <div className="card shadow">

                <div className="card-body">

                    <h2 className="mb-4">
                        Upload Apartment Image
                    </h2>

                    <form
                        onSubmit={handleUpload}
                    >

                        <input
                            type="file"
                            className="form-control mb-3"
                            accept="image/*"
                            onChange={(e) =>
                                setImage(
                                    e.target.files[0]
                                )
                            }
                        />

                        <button
                            type="submit"
                            className="btn btn-primary"
                            disabled={loading}
                        >

                            {
                                loading
                                    ? "Uploading..."
                                    : "Upload Image"
                            }

                        </button>

                    </form>

                    <hr className="my-4" />

                    <h4>
                        Uploaded Images
                    </h4>

                    <div className="row">

                        {
                            images.length > 0 ? (

                      images.map(
    (image) => (

        <div
            key={image.id}
            className="col-md-3 mb-3"
        >

            <img
                src={`http://localhost:8080/uploads/${image.imageUrl}`}
                alt=""
                className="img-fluid rounded shadow"
                style={{
                    height: "180px",
                    width: "100%",
                    objectFit: "cover"
                }}
            />

           <div className="mt-2">

    {
        image.coverImage ? (

            <div
                className="badge bg-success w-100 mb-2"
            >
                ⭐ Cover Image
            </div>

        ) : (

            <button
                className="btn btn-outline-primary btn-sm w-100 mb-2"
                onClick={() =>
                    handleSetCover(
                        image.id
                    )
                }
            >
                Set Cover
            </button>

        )
    }

    <button
        className="btn btn-danger btn-sm w-100"
        onClick={() =>
            handleDeleteImage(
                image.id
            )
        }
    >
        Delete
    </button>

</div>

        </div>

    )
)

                            ) : (

                                <div className="col-12">

                                    <p className="text-muted">
                                        No images uploaded yet.
                                    </p>

                                </div>

                            )
                        }

                    </div>

                </div>

            </div>

        </div>

    </MainLayout>

);
}

export default UploadApartmentImage;