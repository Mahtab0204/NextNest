import { useEffect, useRef, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import messageService from "../../services/messageService";

function ChatPage() {

    const { inquiryId } = useParams();
    const navigate = useNavigate();

    const [messages, setMessages] = useState([]);
    const [content, setContent] = useState("");
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState(false);
    const [showNewMessage, setShowNewMessage] = useState(false);

    const chatBodyRef = useRef(null);
    const initialLoadRef = useRef(true);
    const previousMessageCountRef = useRef(0);

    const user = JSON.parse(
        localStorage.getItem("user") || "{}"
    );

    /* =========================
       LOAD MESSAGES
    ========================= */

    const loadMessages = async (isPolling = false) => {

        try {

            const response =
                await messageService.getMessages(inquiryId);

            const newMessages =
                response.data || [];

            if (!isPolling) {

                setMessages(newMessages);

                return;
            }

            const oldCount =
                previousMessageCountRef.current;

            if (newMessages.length > oldCount) {

                const container =
                    chatBodyRef.current;

                if (container) {

                    const distanceFromBottom =
                        container.scrollHeight -
                        container.scrollTop -
                        container.clientHeight;

                    const isNearBottom =
                        distanceFromBottom < 150;

                    if (isNearBottom) {

                        setMessages(newMessages);

                        setTimeout(() => {

                            scrollToBottom(true);

                        }, 50);

                    } else {

                        setMessages(newMessages);

                        setShowNewMessage(true);
                    }

                } else {

                    setMessages(newMessages);
                }

            } else {

                setMessages(newMessages);
            }

        } catch (error) {

            console.error(
                "Failed to load messages:",
                error
            );

        } finally {

            setLoading(false);

        }
    };

    /* =========================
       INITIAL LOAD + POLLING
    ========================= */

    useEffect(() => {

        initialLoadRef.current = true;

        previousMessageCountRef.current = 0;

        loadMessages();

        const interval =
            setInterval(() => {

                if (
                    document.visibilityState ===
                    "visible"
                ) {

                    loadMessages(true);

                }

            }, 3000);

        return () =>
            clearInterval(interval);

    }, [inquiryId]);

    /* =========================
       INITIAL SCROLL
    ========================= */

    useEffect(() => {

        if (
            !loading &&
            messages.length > 0 &&
            initialLoadRef.current
        ) {

            setTimeout(() => {

                scrollToBottom(false);

                initialLoadRef.current = false;

            }, 100);

        }

        previousMessageCountRef.current =
            messages.length;

    }, [messages, loading]);

    /* =========================
       SCROLL TO BOTTOM
    ========================= */

    const scrollToBottom = (
        smooth = true
    ) => {

        const container =
            chatBodyRef.current;

        if (!container) return;

        container.scrollTo({

            top:
                container.scrollHeight,

            behavior:
                smooth
                    ? "smooth"
                    : "auto"

        });

        setShowNewMessage(false);
    };

    /* =========================
       SEND MESSAGE
    ========================= */

    const handleSend = async (e) => {

        e.preventDefault();

        if (
            !content.trim() ||
            sending
        ) {
            return;
        }

        try {

            setSending(true);

            await messageService.sendMessage({

                inquiryId,

                content:
                    content.trim()

            });

            setContent("");

            await loadMessages(false);

            setTimeout(() => {

                scrollToBottom(true);

            }, 100);

        } catch (error) {

            console.error(
                "Failed to send message:",
                error
            );

        } finally {

            setSending(false);

        }
    };

    /* =========================
       USER INITIAL
    ========================= */

    const getInitial = (name) => {

        if (!name) return "?";

        return name
            .charAt(0)
            .toUpperCase();
    };

    /* =========================
       TIME FORMAT
    ========================= */

    const formatTime = (date) => {

        if (!date) return "";

        return new Date(date)
            .toLocaleTimeString(
                [],
                {
                    hour: "2-digit",
                    minute: "2-digit"
                }
            );
    };

    /* =========================
       DATE FORMAT
    ========================= */

    const formatDate = (date) => {

        if (!date) return "";

        const messageDate =
            new Date(date);

        const today =
            new Date();

        const yesterday =
            new Date();

        yesterday.setDate(
            today.getDate() - 1
        );

        if (
            messageDate.toDateString() ===
            today.toDateString()
        ) {
            return "Today";
        }

        if (
            messageDate.toDateString() ===
            yesterday.toDateString()
        ) {
            return "Yesterday";
        }

        return messageDate.toLocaleDateString(
            [],
            {
                day: "numeric",
                month: "short",
                year: "numeric"
            }
        );
    };

    /* =========================
       CHECK NEW DATE
    ========================= */

    const shouldShowDate = (
        current,
        previous
    ) => {

        if (!previous) return true;

        const currentDate =
            new Date(current).toDateString();

        const previousDate =
            new Date(previous).toDateString();

        return currentDate !== previousDate;
    };

    /* =========================
       LOADING
    ========================= */

    if (loading) {

        return (

            <MainLayout>

                <div className="container py-4">

                    <div
                        className="card border-0 shadow-lg"
                        style={{
                            height: "82vh",
                            borderRadius: "24px"
                        }}
                    >

                        <div className="p-4">

                            <div className="placeholder-glow">

                                <span className="placeholder col-4 rounded" />

                            </div>

                            <hr />

                            {[1, 2, 3, 4, 5].map(
                                item => (

                                    <div
                                        key={item}
                                        className={`placeholder-glow mb-4 ${
                                            item % 2 === 0
                                                ? "text-end"
                                                : ""
                                        }`}
                                    >

                                        <span
                                            className={`placeholder ${
                                                item % 2 === 0
                                                    ? "col-5"
                                                    : "col-6"
                                            } rounded-pill`}
                                            style={{
                                                height: "45px"
                                            }}
                                        />

                                    </div>

                                )
                            )}

                        </div>

                    </div>

                </div>

            </MainLayout>

        );
    }

    /* =========================
       OTHER PERSON
    ========================= */

    const otherMessage =
        messages.find(
            message =>
                Number(message.senderId) !==
                Number(user.userId)
        );

    const otherUserName =
        otherMessage?.senderName ||
        "Conversation";

    return (

        <MainLayout>

            <div className="container py-3 py-md-4">

                <div
                    className="card border-0 shadow-lg overflow-hidden"
                    style={{
                        height: "82vh",
                        minHeight: "600px",
                        borderRadius: "24px"
                    }}
                >

                    {/* ================= HEADER ================= */}

                    <div
                        className="card-header bg-white border-0 px-3 px-md-4 py-3"
                        style={{
                            borderBottom:
                                "1px solid #edf0f4"
                        }}
                    >

                        <div className="d-flex align-items-center justify-content-between">

                            <div className="d-flex align-items-center">

                                <button
                                    className="btn btn-light rounded-circle shadow-sm me-3"
                                    onClick={() =>
                                        navigate(-1)
                                    }
                                    style={{
                                        width: "42px",
                                        height: "42px"
                                    }}
                                >
                                    ←
                                </button>

                                {/* Avatar */}

                                <div
                                    className="d-flex align-items-center justify-content-center fw-bold text-white me-3"
                                    style={{
                                        width: "48px",
                                        height: "48px",
                                        borderRadius: "50%",
                                        background:
                                            "linear-gradient(135deg,#0d6efd,#6610f2)",
                                        fontSize: "18px"
                                    }}
                                >
                                    {getInitial(
                                        otherUserName
                                    )}
                                </div>

                                <div>

                                    <h5 className="mb-0 fw-bold">
                                        {otherUserName}
                                    </h5>

                                    <div className="d-flex align-items-center gap-2">

                                        <span
                                            className="rounded-circle bg-success"
                                            style={{
                                                width: "7px",
                                                height: "7px"
                                            }}
                                        />

                                        <small className="text-muted">
                                            Property conversation
                                        </small>

                                    </div>

                                </div>

                            </div>

                            <div className="d-flex align-items-center gap-2">

                                <span className="badge bg-light text-dark border px-3 py-2 d-none d-md-inline-block">
                                    💬 {messages.length}
                                </span>

                                <button
                                    className="btn btn-light rounded-circle shadow-sm"
                                    onClick={() =>
                                        loadMessages(false)
                                    }
                                    title="Refresh"
                                    style={{
                                        width: "42px",
                                        height: "42px"
                                    }}
                                >
                                    ↻
                                </button>

                            </div>

                        </div>

                    </div>

                    {/* ================= CHAT BODY ================= */}

                    <div
                        ref={chatBodyRef}
                        className="card-body position-relative px-3 px-md-5 py-4"
                        style={{
                            overflowY: "auto",
                            background:
                                "linear-gradient(180deg,#f8fafc 0%,#eef3f8 100%)"
                        }}
                        onScroll={() => {

                            const container =
                                chatBodyRef.current;

                            if (!container)
                                return;

                            const distance =
                                container.scrollHeight -
                                container.scrollTop -
                                container.clientHeight;

                            if (distance < 100) {

                                setShowNewMessage(false);

                            }

                        }}
                    >

                        {/* Empty Chat */}

                        {messages.length === 0 ? (

                            <div className="h-100 d-flex align-items-center justify-content-center">

                                <div className="text-center">

                                    <div
                                        className="d-flex align-items-center justify-content-center mx-auto mb-3 shadow-sm"
                                        style={{
                                            width: "90px",
                                            height: "90px",
                                            borderRadius: "50%",
                                            background:
                                                "linear-gradient(135deg,#e7f1ff,#f1e9ff)",
                                            fontSize: "38px"
                                        }}
                                    >
                                        💬
                                    </div>

                                    <h5 className="fw-bold">
                                        Start a conversation
                                    </h5>

                                    <p className="text-muted mb-0">
                                        Send a message to begin chatting.
                                    </p>

                                </div>

                            </div>

                        ) : (

                            <>

                                {messages.map(
                                    (
                                        message,
                                        index
                                    ) => {

                                        const isMine =
                                            Number(
                                                message.senderId
                                            ) ===
                                            Number(
                                                user.userId
                                            );

                                        const previousMessage =
                                            messages[
                                                index - 1
                                            ];

                                        const showDate =
                                            shouldShowDate(
                                                message.sentAt,
                                                previousMessage?.sentAt
                                            );

                                        const showName =
                                            !isMine &&
                                            (
                                                index === 0 ||
                                                Number(
                                                    previousMessage?.senderId
                                                ) !==
                                                Number(
                                                    message.senderId
                                                )
                                            );

                                        return (

                                            <div
                                                key={
                                                    message.id
                                                }
                                            >

                                                {/* DATE */}

                                                {showDate && (

                                                    <div className="text-center my-4">

                                                        <span
                                                            className="badge bg-white text-muted border shadow-sm px-3 py-2"
                                                            style={{
                                                                borderRadius:
                                                                    "20px"
                                                            }}
                                                        >
                                                            {formatDate(
                                                                message.sentAt
                                                            )}
                                                        </span>

                                                    </div>

                                                )}

                                                {/* MESSAGE */}

                                                <div
                                                    className={`d-flex mb-2 ${
                                                        isMine
                                                            ? "justify-content-end"
                                                            : "justify-content-start"
                                                    }`}
                                                >

                                                    {/* OTHER AVATAR */}

                                                    {!isMine && (

                                                        <div
                                                            className="d-flex align-items-center justify-content-center bg-white shadow-sm fw-bold text-primary flex-shrink-0 me-2"
                                                            style={{
                                                                width: "36px",
                                                                height: "36px",
                                                                borderRadius:
                                                                    "50%",
                                                                marginTop:
                                                                    "4px"
                                                            }}
                                                        >
                                                            {getInitial(
                                                                message.senderName
                                                            )}
                                                        </div>

                                                    )}

                                                    <div
                                                        style={{
                                                            maxWidth:
                                                                "min(75%, 600px)"
                                                        }}
                                                    >

                                                        {/* NAME */}

                                                        {showName && (

                                                            <div
                                                                className="small fw-semibold text-muted mb-1 ms-2"
                                                            >
                                                                {
                                                                    message.senderName
                                                                }
                                                            </div>

                                                        )}

                                                        {/* BUBBLE */}

                                                        <div
                                                            className={
                                                                isMine
                                                                    ? "text-white shadow-sm"
                                                                    : "bg-white text-dark shadow-sm"
                                                            }
                                                            style={{
                                                                padding:
                                                                    "11px 15px",
                                                                borderRadius:
                                                                    isMine
                                                                        ? "18px 18px 4px 18px"
                                                                        : "18px 18px 18px 4px",
                                                                background:
                                                                    isMine
                                                                        ? "linear-gradient(135deg,#0d6efd,#5b5ce2)"
                                                                        : undefined
                                                            }}
                                                        >

                                                            <div
                                                                style={{
                                                                    whiteSpace:
                                                                        "pre-wrap",
                                                                    wordBreak:
                                                                        "break-word",
                                                                    lineHeight:
                                                                        "1.5"
                                                                }}
                                                            >
                                                                {
                                                                    message.content
                                                                }
                                                            </div>

                                                            <div
                                                                className={`d-flex justify-content-end align-items-center gap-1 mt-1 ${
                                                                    isMine
                                                                        ? "text-white-50"
                                                                        : "text-muted"
                                                                }`}
                                                                style={{
                                                                    fontSize:
                                                                        "10px"
                                                                }}
                                                            >

                                                                {formatTime(
                                                                    message.sentAt
                                                                )}

                                                                {isMine && (
                                                                    <span>
                                                                        ✓
                                                                    </span>
                                                                )}

                                                            </div>

                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        );

                                    }
                                )}

                            </>

                        )}

                        {/* NEW MESSAGE BUTTON */}

                        {showNewMessage && (

                            <button
                                className="btn btn-primary shadow position-sticky bottom-0 start-50 translate-middle-x"
                                onClick={() =>
                                    scrollToBottom(true)
                                }
                                style={{
                                    borderRadius: "25px",
                                    padding:
                                        "9px 18px",
                                    zIndex: 10
                                }}
                            >
                                ↓ New messages
                            </button>

                        )}

                    </div>

                    {/* ================= COMPOSER ================= */}

                    <div
                        className="card-footer bg-white border-0 px-3 px-md-4 py-3"
                        style={{
                            borderTop:
                                "1px solid #edf0f4"
                        }}
                    >

                        <form
                            onSubmit={handleSend}
                        >

                            <div
                                className="d-flex align-items-center gap-2 p-2 shadow-sm"
                                style={{
                                    background:
                                        "#f5f7fa",
                                    border:
                                        "1px solid #e8ebef",
                                    borderRadius:
                                        "18px"
                                }}
                            >

                                <span
                                    className="text-muted ps-2 d-none d-md-inline"
                                    style={{
                                        fontSize: "20px"
                                    }}
                                >
                                    💬
                                </span>

                                <input
                                    type="text"
                                    className="form-control border-0 bg-transparent shadow-none"
                                    placeholder="Write a message..."
                                    value={content}
                                    onChange={(e) =>
                                        setContent(
                                            e.target.value
                                        )
                                    }
                                    onKeyDown={(e) => {

                                        if (
                                            e.key ===
                                                "Enter" &&
                                            !e.shiftKey
                                        ) {

                                            e.preventDefault();

                                            handleSend(e);

                                        }

                                    }}
                                    disabled={sending}
                                    style={{
                                        minHeight:
                                            "42px"
                                    }}
                                />

                                <button
                                    type="submit"
                                    className="btn btn-primary rounded-circle d-flex align-items-center justify-content-center shadow-sm"
                                    disabled={
                                        !content.trim() ||
                                        sending
                                    }
                                    style={{
                                        width: "44px",
                                        height: "44px",
                                        flexShrink: 0
                                    }}
                                >

                                    {sending ? (

                                        <span
                                            className="spinner-border spinner-border-sm"
                                        />

                                    ) : (

                                        <span
                                            style={{
                                                fontSize:
                                                    "18px"
                                            }}
                                        >
                                            ➤
                                        </span>

                                    )}

                                </button>

                            </div>

                        </form>

                        <div className="text-center mt-2">

                            <small className="text-muted">
                                🔒 Your conversation is private
                            </small>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default ChatPage;