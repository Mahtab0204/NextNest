import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import MainLayout from "../../layouts/MainLayout";
import authService from "../../services/authService";

function ForgotPassword() {

    const navigate = useNavigate();

    const [email, setEmail] =
        useState("");

    const handleSubmit = async (e) => {

        e.preventDefault();

        try {

            await authService.forgotPassword(
                email
            );

            toast.success(
                "OTP sent to your email"
            );

            navigate(
                "/reset-password",
                {
                    state: {
                        email
                    }
                }
            );

        } catch (error) {

            toast.error(
                error?.response?.data?.message ||
                "Failed to send OTP"
            );
        }
    };

    return (

        <MainLayout>

            <div className="row justify-content-center">

                <div className="col-md-5">

                    <div className="card shadow">

                        <div className="card-body p-4">

                            <h2 className="text-center mb-4">

                                Forgot Password

                            </h2>

                            <form
                                onSubmit={handleSubmit}
                            >

                                <div className="mb-3">

                                    <label>
                                        Email
                                    </label>

                                    <input
                                        type="email"
                                        className="form-control"
                                        value={email}
                                        onChange={(e) =>
                                            setEmail(
                                                e.target.value
                                            )
                                        }
                                        required
                                    />

                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-primary w-100"
                                >
                                    Send OTP
                                </button>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default ForgotPassword;