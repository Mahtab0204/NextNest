import { useEffect, useState } from "react";

import MainLayout from "../../layouts/MainLayout";

import featuredPaymentService
from "../../services/featuredPaymentService";

function OwnerFeaturedDashboard() {

    const [payments, setPayments] =
        useState([]);

    useEffect(() => {

        loadHistory();

    }, []);

    const loadHistory = async () => {

        try {

            const user =
                JSON.parse(
                    localStorage.getItem("user")
                );

            const response =
                await featuredPaymentService
                    .getOwnerHistory(
                        user.userId
                    );

            setPayments(
                response.data
            );

        } catch (error) {

            console.error(error);

        }
    };

    return (

        <MainLayout>

            <h2 className="fw-bold mb-4">
                ⭐ Featured Dashboard
            </h2>

            <div className="card shadow">

                <div className="card-body">

                    <table className="table">

                        <thead>

                            <tr>

                                <th>
                                    Apartment
                                </th>

                                <th>
                                    Plan
                                </th>

                                <th>
                                    Amount
                                </th>

                                <th>
                                    Payment Method
                                </th>

                                <th>
                                    Paid At
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                            {
                                payments.map(
                                    payment => (

                                        <tr
                                            key={payment.id}
                                        >

                                            <td>
                                                {
                                                    payment.apartmentTitle
                                                }
                                            </td>

                                            <td>
                                                {
                                                    payment.plan
                                                }
                                            </td>

                                            <td>
                                                ৳
                                                {
                                                    payment.amount
                                                }
                                            </td>

                                            <td>
                                                {
                                                    payment.paymentMethod
                                                }
                                            </td>

                                            <td>
                                                {
                                                    new Date(
                                                        payment.paidAt
                                                    )
                                                    .toLocaleDateString()
                                                }
                                            </td>

                                        </tr>

                                    )
                                )
                            }

                        </tbody>

                    </table>

                </div>

            </div>

        </MainLayout>
    );
}

export default OwnerFeaturedDashboard;