import React, { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import ApartmentCard from "../../components/ApartmentCard";
import ApartmentMap from "../../components/ApartmentMap";

import apartmentService from "../../services/apartmentService";
import locationService from "../../services/locationService";
import axiosInstance from "../../api/axios"; // Ensure this path matches your project structure

function ApartmentList({ purpose, pageTitle }) {
    // 1. Hook updates for URL manipulation
    const [searchParams, setSearchParams] = useSearchParams();
    const navigate = useNavigate();

    const [apartments, setApartments] = useState([]);
    const [locations, setLocations] = useState([]);
    const [loading, setLoading] = useState(true);

    // 2. Read ALL parameters from the URL (including AI generated ones)
    const urlKeyword = searchParams.get("keyword") || "";
    const urlArea = searchParams.get("area") || "";
    const urlBedrooms = searchParams.get("bedrooms") || "";
    const urlMinPrice = searchParams.get("minPrice") || "";
    const urlMaxPrice = searchParams.get("maxPrice") || "";
    const urlFurnishing = searchParams.get("furnishing") || "";

    // 3. Initialize Standard Filter State
    const [keyword, setKeyword] = useState(urlKeyword);
    const [area, setArea] = useState(urlArea);
    const [bedrooms, setBedrooms] = useState(urlBedrooms);
    const [minPrice, setMinPrice] = useState(urlMinPrice);
    const [maxPrice, setMaxPrice] = useState(urlMaxPrice);
    const [furnishing, setFurnishing] = useState(urlFurnishing);
    const [selectedPurpose, setSelectedPurpose] = useState(purpose);

    // 4. Initialize AI Search State
    const [aiQuery, setAiQuery] = useState("");
    const [isSearchingAi, setIsSearchingAi] = useState(false);

    useEffect(() => {
        loadLocations();
    }, []);

    // Watch for changes in the URL or the main purpose prop
    useEffect(() => {
        setKeyword(urlKeyword);
        setArea(urlArea);
        setBedrooms(urlBedrooms);
        setMinPrice(urlMinPrice);
        setMaxPrice(urlMaxPrice);
        setFurnishing(urlFurnishing);
        setSelectedPurpose(purpose);
        handleSearch();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [purpose, urlKeyword, urlArea, urlBedrooms, urlMinPrice, urlMaxPrice, urlFurnishing]);

    const loadLocations = async () => {
        try {
            const res = await locationService.getLocations();
            setLocations(res.data);
        } catch (err) {
            console.error(err);
        }
    };

    // Standard Search Logic
    const handleSearch = async () => {
        try {
            setLoading(true);
            let data = [];

            // Fetch base data
            if (area) {
                const res = await apartmentService.getApartmentsByArea(area, selectedPurpose);
                data = res.data;
            } else {
                const res = await apartmentService.getApartmentsByPurpose(selectedPurpose);
                data = res.data;
            }

            // Apply Filters
            if (keyword.trim()) {
                data = data.filter(apartment =>
                    apartment.title?.toLowerCase().includes(keyword.toLowerCase()) ||
                    apartment.description?.toLowerCase().includes(keyword.toLowerCase())
                );
            }

            if (bedrooms) {
                data = data.filter(apartment => apartment.bedrooms === Number(bedrooms));
            }

            if (minPrice) {
                data = data.filter(apartment => apartment.price >= Number(minPrice));
            }

            if (maxPrice) {
                data = data.filter(apartment => apartment.price <= Number(maxPrice));
            }

            if (furnishing) {
                data = data.filter(apartment => apartment.furnishing === furnishing);
            }

            setApartments(data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    // AI Smart Search Logic
    const handleAiSearch = async () => {
        if (!aiQuery.trim()) return;
        setIsSearchingAi(true);

        try {
            const response = await axiosInstance.get(`/v1/ai/smart-search?query=${aiQuery}`);
            const aiFilters = response.data;

            // Clone current URL parameters
            const newParams = new URLSearchParams(searchParams);

            // Apply AI extracted filters safely
            if (aiFilters.bedrooms) newParams.set("bedrooms", aiFilters.bedrooms);
            if (aiFilters.maxPrice) newParams.set("maxPrice", aiFilters.maxPrice);
            if (aiFilters.minPrice) newParams.set("minPrice", aiFilters.minPrice);
            if (aiFilters.furnishing) newParams.set("furnishing", aiFilters.furnishing.toUpperCase());
            if (aiFilters.locationKeyword) newParams.set("area", aiFilters.locationKeyword);

            // Update the URL! This automatically triggers your existing useEffect and handleSearch
            setSearchParams(newParams);
            setAiQuery(""); // Clear the input box after search

        } catch (error) {
            console.error("AI Smart Search failed", error);
        } finally {
            setIsSearchingAi(false);
        }
    };

    const resetFilters = () => {
        setKeyword("");
        setArea("");
        setBedrooms("");
        setMinPrice("");
        setMaxPrice("");
        setFurnishing("");
        navigate(selectedPurpose === "RENT" ? "/rent" : "/buy");
    };

    // Helper to get unique areas
    const uniqueAreas = [...new Set(locations.map(l => l.area))];

    return (
        <MainLayout>
            <div className="mb-4">
                <h2 className="fw-bold">{pageTitle}</h2>
                <p className="text-muted">Find your perfect apartment.</p>
            </div>

            <div className="card shadow border-0 mb-4">
                <div className="card-body">
                    
                    {/* --- AI SEARCH SECTION --- */}
                    <div className="row mb-3 pb-3 border-bottom">
                        <div className="col-12">
                            <div className="input-group shadow-sm rounded overflow-hidden">
                                <span className="input-group-text bg-primary text-white border-primary fw-bold">
                                    ✨ Ask AI
                                </span>
                                <input
                                    type="text"
                                    className="form-control border-primary"
                                    placeholder="E.g., Find me a furnished 2-bedroom flat under 30,000 BDT..."
                                    value={aiQuery}
                                    onChange={(e) => setAiQuery(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()}
                                    disabled={isSearchingAi}
                                />
                                <button
                                    className="btn btn-primary px-4 fw-bold"
                                    type="button"
                                    onClick={handleAiSearch}
                                    disabled={isSearchingAi || !aiQuery.trim()}
                                >
                                    {isSearchingAi ? "Thinking..." : "Apply Smart Filters"}
                                </button>
                            </div>
                            <small className="text-muted mt-2 d-block">
                                Type what you are looking for in plain English, and we will apply the filters below automatically!
                            </small>
                        </div>
                    </div>
                    {/* --- END AI SEARCH SECTION --- */}

                    {/* --- STANDARD FILTERS --- */}
                    <div className="row g-3">
                        <div className="col-md-2">
                            <input
                                type="text"
                                className="form-control"
                                placeholder="Apartment name..."
                                value={keyword}
                                onChange={(e) => setKeyword(e.target.value)}
                            />
                        </div>

                        <div className="col-md-2">
                            <select
                                className="form-select"
                                value={area}
                                onChange={(e) => setArea(e.target.value)}
                            >
                                <option value="">All Areas</option>
                                {uniqueAreas.map(area => (
                                    <option key={area} value={area}>{area}</option>
                                ))}
                            </select>
                        </div>

                        <div className="col-md-2">
                            <select
                                className="form-select"
                                value={bedrooms}
                                onChange={(e) => setBedrooms(e.target.value)}
                            >
                                <option value="">Bedrooms</option>
                                <option value="1">1 Bedroom</option>
                                <option value="2">2 Bedrooms</option>
                                <option value="3">3 Bedrooms</option>
                                <option value="4">4+ Bedrooms</option>
                            </select>
                        </div>

                        <div className="col-md-2">
                            <select
                                className="form-select"
                                value={furnishing}
                                onChange={(e) => setFurnishing(e.target.value)}
                            >
                                <option value="">Furnishing</option>
                                <option value="FURNISHED">Furnished</option>
                                <option value="UNFURNISHED">Unfurnished</option>
                                <option value="SEMI_FURNISHED">Semi-Furnished</option>
                            </select>
                        </div>

                        <div className="col-md-1">
                            <input
                                type="number"
                                className="form-control"
                                placeholder="Min Price"
                                value={minPrice}
                                onChange={(e) => setMinPrice(e.target.value)}
                            />
                        </div>

                        <div className="col-md-1">
                            <input
                                type="number"
                                className="form-control"
                                placeholder="Max Price"
                                value={maxPrice}
                                onChange={(e) => setMaxPrice(e.target.value)}
                            />
                        </div>

                        <div className="col-md-2 d-grid">
                            <button
                                className="btn btn-dark fw-bold"
                                onClick={() => {
                                    // Update URL manually when clicking Standard Search
                                    const params = new URLSearchParams();
                                    if (keyword) params.append("keyword", keyword);
                                    if (area) params.append("area", area);
                                    if (bedrooms) params.append("bedrooms", bedrooms);
                                    if (minPrice) params.append("minPrice", minPrice);
                                    if (maxPrice) params.append("maxPrice", maxPrice);
                                    if (furnishing) params.append("furnishing", furnishing);
                                    setSearchParams(params);
                                }}
                            >
                                Search
                            </button>
                        </div>
                    </div>

                    <div className="mt-3">
                        <button
                            className="btn btn-outline-secondary btn-sm"
                            onClick={resetFilters}
                        >
                            Reset Filters
                        </button>
                    </div>
                </div>
            </div>

            {loading ? (
                <div className="text-center py-5">
                    <div className="spinner-border text-primary" />
                </div>
            ) : (
                <>
                    {apartments.length > 0 && (
                        <div className="mb-4">
                            <ApartmentMap apartments={apartments} />
                        </div>
                    )}

                    <div className="row">
                        {apartments.length > 0 ? (
                            apartments.map(apartment => (
                                <ApartmentCard
                                    key={apartment.id}
                                    apartment={apartment}
                                />
                            ))
                        ) : (
                            <div className="col-12">
                                <div className="alert alert-info">
                                    No apartments found matching your criteria.
                                </div>
                            </div>
                        )}
                    </div>
                </>
            )}
        </MainLayout>
    );
}

export default ApartmentList;