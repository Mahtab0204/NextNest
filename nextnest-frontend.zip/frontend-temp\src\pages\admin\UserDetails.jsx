import {
    useEffect,
    useState
} from "react";

import {
    useParams,
    useNavigate
} from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import adminUserService from "../../services/adminUserService";

function UserDetails() {

    const { id } = useParams();

    const navigate = useNavigate();

    const [user, setUser] =
        useState(null);

    const [ownerData, setOwnerData] =
        useState(null);

    const [loading, setLoading] =
        useState(true);

    useEffect(() => {

        loadUser();

    }, [id]);

    const loadUser = async () => {

        try {

            const response =
                await adminUserService
                    .getUserById(id);

            const userData =
                response.data;

            setUser(userData);

            if (
                userData.role === "OWNER"
            ) {

                const ownerResponse =
                    await adminUserService
                        .getOwnerDetails(id);

                setOwnerData(
                    ownerResponse.data
                );
            }

        } catch (error) {

            console.error(
                "Failed to load user",
                error
            );

        } finally {

            setLoading(false);
        }
    };

    if (loading) {

        return (
            <MainLayout>

                <div className="container py-5 text-center">

                    <div className="spinner-border text-primary" />

                </div>

            </MainLayout>
        );
    }

    if (!user) {

        return (
            <MainLayout>

                <div className="container py-5">

                    <div className="alert alert-danger">

                        User not found.

                    </div>

                    <button
                        className="btn btn-secondary"
                        onClick={() =>
                            navigate(-1)
                        }
                    >
                        Back
                    </button>

                </div>

            </MainLayout>
        );
    }

    return (

        <MainLayout>

            <div className="container py-4">

                {/* USER DETAILS */}

                <div className="card shadow border-0 mb-4">

                    <div className="card-body">

                        <div className="d-flex justify-content-between align-items-center mb-4">

                            <h2 className="fw-bold mb-0">

                                User Details

                            </h2>

                            <button
                                className="btn btn-secondary"
                                onClick={() =>
                                    navigate(-1)
                                }
                            >
                                Back
                            </button>

                        </div>

                        <table className="table table-bordered align-middle">

                            <tbody>

                                <tr>
                                    <th width="250">
                                        ID
                                    </th>
                                    <td>
                                        {user.id}
                                    </td>
                                </tr>

                                <tr>
                                    <th>
                                        Full Name
                                    </th>
                                    <td>
                                        {user.fullName}
                                    </td>
                                </tr>

                                <tr>
                                    <th>
                                        Email
                                    </th>
                                    <td>
                                        {user.email}
                                    </td>
                                </tr>

                                <tr>
                                    <th>
                                        Phone
                                    </th>
                                    <td>
                                        {user.phone}
                                    </td>
                                </tr>

                                <tr>
                                    <th>
                                        Role
                                    </th>
                                    <td>

                                        <span className="badge bg-primary">

                                            {user.role}

                                        </span>

                                    </td>
                                </tr>

                                <tr>
                                    <th>
                                        Account Status
                                    </th>
                                    <td>

                                        <span
                                            className={
                                                user.accountStatus ===
                                                "ACTIVE"
                                                    ? "badge bg-success"
                                                    : "badge bg-warning text-dark"
                                            }
                                        >
                                            {user.accountStatus}
                                        </span>

                                    </td>
                                </tr>

                                <tr>
                                    <th>
                                        Email Verification
                                    </th>
                                    <td>

                                        {user.verified ? (

                                            <span className="badge bg-success">

                                                Verified

                                            </span>

                                        ) : (

                                            <span className="badge bg-danger">

                                                Not Verified

                                            </span>

                                        )}

                                    </td>
                                </tr>

                                <tr>
                                    <th>
                                        Account Enabled
                                    </th>
                                    <td>

                                        {user.enabled ? (

                                            <span className="badge bg-success">

                                                Enabled

                                            </span>

                                        ) : (

                                            <span className="badge bg-danger">

                                                Disabled

                                            </span>

                                        )}

                                    </td>
                                </tr>

                            </tbody>

                        </table>

                    </div>

                </div>

                {/* OWNER SECTION */}

                {
                    user.role === "OWNER" &&
                    ownerData && (

                        <>

                            {/* OWNER SUMMARY */}

                            <div className="card shadow border-0 mb-4">

                                <div className="card-body">

                                    <h4 className="fw-bold mb-4">

                                        Owner Summary

                                    </h4>

                                    <div className="row text-center">

                                        <div className="col-md-3 mb-3">

                                            <div className="card border-0 bg-primary text-white">

                                                <div className="card-body">

                                                    <h2>

                                                        {ownerData.totalProperties}

                                                    </h2>

                                                    <p className="mb-0">

                                                        Total Properties

                                                    </p>

                                                </div>

                                            </div>

                                        </div>

                                        <div className="col-md-3 mb-3">

                                            <div className="card border-0 bg-success text-white">

                                                <div className="card-body">

                                                    <h2>

                                                        {ownerData.approvedProperties}

                                                    </h2>

                                                    <p className="mb-0">

                                                        Approved

                                                    </p>

                                                </div>

                                            </div>

                                        </div>

                                        <div className="col-md-3 mb-3">

                                            <div className="card border-0 bg-warning">

                                                <div className="card-body">

                                                    <h2>

                                                        {ownerData.pendingProperties}

                                                    </h2>

                                                    <p className="mb-0">

                                                        Pending

                                                    </p>

                                                </div>

                                            </div>

                                        </div>

                                        <div className="col-md-3 mb-3">

                                            <div className="card border-0 bg-danger text-white">

                                                <div className="card-body">

                                                    <h2>

                                                        {ownerData.rejectedProperties}

                                                    </h2>

                                                    <p className="mb-0">

                                                        Rejected

                                                    </p>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                            {/* OWNER APARTMENTS */}

                            <div className="card shadow border-0">

                                <div className="card-body">

                                    <h4 className="fw-bold mb-4">

                                        Owner Properties

                                    </h4>

                                    {
                                        ownerData.apartments?.length === 0 ? (

                                            <div className="alert alert-info">

                                                This owner has not listed any properties.

                                            </div>

                                        ) : (

                                            <div className="table-responsive">

                                                <table className="table table-hover align-middle">

                                                    <thead className="table-light">

                                                        <tr>

                                                            <th>ID</th>

                                                            <th>Title</th>

                                                            <th>Type</th>

                                                            <th>Purpose</th>

                                                            <th>Price</th>

                                                            <th>Status</th>

                                                            <th>Approval</th>

                                                            <th>Action</th>

                                                        </tr>

                                                    </thead>

                                                    <tbody>

                                                        {
                                                            ownerData.apartments.map(
                                                                apartment => (

                                                                    <tr
                                                                        key={
                                                                            apartment.id
                                                                        }
                                                                    >

                                                                        <td>

                                                                            {apartment.id}

                                                                        </td>

                                                                        <td>

                                                                            {apartment.title}

                                                                        </td>

                                                                        <td>

                                                                            {apartment.propertyType}

                                                                        </td>

                                                                        <td>

                                                                            {apartment.purpose}

                                                                        </td>

                                                                        <td>

                                                                            ৳ {apartment.price?.toLocaleString()}

                                                                        </td>

                                                                        <td>

                                                                            <span className="badge bg-primary">

                                                                                {apartment.status}

                                                                            </span>

                                                                        </td>

                                                                        <td>

                                                                            <span
                                                                                className={
                                                                                    apartment.approvalStatus === "APPROVED"
                                                                                        ? "badge bg-success"
                                                                                        : apartment.approvalStatus === "PENDING"
                                                                                        ? "badge bg-warning text-dark"
                                                                                        : "badge bg-danger"
                                                                                }
                                                                            >

                                                                                {apartment.approvalStatus}

                                                                            </span>

                                                                        </td>

                                                                        <td>

                                                                            <button
                                                                                className="btn btn-sm btn-primary"
                                                                                onClick={() =>
                                                                                    navigate(
                                                                                        `/apartments/${apartment.id}`
                                                                                    )
                                                                                }
                                                                            >
                                                                                View
                                                                            </button>

                                                                        </td>

                                                                    </tr>

                                                                )
                                                            )
                                                        }

                                                    </tbody>

                                                </table>

                                            </div>

                                        )
                                    }

                                </div>

                            </div>

                        </>

                    )
                }

            </div>

        </MainLayout>

    );
}

export default UserDetails;