import { useEffect, useState } from "react";
import axiosInstance from "../../api/axios.js";
import MainLayout from "../../layouts/MainLayout";
import apartmentService from "../../services/apartmentService";
import locationService from "../../services/locationService";

// Leaflet Map Imports
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

// Fix Leaflet's default icon path issues
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: markerIcon2x,
    iconUrl: markerIcon,
    shadowUrl: markerShadow
});

const STORAGE_KEY = "createApartmentForm";

const propertyFeatures = [
    "SECURITY",
    "CCTV",
    "LIFT",
    "ELECTRICITY",
    "GENERATOR",
    "WASA_CONNECTION",
    "HOT_WATER",
    "GAS_LINE",
    "CYLINDER_GAS",
    "WIFI_CONNECTIVITY",
    "PARKING",
    "MOSQUE_PRAYER_ROOM",
    "CHILD_PLAYGROUND",
    "GYM",
    "COMMUNITY_HALL",
    "ROOFTOP_ACCESS",
    "PET_FRIENDLY"
];

// --- MAP COMPONENTS ---

// 1. Handles clicking on the map to drop a pin
function LocationPicker({ setLatitude, setLongitude, position }) {
    useMapEvents({
        click(e) {
            setLatitude(e.latlng.lat.toFixed(6));
            setLongitude(e.latlng.lng.toFixed(6));
        },
    });

    const isValidPosition = position && !isNaN(position[0]) && !isNaN(position[1]) && position[0] !== "" && position[1] !== "";
    return isValidPosition ? <Marker position={position} /> : null;
}

// 2. Handles smoothly panning the camera when a dropdown location is selected
function MapUpdater({ center }) {
    const map = useMap();
    useEffect(() => {
        if (center) {
            map.flyTo(center, 14, { animate: true, duration: 1.5 });
        }
    }, [center, map]);
    return null;
}

function CreateApartment() {

    const [isGeneratingAi, setIsGeneratingAi] = useState(false);
    
    // Map center state for camera panning
    const [mapCenter, setMapCenter] = useState([23.8103, 90.4125]); 

    const initialForm = {
        title: "",
        description: "",
        purpose: "RENT",
        listingScope: "UNIT",
        propertyType: "FLAT",
        price: "",
        sizeSqFt: "",
        bedrooms: "",
        bathrooms: "",
        balconies: "",
        floorNo: "",
        totalFloor: "",
        parkingSpaces: "",
        totalUnits: "",
        landAreaSqFt: "",
        yearBuilt: "",
        furnishing: "SEMI_FURNISHED",
        address: "",
        postalCode: "",
        latitude: "",
        longitude: "",
        contactName: "",
        contactPhone: "",
        contactEmail: "",
        negotiable: false,
        available: true,
        locationId: "",
        availableFrom: ""
    };

    const [formData, setFormData] = useState(initialForm);
    const [features, setFeatures] = useState([]);
    const [locations, setLocations] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            try {
                const parsed = JSON.parse(saved);
                if (parsed.formData) {
                    setFormData({
                        ...initialForm,
                        ...parsed.formData,
                        listingScope: parsed.formData.listingScope || "UNIT"
                    });
                }
                if (Array.isArray(parsed.features)) {
                    setFeatures(parsed.features);
                }
            } catch (error) {
                console.error("Failed to restore draft:", error);
            }
        }
        loadLocations();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({ formData, features }));
    }, [formData, features]);

    // Automatically fly to the selected location
    useEffect(() => {
        const geocodeLocation = async () => {
            if (!formData.locationId || locations.length === 0) return;

            // Find the selected location object
            const selectedLoc = locations.find(l => l.id === Number(formData.locationId));
            if (!selectedLoc) return;

            // Build a search query for OpenStreetMap
            const query = `${selectedLoc.subArea || ''} ${selectedLoc.area || ''} ${selectedLoc.city || ''} Bangladesh`.trim();

            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
                const data = await response.json();

                if (data && data.length > 0) {
                    // Update the map's center coordinates to fly to the new area
                    const newLat = parseFloat(data[0].lat);
                    const newLng = parseFloat(data[0].lon);
                    setMapCenter([newLat, newLng]);
                }
            } catch (error) {
                console.error("Geocoding failed:", error);
            }
        };

        geocodeLocation();
    }, [formData.locationId, locations]);

    const loadLocations = async () => {
        try {
            const response = await locationService.getLocations();
            setLocations(response.data);
        } catch (error) {
            console.error("Failed to load locations:", error);
        }
    };

    const handleAddressSearch = async () => {
        if (!formData.address.trim()) return;

        // Try to append the city from the dropdown if it exists to make the search more accurate
        let searchQuery = formData.address;
        if (formData.locationId && locations.length > 0) {
            const selectedLoc = locations.find(l => l.id === Number(formData.locationId));
            if (selectedLoc && !searchQuery.toLowerCase().includes(selectedLoc.city.toLowerCase())) {
                searchQuery = `${formData.address}, ${selectedLoc.city}, Bangladesh`;
            }
        }

        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}`);
            const data = await response.json();

            if (data && data.length > 0) {
                const newLat = parseFloat(data[0].lat).toFixed(6);
                const newLng = parseFloat(data[0].lon).toFixed(6);
                
                // Fly the map to the location
                setMapCenter([newLat, newLng]);
                
                // Automatically drop the pin there too!
                setFormData(prev => ({
                    ...prev,
                    latitude: newLat,
                    longitude: newLng
                }));
            } else {
                alert("Could not find this exact address on the map. Try simplifying it (e.g., 'Road 1, Block F, Mohammadpur').");
            }
        } catch (error) {
            console.error("Address geocoding failed:", error);
        }
    };

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        let newValue;

        if (name === "listingScope") {
            if (value === "BUILDING") {
                setFormData((prev) => ({
                    ...prev,
                    listingScope: "BUILDING",
                    propertyType: "APARTMENT",
                    bedrooms: "",
                    bathrooms: "",
                    balconies: "",
                    floorNo: "",
                    furnishing: "UNFURNISHED"
                }));
            } else {
                setFormData((prev) => ({
                    ...prev,
                    listingScope: "UNIT",
                    propertyType: prev.propertyType === "APARTMENT" ? "FLAT" : prev.propertyType,
                    totalUnits: "",
                    landAreaSqFt: "",
                    yearBuilt: ""
                }));
            }
            return;
        }

        if (type === "checkbox") {
            newValue = checked;
        } else if (type === "number") {
            newValue = value === "" ? "" : Number(value);
        } else if (name === "locationId") {
            newValue = value === "" ? "" : Number(value);
        } else {
            newValue = value;
        }

        setFormData((prev) => ({ ...prev, [name]: newValue }));
    };

    const handlePropertyTypeChange = (e) => {
        const propertyType = e.target.value;
        setFormData((prev) => ({ ...prev, propertyType }));
    };

    const handleFeatureChange = (feature) => {
        setFeatures((prevFeatures) =>
            prevFeatures.includes(feature)
                ? prevFeatures.filter((item) => item !== feature)
                : [...prevFeatures, feature]
        );
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            setLoading(true);
            const apartmentData = { ...formData, features };

            if (formData.listingScope === "UNIT") {
                apartmentData.totalUnits = null;
                apartmentData.landAreaSqFt = null;
                apartmentData.yearBuilt = null;
            }

            if (formData.listingScope === "BUILDING") {
                apartmentData.bedrooms = null;
                apartmentData.bathrooms = null;
                apartmentData.balconies = null;
                apartmentData.floorNo = null;
                apartmentData.furnishing = null;
            }

            await apartmentService.createApartment(apartmentData);
            alert("Apartment Created Successfully.");

            localStorage.removeItem(STORAGE_KEY);
            setFormData(initialForm);
            setFeatures([]);
        } catch (error) {
            console.error("Create apartment error:", error);
            const message = error?.response?.data?.message || "Failed to Create Apartment.";
            alert(message);
        } finally {
            setLoading(false);
        }
    };

    const resetForm = () => {
        if (window.confirm("Clear all entered data?")) {
            localStorage.removeItem(STORAGE_KEY);
            setFormData(initialForm);
            setFeatures([]);
        }
    };

    const handleGenerateAiDescription = async () => {
        setIsGeneratingAi(true);
        try {
            const response = await axiosInstance.post('/v1/ai/generate-description', formData);
            setFormData(prev => ({ ...prev, description: response.data }));
        } catch (error) {
            console.error("Failed to generate description", error);
        } finally {
            setIsGeneratingAi(false);
        }
    };

    return (
        <MainLayout>
            <div className="container py-5">
                <div className="card shadow-lg border-0 rounded-4">
                    <div className="card-header bg-primary text-white rounded-top-4 p-4">
                        <h2 className="mb-1">🏢 Create Property Listing</h2>
                        <p className="mb-0 opacity-75">
                            Add your property details, facilities and contact information.
                        </p>
                    </div>

                    <div className="card-body p-4">
                        <form onSubmit={handleSubmit}>

                            <h4 className="mb-4">🏠 What are you listing?</h4>
                            <div className="row g-3 mb-4">
                                <div className="col-md-6">
                                    <div
                                        className={`border rounded-4 p-4 h-100 ${formData.listingScope === "UNIT" ? "border-primary bg-primary bg-opacity-10" : "bg-light"}`}
                                        style={{ cursor: "pointer", transition: "all 0.2s ease" }}
                                        onClick={() => handleChange({ target: { name: "listingScope", value: "UNIT" } })}
                                    >
                                        <div className="d-flex align-items-start">
                                            <div className="form-check me-3">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="listingScope"
                                                    value="UNIT"
                                                    checked={formData.listingScope === "UNIT"}
                                                    onChange={handleChange}
                                                />
                                            </div>
                                            <div>
                                                <h5 className="fw-bold mb-1">🏠 Individual Unit</h5>
                                                <p className="text-muted mb-0">List a flat, duplex, studio, penthouse or condominium.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="col-md-6">
                                    <div
                                        className={`border rounded-4 p-4 h-100 ${formData.listingScope === "BUILDING" ? "border-primary bg-primary bg-opacity-10" : "bg-light"}`}
                                        style={{ cursor: "pointer", transition: "all 0.2s ease" }}
                                        onClick={() => handleChange({ target: { name: "listingScope", value: "BUILDING" } })}
                                    >
                                        <div className="d-flex align-items-start">
                                            <div className="form-check me-3">
                                                <input
                                                    type="radio"
                                                    className="form-check-input"
                                                    name="listingScope"
                                                    value="BUILDING"
                                                    checked={formData.listingScope === "BUILDING"}
                                                    onChange={handleChange}
                                                />
                                            </div>
                                            <div>
                                                <h5 className="fw-bold mb-1">🏢 Entire Building</h5>
                                                <p className="text-muted mb-0">List an entire residential building or apartment complex.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr className="my-5" />

                            <h4 className="mb-4">📋 Basic Information</h4>
                            <div className="row">
                                <div className="col-md-6 mb-3">
                                    <label className="form-label fw-bold">Title</label>
                                    <input
                                        type="text"
                                        name="title"
                                        className="form-control"
                                        value={formData.title}
                                        onChange={handleChange}
                                        placeholder={formData.listingScope === "BUILDING" ? "e.g. Modern 8-Storey Apartment Building" : "e.g. Luxury 3 Bedroom Flat"}
                                        required
                                    />
                                </div>

                                <div className="col-md-6 mb-3">
                                    <label className="form-label fw-bold">Purpose</label>
                                    <select
                                        className="form-select"
                                        name="purpose"
                                        value={formData.purpose}
                                        onChange={handleChange}
                                    >
                                        <option value="RENT">Rent</option>
                                        <option value="SALE">Sale</option>
                                    </select>
                                </div>
                            </div>

                            <div className="mb-4">
                                <div className="d-flex justify-content-between align-items-center mb-2">
                                    <label className="form-label fw-bold mb-0">Description</label>
                                    <button
                                        type="button"
                                        className="btn btn-sm btn-outline-primary"
                                        onClick={handleGenerateAiDescription}
                                        disabled={isGeneratingAi}
                                    >
                                        {isGeneratingAi ? (
                                            <>
                                                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                                                Generating...
                                            </>
                                        ) : (
                                            <>✨ Auto-Generate with AI</>
                                        )}
                                    </button>
                                </div>
                                <textarea
                                    rows="4"
                                    className="form-control"
                                    name="description"
                                    value={formData.description}
                                    onChange={handleChange}
                                    placeholder={formData.listingScope === "BUILDING" ? "Describe the building, facilities, location and overall condition..." : "Describe the property, rooms, facilities and surroundings..."}
                                />
                            </div>

                            <hr className="my-5" />

                            <h4 className="mb-4">🏡 Property Details</h4>
                            <div className="row">
                                <div className="col-lg-4 mb-3">
                                    <label className="form-label fw-bold">Property Type</label>
                                    <select
                                        className="form-select"
                                        name="propertyType"
                                        value={formData.propertyType}
                                        onChange={handlePropertyTypeChange}
                                        disabled={formData.listingScope === "BUILDING"}
                                    >
                                        {formData.listingScope === "BUILDING" ? (
                                            <option value="APARTMENT">Entire Apartment Building</option>
                                        ) : (
                                            <>
                                                <option value="FLAT">Flat</option>
                                                <option value="DUPLEX">Duplex</option>
                                                <option value="PENTHOUSE">Penthouse</option>
                                                <option value="STUDIO">Studio</option>
                                                <option value="CONDOMINIUM">Condominium</option>
                                            </>
                                        )}
                                    </select>
                                </div>

                                {formData.listingScope === "UNIT" && (
                                    <div className="col-lg-4 mb-3">
                                        <label className="form-label fw-bold">Furnishing</label>
                                        <select
                                            className="form-select"
                                            name="furnishing"
                                            value={formData.furnishing}
                                            onChange={handleChange}
                                        >
                                            <option value="UNFURNISHED">Unfurnished</option>
                                            <option value="SEMI_FURNISHED">Semi Furnished</option>
                                            <option value="FULLY_FURNISHED">Fully Furnished</option>
                                        </select>
                                    </div>
                                )}

                                <div className="col-lg-4 mb-3">
                                    <label className="form-label fw-bold">Available From</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        name="availableFrom"
                                        value={formData.availableFrom}
                                        onChange={handleChange}
                                    />
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-6 mb-3">
                                    <label className="form-label fw-bold">Price</label>
                                    <input
                                        type="number"
                                        min="0"
                                        className="form-control"
                                        name="price"
                                        value={formData.price}
                                        onChange={handleChange}
                                        placeholder="Enter price"
                                        required
                                    />
                                </div>
                                <div className="col-md-6 mb-3">
                                    <label className="form-label fw-bold">
                                        {formData.listingScope === "BUILDING" ? "Building Size (Sq Ft)" : "Property Size (Sq Ft)"}
                                    </label>
                                    <input
                                        type="number"
                                        min="0"
                                        className="form-control"
                                        name="sizeSqFt"
                                        value={formData.sizeSqFt}
                                        onChange={handleChange}
                                        placeholder="e.g. 1500"
                                    />
                                </div>
                            </div>

                            {formData.listingScope === "UNIT" && (
                                <>
                                    <div className="alert alert-info border-0">
                                        <strong>Unit Information</strong>
                                        <div className="small mt-1">Add the room and floor information for this individual property.</div>
                                    </div>
                                    <div className="row">
                                        {[
                                            ["bedrooms", "Bedrooms"],
                                            ["bathrooms", "Bathrooms"],
                                            ["balconies", "Balconies"],
                                            ["parkingSpaces", "Parking Spaces"]
                                        ].map(([name, label]) => (
                                            <div className="col-md-3 mb-3" key={name}>
                                                <label className="form-label fw-bold">{label}</label>
                                                <input
                                                    type="number"
                                                    min="0"
                                                    className="form-control"
                                                    name={name}
                                                    value={formData[name]}
                                                    onChange={handleChange}
                                                />
                                            </div>
                                        ))}
                                    </div>
                                    <div className="row">
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-bold">Floor No</label>
                                            <input
                                                type="number"
                                                min="0"
                                                className="form-control"
                                                name="floorNo"
                                                value={formData.floorNo}
                                                onChange={handleChange}
                                                placeholder="e.g. 5"
                                            />
                                        </div>
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-bold">Total Floors</label>
                                            <input
                                                type="number"
                                                min="1"
                                                className="form-control"
                                                name="totalFloor"
                                                value={formData.totalFloor}
                                                onChange={handleChange}
                                                placeholder="e.g. 10"
                                            />
                                        </div>
                                    </div>
                                </>
                            )}

                            {formData.listingScope === "BUILDING" && (
                                <>
                                    <div className="alert alert-primary border-0">
                                        <strong>🏢 Building Information</strong>
                                        <div className="small mt-1">Add information about the entire building rather than an individual apartment unit.</div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-4 mb-3">
                                            <label className="form-label fw-bold">Total Floors</label>
                                            <input
                                                type="number"
                                                min="1"
                                                className="form-control"
                                                name="totalFloor"
                                                value={formData.totalFloor}
                                                onChange={handleChange}
                                                placeholder="e.g. 8"
                                                required
                                            />
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <label className="form-label fw-bold">Total Units</label>
                                            <input
                                                type="number"
                                                min="1"
                                                className="form-control"
                                                name="totalUnits"
                                                value={formData.totalUnits}
                                                onChange={handleChange}
                                                placeholder="e.g. 32"
                                                required
                                            />
                                        </div>
                                        <div className="col-md-4 mb-3">
                                            <label className="form-label fw-bold">Land Area (Sq Ft)</label>
                                            <input
                                                type="number"
                                                min="0"
                                                step="any"
                                                className="form-control"
                                                name="landAreaSqFt"
                                                value={formData.landAreaSqFt}
                                                onChange={handleChange}
                                                placeholder="e.g. 5000"
                                                required
                                            />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-bold">Year Built</label>
                                            <input
                                                type="number"
                                                min="1800"
                                                max={new Date().getFullYear()}
                                                className="form-control"
                                                name="yearBuilt"
                                                value={formData.yearBuilt}
                                                onChange={handleChange}
                                                placeholder="e.g. 2023"
                                            />
                                        </div>
                                        <div className="col-md-6 mb-3">
                                            <label className="form-label fw-bold">Parking Spaces</label>
                                            <input
                                                type="number"
                                                min="0"
                                                className="form-control"
                                                name="parkingSpaces"
                                                value={formData.parkingSpaces}
                                                onChange={handleChange}
                                                placeholder="e.g. 20"
                                            />
                                        </div>
                                    </div>
                                </>
                            )}

                            <hr className="my-5" />

                            <h4 className="mb-4">📍 Location Information</h4>
                            <div className="row">
                                <div className="col-lg-6 mb-3">
                                    <label className="form-label fw-bold">Address</label>
                                    <div className="input-group">
                                        <input
                                            type="text"
                                            className="form-control"
                                            name="address"
                                            value={formData.address}
                                            onChange={handleChange}
                                            placeholder="e.g. Near Road 1, Block F, Mohammadpur"
                                        />
                                        <button 
                                            type="button" 
                                            className="btn btn-primary fw-bold"
                                            onClick={handleAddressSearch}
                                        >
                                            🔍 Find on Map
                                        </button>
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label className="form-label fw-bold">Postal Code</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        name="postalCode"
                                        value={formData.postalCode}
                                        onChange={handleChange}
                                    />
                                </div>
                            </div>
                            
                            <div className="mb-4">
                                <label className="form-label fw-bold">Select Location</label>
                                <select
                                    className="form-select"
                                    name="locationId"
                                    value={formData.locationId}
                                    onChange={handleChange}
                                    required
                                >
                                    <option value="">Select Location</option>
                                    {locations.map((location) => (
                                        <option key={location.id} value={location.id}>
                                            {location.city} - {location.area} - {location.subArea}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            {/* --- INTERACTIVE MAP COORDINATE SECTION --- */}
                            <div className="mb-4 card shadow-sm border-0 bg-light p-3">
                                <div className="card-body p-0">
                                    <label className="form-label fw-bold mb-1">📍 Apartment Coordinates</label>
                                    <p className="text-muted small mb-3">
                                        Select a location from the dropdown above to center the map, then click on the map to drop a pin.
                                    </p>
                                    
                                    <div className="row g-3 mb-3">
                                        <div className="col-md-6">
                                            <div className="input-group">
                                                <span className="input-group-text bg-white text-secondary">Lat</span>
                                                <input 
                                                    type="number" 
                                                    step="any"
                                                    name="latitude"
                                                    className="form-control" 
                                                    value={formData.latitude} 
                                                    placeholder="e.g., 23.7939"
                                                    onChange={handleChange} 
                                                />
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <div className="input-group">
                                                <span className="input-group-text bg-white text-secondary">Lng</span>
                                                <input 
                                                    type="number" 
                                                    step="any"
                                                    name="longitude"
                                                    className="form-control" 
                                                    value={formData.longitude} 
                                                    placeholder="e.g., 90.4042"
                                                    onChange={handleChange} 
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="border border-secondary rounded-3 overflow-hidden shadow-sm" style={{ height: "350px", width: "100%", zIndex: 0 }}>
                                        <MapContainer 
                                            center={mapCenter} 
                                            zoom={12} 
                                            style={{ height: "100%", width: "100%" }}
                                        >
                                            <TileLayer
                                                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                                attribution='&copy; OpenStreetMap contributors'
                                            />
                                            
                                            {/* Updates the view camera smoothly */}
                                            <MapUpdater center={mapCenter} />

                                            <LocationPicker 
                                                setLatitude={(lat) => setFormData((prev) => ({ ...prev, latitude: lat }))}
                                                setLongitude={(lng) => setFormData((prev) => ({ ...prev, longitude: lng }))}
                                                position={
                                                    formData.latitude && formData.longitude && !isNaN(parseFloat(formData.latitude)) && !isNaN(parseFloat(formData.longitude))
                                                    ? [parseFloat(formData.latitude), parseFloat(formData.longitude)] 
                                                    : null
                                                }
                                            />
                                        </MapContainer>
                                    </div>
                                </div>
                            </div>
                            {/* --- END INTERACTIVE MAP SECTION --- */}

                            <hr className="my-5" />

                            <h4 className="mb-4">👤 Contact Information</h4>
                            <div className="row">
                                {[
                                    ["contactName", "Contact Name", "text"],
                                    ["contactPhone", "Contact Phone", "text"],
                                    ["contactEmail", "Contact Email", "email"]
                                ].map(([name, label, type]) => (
                                    <div className="col-md-4 mb-3" key={name}>
                                        <label className="form-label fw-bold">{label}</label>
                                        <input
                                            type={type}
                                            className="form-control"
                                            name={name}
                                            value={formData[name]}
                                            onChange={handleChange}
                                            placeholder={label}
                                        />
                                    </div>
                                ))}
                            </div>

                            <hr className="my-5" />

                            <h4 className="mb-4">⚙ Property Status</h4>
                            <div className="row">
                                <div className="col-md-6 mb-3">
                                    <div className="form-check form-switch">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            name="negotiable"
                                            checked={formData.negotiable}
                                            onChange={handleChange}
                                        />
                                        <label className="form-check-label">Price is negotiable</label>
                                    </div>
                                </div>
                                <div className="col-md-6 mb-3">
                                    <div className="form-check form-switch">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            name="available"
                                            checked={formData.available}
                                            onChange={handleChange}
                                        />
                                        <label className="form-check-label">Currently Available</label>
                                    </div>
                                </div>
                            </div>

                            <hr className="my-5" />

                            <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
                                <div>
                                    <h4 className="mb-1">✨ Property Features</h4>
                                    <p className="text-muted mb-0">Select only the facilities available with this property.</p>
                                </div>
                                <span className="badge bg-primary fs-6">{features.length} Selected</span>
                            </div>
                            <div className="row g-3">
                                {propertyFeatures.map((feature) => {
                                    const selected = features.includes(feature);
                                    return (
                                        <div className="col-md-4 col-lg-3" key={feature}>
                                            <div
                                                className={`border rounded-3 p-3 h-100 ${selected ? "border-primary bg-primary bg-opacity-10" : "bg-light"}`}
                                                style={{ cursor: "pointer", transition: "all 0.2s ease" }}
                                                onClick={() => handleFeatureChange(feature)}
                                            >
                                                <div className="form-check">
                                                    <input
                                                        type="checkbox"
                                                        className="form-check-input"
                                                        checked={selected}
                                                        onChange={() => handleFeatureChange(feature)}
                                                        onClick={(e) => e.stopPropagation()}
                                                    />
                                                    <label className={`form-check-label fw-semibold ${selected ? "text-primary" : ""}`}>
                                                        {feature.replaceAll("_", " ")}
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>

                            <hr className="my-5" />

                            <div className="d-flex justify-content-between flex-wrap gap-3">
                                <button
                                    type="button"
                                    className="btn btn-outline-danger btn-lg px-4"
                                    onClick={resetForm}
                                >
                                    🗑 Clear Form
                                </button>
                                <button
                                    type="submit"
                                    className="btn btn-primary btn-lg px-5"
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <>
                                            <span className="spinner-border spinner-border-sm me-2" />
                                            Creating...
                                        </>
                                    ) : (
                                        <>🏢 Create Listing</>
                                    )}
                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </MainLayout>
    );
}

export default CreateApartment;