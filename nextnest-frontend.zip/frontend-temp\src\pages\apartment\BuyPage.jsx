import ApartmentList from "./ApartmentList";

function BuyPage() {

    return (
        <ApartmentList
            purpose="SALE"
            pageTitle="Apartments For Sale"
        />
    );
}

export default BuyPage;