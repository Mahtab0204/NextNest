import api from "../api/axios";

const getNotifications = () => {
    return api.get(
        "/notifications"
    );
};

const getUnreadCount = () => {
    return api.get(
        "/notifications/unread-count"
    );
};

const markAsRead = (id) => {
    return api.patch(
        `/notifications/${id}/read`
    );
};

const notificationService = {

    getNotifications,

    getUnreadCount,

    markAsRead
};

export default notificationService;