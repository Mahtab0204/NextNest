import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";

import MainLayout from "../../layouts/MainLayout";
import apartmentService from "../../services/apartmentService";

function AdminApartmentDetails() {

    const { id } = useParams();

    const navigate = useNavigate();

    const [loading, setLoading] =
        useState(true);

    const [apartment, setApartment] =
        useState(null);

    const [rejectionReason,
       setRejectionReason] =
       useState("");

    const loadApartment = async () => {

        try {

            const response =
                await apartmentService
                    .getAdminApartmentDetails(id);

            setApartment(
                response.data
            );

        } catch (error) {

            toast.error(
                "Failed to load apartment details"
            );

        } finally {

            setLoading(false);

        }
    };

    useEffect(() => {

        loadApartment();

    }, [id]);

    const handleApprove = async () => {

        try {

            await apartmentService
                .approveApartment(id);

            toast.success(
                "Apartment approved"
            );

            navigate(
                "/admin/apartments"
            );

        } catch {

            toast.error(
                "Approval failed"
            );
        }
    };

   const handleReject =
    async () => {

    if (
        !rejectionReason.trim()
    ) {

        toast.warning(
            "Please enter rejection reason"
        );

        return;
    }

    try {

        await apartmentService
                .rejectApartment(
                    apartment.id,
                    rejectionReason
                );

        toast.success(
            "Apartment rejected"
        );

        navigate(
            "/admin/apartments"
        );

    } catch {

        toast.error(
            "Failed to reject apartment"
        );
    }
};

    if (loading) {

        return (

            <MainLayout>

                <div className="text-center mt-5">

                    <div className="spinner-border text-primary" />

                </div>

            </MainLayout>

        );
    }

return (
    <MainLayout>
        <div className="container py-4">

            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="fw-bold mb-0">Apartment Review</h2>
                <button
                    className="btn btn-secondary btn-sm"
                    onClick={() => navigate("/admin/apartments")}
                >
                    Back
                </button>
            </div>

            {/* Apartment Information */}
            <div className="card shadow border-0 mb-4">
                <div className="card-header bg-white">
                    <h4 className="mb-0">Apartment Information</h4>
                </div>

                <div className="card-body">
                    <div className="row">

                        <div className="col-md-6 mb-3">
                            <strong>Title:</strong><br />
                            {apartment.title}
                        </div>

                        <div className="col-md-6 mb-3">
                            <strong>Purpose:</strong><br />
                            {apartment.purpose}
                        </div>

                        <div className="col-md-6 mb-3">
                            <strong>Property Type:</strong><br />
                            {apartment.propertyType}
                        </div>

                        <div className="col-md-6 mb-3">
                            <strong>Price:</strong><br />
                            ৳ {apartment.price?.toLocaleString()}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Bedrooms:</strong><br />
                            {apartment.bedrooms}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Bathrooms:</strong><br />
                            {apartment.bathrooms}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Balconies:</strong><br />
                            {apartment.balconies}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Floor:</strong><br />
                            {apartment.floorNo}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Total Floors:</strong><br />
                            {apartment.totalFloor}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Size:</strong><br />
                            {apartment.sizeSqFt} sqft
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Parking Spaces:</strong><br />
                            {apartment.parkingSpaces}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Furnishing:</strong><br />
                            {apartment.furnishing}
                        </div>

                        <div className="col-md-4 mb-3">
                            <strong>Status:</strong><br />
                            {apartment.status}
                        </div>

                        <div className="col-md-12 mb-3">
                            <strong>Address:</strong><br />
                            {apartment.address}
                        </div>

                        <div className="col-md-12 mb-3">
                            <strong>Description:</strong><br />
                            {apartment.description}
                        </div>

                    </div>
                </div>
            </div>

            {/* Owner Information */}
            <div className="card shadow border-0 mb-4">
                <div className="card-header bg-white">
                    <h4 className="mb-0">Owner Information</h4>
                </div>

                <div className="card-body">
                    <div className="row">

                        <div className="col-md-4 mb-3 mb-md-0">
                            <strong>Name:</strong><br />
                            {apartment.ownerName}
                        </div>

                        <div className="col-md-4 mb-3 mb-md-0">
                            <strong>Email:</strong><br />
                            {apartment.ownerEmail}
                        </div>

                        <div className="col-md-4">
                            <strong>Phone:</strong><br />
                            {apartment.ownerPhone}
                        </div>

                    </div>
                </div>
            </div>

            {/* Images */}
            <div className="card shadow border-0 mb-4">
                <div className="card-header bg-white">
                    <h4 className="mb-0">Apartment Images</h4>
                </div>

                <div className="card-body">
                    <div className="row">

                        {apartment.images?.length > 0 ? (
                            apartment.images.map(image => (
                                <div
                                    key={image.id}
                                    className="col-md-4 mb-3"
                                >
                                    <img
                                        src={`http://localhost:8080/uploads/${image.imageUrl}`}
                                        alt="Apartment"
                                        className="img-fluid rounded shadow-sm"
                                        style={{
                                            height: "250px",
                                            width: "100%",
                                            objectFit: "cover"
                                        }}
                                    />
                                </div>
                            ))
                        ) : (
                            <div className="col-12">
                                <p className="text-muted mb-0">
                                    No images available.
                                </p>
                            </div>
                        )}

                    </div>
                </div>
            </div>

            {/* Admin Decision */}
            <div className="card shadow border-0 mb-4">
                <div className="card-header bg-white">
                    <h4 className="mb-0">Admin Decision</h4>
                </div>

                <div className="card-body">

                    {/* Rejection Reason */}
                    <div className="mb-3">
                        <label className="form-label fw-semibold">
                            Rejection Reason
                        </label>

                        <textarea
                            className="form-control"
                            rows="3"
                            value={rejectionReason}
                            onChange={(e) =>
                                setRejectionReason(e.target.value)
                            }
                            placeholder="Enter the reason for rejecting this apartment..."
                        />
                    </div>

                    {/* Action Buttons */}
                    <div className="d-flex gap-2">

                        <button
                            type="button"
                            className="btn btn-success btn-sm px-3"
                            onClick={handleApprove}
                        >
                            ✓ Approve Apartment
                        </button>

                        <button
                            type="button"
                            className="btn btn-danger btn-sm px-3"
                            onClick={handleReject}
                        >
                            ✕ Reject Apartment
                        </button>

                    </div>

                </div>
            </div>

        </div>
    </MainLayout>
);

}

export default AdminApartmentDetails;