import axiosInstance from "../api/axios";

const getRecentlyViewed = () => {
    return axiosInstance.get(
        "/recently-viewed"
    );
};

export default {
    getRecentlyViewed
};