import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import apartmentService from "../../services/apartmentService";
import locationService from "../../services/locationService";

const propertyFeatures = [
    "SECURITY",
    "CCTV",
    "LIFT",
    "ELECTRICITY",
    "GENERATOR",
    "WASA_CONNECTION",
    "HOT_WATER",
    "GAS_LINE",
    "CYLINDER_GAS",
    "WIFI_CONNECTIVITY",
    "PARKING",
    "MOSQUE_PRAYER_ROOM",
    "CHILD_PLAYGROUND",
    "GYM",
    "COMMUNITY_HALL",
    "ROOFTOP_ACCESS",
    "PET_FRIENDLY"
];

const initialForm = {
    title: "",
    description: "",
    purpose: "RENT",
    propertyType: "APARTMENT",

    listingScope: "UNIT",

    price: "",
    sizeSqFt: "",

    bedrooms: "",
    bathrooms: "",
    balconies: "",
    floorNo: "",
    totalFloor: "",
    parkingSpaces: "",

    totalUnits: "",
    landAreaSqFt: "",
    yearBuilt: "",

    furnishing: "SEMI_FURNISHED",

    address: "",
    postalCode: "",

    latitude: "",
    longitude: "",

    contactName: "",
    contactPhone: "",
    contactEmail: "",

    negotiable: false,
    available: true,

    locationId: "",
    availableFrom: ""
};

function EditApartment() {

    const { id } = useParams();
    const navigate = useNavigate();

    const [formData, setFormData] =
        useState(initialForm);

    const [features, setFeatures] =
        useState([]);

    const [locations, setLocations] =
        useState([]);

    const [loading, setLoading] =
        useState(true);

    const [saving, setSaving] =
        useState(false);

    // --------------------------------
    // Load apartment + locations
    // --------------------------------

    useEffect(() => {
        loadData();
    }, [id]);

    const loadData = async () => {

        try {

            setLoading(true);

            const [apartmentResponse, locationResponse] =
                await Promise.all([
                    apartmentService.getApartmentById(id),
                    locationService.getLocations()
                ]);

            const apartment =
                apartmentResponse.data;

            setLocations(
                locationResponse.data || []
            );

            setFormData({
                title: apartment.title || "",
                description: apartment.description || "",
                purpose: apartment.purpose || "RENT",
                propertyType:
                    apartment.propertyType || "APARTMENT",

                listingScope:
                    apartment.listingScope || "UNIT",

                price: apartment.price ?? "",
                sizeSqFt: apartment.sizeSqFt ?? "",

                bedrooms: apartment.bedrooms ?? "",
                bathrooms: apartment.bathrooms ?? "",
                balconies: apartment.balconies ?? "",

                floorNo: apartment.floorNo ?? "",
                totalFloor: apartment.totalFloor ?? "",
                parkingSpaces:
                    apartment.parkingSpaces ?? "",

                totalUnits:
                    apartment.totalUnits ?? "",

                landAreaSqFt:
                    apartment.landAreaSqFt ?? "",

                yearBuilt:
                    apartment.yearBuilt ?? "",

                furnishing:
                    apartment.furnishing || "SEMI_FURNISHED",

                address: apartment.address || "",
                postalCode:
                    apartment.postalCode || "",

                latitude: apartment.latitude ?? "",
                longitude: apartment.longitude ?? "",

                contactName:
                    apartment.contactName || "",

                contactPhone:
                    apartment.contactPhone || "",

                contactEmail:
                    apartment.contactEmail || "",

                negotiable:
                    Boolean(apartment.negotiable),

                available:
                    apartment.available !== false,

                locationId:
                    apartment.locationId ?? "",

                availableFrom:
                    apartment.availableFrom || ""
            });

            setFeatures(
                Array.isArray(apartment.features)
                    ? apartment.features
                    : []
            );

        } catch (error) {

            console.error(
                "Failed to load apartment:",
                error
            );

            alert(
                "Failed to load apartment."
            );

            navigate("/owner/apartments");

        } finally {

            setLoading(false);

        }
    };

    // --------------------------------
    // Input handler
    // --------------------------------

    const handleChange = (e) => {

        const {
            name,
            value,
            type,
            checked
        } = e.target;

        let newValue;

        if (type === "checkbox") {

            newValue = checked;

        } else if (
            type === "number" ||
            name === "locationId"
        ) {

            newValue =
                value === ""
                    ? ""
                    : Number(value);

        } else {

            newValue = value;

        }

        setFormData(prev => ({
            ...prev,
            [name]: newValue
        }));

    };

    // --------------------------------
    // Feature handler
    // --------------------------------

    const handleFeatureChange = (feature) => {

        setFeatures(prev =>
            prev.includes(feature)
                ? prev.filter(
                    item => item !== feature
                )
                : [...prev, feature]
        );

    };

    // --------------------------------
    // Submit
    // --------------------------------

    const handleSubmit = async (e) => {

        e.preventDefault();

        try {

            setSaving(true);

            await apartmentService.updateApartment(
                id,
                {
                    ...formData,
                    features
                }
            );

            alert(
                "Apartment updated successfully."
            );

            navigate("/owner/apartments");

        } catch (error) {

            console.error(
                "Failed to update apartment:",
                error
            );

            alert(
                "Failed to update apartment."
            );

        } finally {

            setSaving(false);

        }
    };

    // --------------------------------
    // Loading
    // --------------------------------

    if (loading) {

        return (
            <MainLayout>

                <div className="container py-5 text-center">

                    <div
                        className="spinner-border text-primary"
                        style={{
                            width: "3rem",
                            height: "3rem"
                        }}
                    />

                    <p className="text-muted mt-3">
                        Loading apartment...
                    </p>

                </div>

            </MainLayout>
        );
    }

    // --------------------------------
    // UI
    // --------------------------------

    return (

        <MainLayout>

            <div className="container py-5">

                <div className="card border-0 shadow-lg rounded-4">

                    <div className="card-header bg-primary text-white p-4">

                        <div className="d-flex justify-content-between align-items-center">

                            <div>

                                <h2 className="mb-1">
                                    ✏️ Edit Property
                                </h2>

                                <p className="mb-0 opacity-75">
                                    Update your property information.
                                </p>

                            </div>

                            <button
                                type="button"
                                className="btn btn-light"
                                onClick={() =>
                                    navigate(
                                        "/owner/apartments"
                                    )
                                }
                            >
                                ← Back
                            </button>

                        </div>

                    </div>

                    <div className="card-body p-4">

                        <form onSubmit={handleSubmit}>

                            {/* BASIC */}

                            <h4 className="mb-4">
                                📋 Basic Information
                            </h4>

                            <div className="row">

                                <div className="col-md-6 mb-3">

                                    <label className="form-label fw-bold">
                                        Property Title
                                    </label>

                                    <input
                                        type="text"
                                        name="title"
                                        className="form-control"
                                        value={formData.title}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="col-md-3 mb-3">

                                    <label className="form-label fw-bold">
                                        Purpose
                                    </label>

                                    <select
                                        name="purpose"
                                        className="form-select"
                                        value={formData.purpose}
                                        onChange={handleChange}
                                    >
                                        <option value="RENT">
                                            Rent
                                        </option>

                                        <option value="SALE">
                                            Sale
                                        </option>
                                    </select>

                                </div>

                                <div className="col-md-3 mb-3">

                                    <label className="form-label fw-bold">
                                        Property Type
                                    </label>

                                    <select
                                        name="propertyType"
                                        className="form-select"
                                        value={
                                            formData.propertyType
                                        }
                                        onChange={handleChange}
                                    >

                                        <option value="APARTMENT">
                                            Apartment
                                        </option>

                                        <option value="FLAT">
                                            Flat
                                        </option>

                                        <option value="DUPLEX">
                                            Duplex
                                        </option>

                                        <option value="PENTHOUSE">
                                            Penthouse
                                        </option>

                                        <option value="STUDIO">
                                            Studio
                                        </option>

                                        <option value="CONDOMINIUM">
                                            Condominium
                                        </option>

                                    </select>

                                </div>

                            </div>

                            <div className="mb-4">

                                <label className="form-label fw-bold">
                                    Description
                                </label>

                                <textarea
                                    rows="4"
                                    name="description"
                                    className="form-control"
                                    value={
                                        formData.description
                                    }
                                    onChange={handleChange}
                                />

                            </div>

                            <hr className="my-5" />

                            {/* LISTING SCOPE */}

                            <h4 className="mb-3">
                                🏢 Listing Type
                            </h4>

                            <p className="text-muted">
                                Choose whether you are listing an individual
                                unit or an entire building/property.
                            </p>

                            <div className="row">

                                <div className="col-md-6 mb-3">

                                    <div className="form-check border rounded-3 p-3">

                                        <input
                                            className="form-check-input"
                                            type="radio"
                                            name="listingScope"
                                            value="UNIT"
                                            checked={
                                                formData.listingScope ===
                                                "UNIT"
                                            }
                                            onChange={handleChange}
                                        />

                                        <label className="form-check-label fw-bold">

                                            🏠 Individual Unit

                                            <div className="small text-muted">
                                                Flat, studio, duplex,
                                                penthouse, etc.
                                            </div>

                                        </label>

                                    </div>

                                </div>

                                <div className="col-md-6 mb-3">

                                    <div className="form-check border rounded-3 p-3">

                                        <input
                                            className="form-check-input"
                                            type="radio"
                                            name="listingScope"
                                            value="BUILDING"
                                            checked={
                                                formData.listingScope ===
                                                "BUILDING"
                                            }
                                            onChange={handleChange}
                                        />

                                        <label className="form-check-label fw-bold">

                                            🏢 Entire Building

                                            <div className="small text-muted">
                                                Complete apartment/building
                                                property.
                                            </div>

                                        </label>

                                    </div>

                                </div>

                            </div>

                            <hr className="my-5" />

                            {/* PROPERTY DETAILS */}

                            <h4 className="mb-4">
                                🏠 Property Details
                            </h4>

                            <div className="row">

                                <div className="col-md-4 mb-3">

                                    <label className="form-label fw-bold">
                                        Price
                                    </label>

                                    <input
                                        type="number"
                                        name="price"
                                        className="form-control"
                                        value={formData.price}
                                        onChange={handleChange}
                                        min="0"
                                        required
                                    />

                                </div>

                                <div className="col-md-4 mb-3">

                                    <label className="form-label fw-bold">
                                        Size (Sq Ft)
                                    </label>

                                    <input
                                        type="number"
                                        name="sizeSqFt"
                                        className="form-control"
                                        value={
                                            formData.sizeSqFt
                                        }
                                        onChange={handleChange}
                                        min="0"
                                    />

                                </div>

                                <div className="col-md-4 mb-3">

                                    <label className="form-label fw-bold">
                                        Year Built
                                    </label>

                                    <input
                                        type="number"
                                        name="yearBuilt"
                                        className="form-control"
                                        value={
                                            formData.yearBuilt
                                        }
                                        onChange={handleChange}
                                        min="1800"
                                    />

                                </div>

                            </div>

                            {/* UNIT DETAILS */}

                            {formData.listingScope === "UNIT" && (

                                <>
                                    <div className="row">

                                        {[
                                            ["bedrooms", "Bedrooms"],
                                            ["bathrooms", "Bathrooms"],
                                            ["balconies", "Balconies"],
                                            ["parkingSpaces", "Parking"]
                                        ].map(
                                            ([name, label]) => (

                                                <div
                                                    className="col-md-3 mb-3"
                                                    key={name}
                                                >

                                                    <label className="form-label fw-bold">
                                                        {label}
                                                    </label>

                                                    <input
                                                        type="number"
                                                        min="0"
                                                        name={name}
                                                        className="form-control"
                                                        value={
                                                            formData[name]
                                                        }
                                                        onChange={
                                                            handleChange
                                                        }
                                                    />

                                                </div>

                                            )
                                        )}

                                    </div>

                                    <div className="row">

                                        <div className="col-md-6 mb-3">

                                            <label className="form-label fw-bold">
                                                Floor Number
                                            </label>

                                            <input
                                                type="number"
                                                min="0"
                                                name="floorNo"
                                                className="form-control"
                                                value={
                                                    formData.floorNo
                                                }
                                                onChange={
                                                    handleChange
                                                }
                                            />

                                        </div>

                                        <div className="col-md-6 mb-3">

                                            <label className="form-label fw-bold">
                                                Total Floors
                                            </label>

                                            <input
                                                type="number"
                                                min="1"
                                                name="totalFloor"
                                                className="form-control"
                                                value={
                                                    formData.totalFloor
                                                }
                                                onChange={
                                                    handleChange
                                                }
                                            />

                                        </div>

                                    </div>

                                    <div className="mb-3">

                                        <label className="form-label fw-bold">
                                            Furnishing
                                        </label>

                                        <select
                                            name="furnishing"
                                            className="form-select"
                                            value={
                                                formData.furnishing
                                            }
                                            onChange={
                                                handleChange
                                            }
                                        >

                                            <option value="UNFURNISHED">
                                                Unfurnished
                                            </option>

                                            <option value="SEMI_FURNISHED">
                                                Semi Furnished
                                            </option>

                                            <option value="FULLY_FURNISHED">
                                                Fully Furnished
                                            </option>

                                        </select>

                                    </div>
                                </>

                            )}

                            {/* BUILDING DETAILS */}

                            {formData.listingScope === "BUILDING" && (

                                <div className="row">

                                    <div className="col-md-4 mb-3">

                                        <label className="form-label fw-bold">
                                            Total Floors
                                        </label>

                                        <input
                                            type="number"
                                            min="1"
                                            name="totalFloor"
                                            className="form-control"
                                            value={
                                                formData.totalFloor
                                            }
                                            onChange={handleChange}
                                        />

                                    </div>

                                    <div className="col-md-4 mb-3">

                                        <label className="form-label fw-bold">
                                            Total Units
                                        </label>

                                        <input
                                            type="number"
                                            min="1"
                                            name="totalUnits"
                                            className="form-control"
                                            value={
                                                formData.totalUnits
                                            }
                                            onChange={handleChange}
                                        />

                                    </div>

                                    <div className="col-md-4 mb-3">

                                        <label className="form-label fw-bold">
                                            Land Area (Sq Ft)
                                        </label>

                                        <input
                                            type="number"
                                            min="0"
                                            name="landAreaSqFt"
                                            className="form-control"
                                            value={
                                                formData.landAreaSqFt
                                            }
                                            onChange={handleChange}
                                        />

                                    </div>

                                </div>

                            )}

                            <hr className="my-5" />

                            {/* LOCATION */}

                            <h4 className="mb-4">
                                📍 Location
                            </h4>

                            <div className="row">

                                <div className="col-md-8 mb-3">

                                    <label className="form-label fw-bold">
                                        Address
                                    </label>

                                    <input
                                        type="text"
                                        name="address"
                                        className="form-control"
                                        value={
                                            formData.address
                                        }
                                        onChange={handleChange}
                                    />

                                </div>

                                <div className="col-md-4 mb-3">

                                    <label className="form-label fw-bold">
                                        Postal Code
                                    </label>

                                    <input
                                        type="text"
                                        name="postalCode"
                                        className="form-control"
                                        value={
                                            formData.postalCode
                                        }
                                        onChange={handleChange}
                                    />

                                </div>

                            </div>

                            <div className="mb-3">

                                <label className="form-label fw-bold">
                                    Location
                                </label>

                                <select
                                    name="locationId"
                                    className="form-select"
                                    value={
                                        formData.locationId
                                    }
                                    onChange={handleChange}
                                    required
                                >

                                    <option value="">
                                        Select Location
                                    </option>

                                    {locations.map(
                                        location => (

                                            <option
                                                key={
                                                    location.id
                                                }
                                                value={
                                                    location.id
                                                }
                                            >
                                                {location.city}
                                                {" - "}
                                                {location.area}
                                                {location.subArea
                                                    ? ` - ${location.subArea}`
                                                    : ""}
                                            </option>

                                        )
                                    )}

                                </select>

                            </div>

                            <div className="row">

                                <div className="col-md-6 mb-3">

                                    <label className="form-label fw-bold">
                                        Latitude
                                    </label>

                                    <input
                                        type="number"
                                        step="any"
                                        name="latitude"
                                        className="form-control"
                                        value={
                                            formData.latitude
                                        }
                                        onChange={handleChange}
                                    />

                                </div>

                                <div className="col-md-6 mb-3">

                                    <label className="form-label fw-bold">
                                        Longitude
                                    </label>

                                    <input
                                        type="number"
                                        step="any"
                                        name="longitude"
                                        className="form-control"
                                        value={
                                            formData.longitude
                                        }
                                        onChange={handleChange}
                                    />

                                </div>

                            </div>

                            <hr className="my-5" />

                            {/* CONTACT */}

                            <h4 className="mb-4">
                                👤 Contact Information
                            </h4>

                            <div className="row">

                                {[
                                    [
                                        "contactName",
                                        "Contact Name",
                                        "text"
                                    ],
                                    [
                                        "contactPhone",
                                        "Contact Phone",
                                        "text"
                                    ],
                                    [
                                        "contactEmail",
                                        "Contact Email",
                                        "email"
                                    ]
                                ].map(
                                    ([name, label, type]) => (

                                        <div
                                            className="col-md-4 mb-3"
                                            key={name}
                                        >

                                            <label className="form-label fw-bold">
                                                {label}
                                            </label>

                                            <input
                                                type={type}
                                                name={name}
                                                className="form-control"
                                                value={
                                                    formData[name]
                                                }
                                                onChange={
                                                    handleChange
                                                }
                                            />

                                        </div>

                                    )
                                )}

                            </div>

                            <hr className="my-5" />

                            {/* FEATURES */}

                            <div className="d-flex justify-content-between align-items-center mb-4">

                                <div>

                                    <h4 className="mb-1">
                                        ✨ Property Features
                                    </h4>

                                    <p className="text-muted mb-0">
                                        Select only facilities
                                        actually available.
                                    </p>

                                </div>

                                <span className="badge bg-primary">
                                    {features.length} Selected
                                </span>

                            </div>

                            <div className="row g-3">

                                {propertyFeatures.map(
                                    feature => {

                                        const selected =
                                            features.includes(
                                                feature
                                            );

                                        return (

                                            <div
                                                className="col-md-4 col-lg-3"
                                                key={feature}
                                            >

                                                <div
                                                    className={`border rounded-3 p-3 h-100 ${
                                                        selected
                                                            ? "border-primary bg-primary bg-opacity-10"
                                                            : "bg-light"
                                                    }`}
                                                    style={{
                                                        cursor:
                                                            "pointer"
                                                    }}
                                                    onClick={() =>
                                                        handleFeatureChange(
                                                            feature
                                                        )
                                                    }
                                                >

                                                    <div className="form-check">

                                                        <input
                                                            type="checkbox"
                                                            className="form-check-input"
                                                            checked={
                                                                selected
                                                            }
                                                            onChange={() =>
                                                                handleFeatureChange(
                                                                    feature
                                                                )
                                                            }
                                                            onClick={e =>
                                                                e.stopPropagation()
                                                            }
                                                        />

                                                        <label
                                                            className={`form-check-label fw-semibold ${
                                                                selected
                                                                    ? "text-primary"
                                                                    : ""
                                                            }`}
                                                        >
                                                            {feature
                                                                .replaceAll(
                                                                    "_",
                                                                    " "
                                                                )
                                                                .toLowerCase()
                                                                .replace(
                                                                    /\b\w/g,
                                                                    c =>
                                                                        c.toUpperCase()
                                                                )}
                                                        </label>

                                                    </div>

                                                </div>

                                            </div>

                                        );
                                    }
                                )}

                            </div>

                            <hr className="my-5" />

                            {/* STATUS */}

                            <h4 className="mb-4">
                                ⚙ Property Status
                            </h4>

                            <div className="row">

                                <div className="col-md-6 mb-3">

                                    <div className="form-check form-switch">

                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            name="negotiable"
                                            checked={
                                                formData.negotiable
                                            }
                                            onChange={
                                                handleChange
                                            }
                                        />

                                        <label className="form-check-label">
                                            Price Negotiable
                                        </label>

                                    </div>

                                </div>

                                <div className="col-md-6 mb-3">

                                    <div className="form-check form-switch">

                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            name="available"
                                            checked={
                                                formData.available
                                            }
                                            onChange={
                                                handleChange
                                            }
                                        />

                                        <label className="form-check-label">
                                            Currently Available
                                        </label>

                                    </div>

                                </div>

                            </div>

                            <div className="mb-4">

                                <label className="form-label fw-bold">
                                    Available From
                                </label>

                                <input
                                    type="date"
                                    name="availableFrom"
                                    className="form-control"
                                    value={
                                        formData.availableFrom
                                    }
                                    onChange={
                                        handleChange
                                    }
                                />

                            </div>

                            {/* ACTIONS */}

                            <hr className="my-4" />

                            <div className="d-flex justify-content-between flex-wrap gap-3">

                                <button
                                    type="button"
                                    className="btn btn-outline-secondary btn-lg px-4"
                                    onClick={() =>
                                        navigate(
                                            "/owner/apartments"
                                        )
                                    }
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    className="btn btn-primary btn-lg px-5"
                                    disabled={saving}
                                >

                                    {saving ? (
                                        <>
                                            <span className="spinner-border spinner-border-sm me-2" />
                                            Updating...
                                        </>
                                    ) : (
                                        <>
                                            💾 Save Changes
                                        </>
                                    )}

                                </button>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default EditApartment;