import { useEffect, useState } from "react";

import MainLayout from "../../layouts/MainLayout";
import ApartmentCard from "../../components/ApartmentCard";
import recentlyViewedService from "../../services/recentlyViewedService";

function RecentlyViewed() {

    const [apartments, setApartments] =
        useState([]);

    const [loading, setLoading] =
        useState(true);

    useEffect(() => {

        loadRecentlyViewed();

    }, []);

    const loadRecentlyViewed =
        async () => {

            try {

                const res =
                    await recentlyViewedService
                        .getRecentlyViewed();

                setApartments(
                    res.data
                );

            } catch (err) {

                console.error(err);

            } finally {

                setLoading(false);
            }
        };

    return (

        <MainLayout>

            <h2 className="fw-bold mb-4">
                Recently Viewed Apartments
            </h2>

            {
                loading ? (

                    <div className="text-center">

                        <div className="spinner-border text-primary" />

                    </div>

                ) : (

                    <div className="row">

                        {
                            apartments.length > 0
                                ? apartments.map(
                                      apartment => (

                                          <ApartmentCard
                                              key={apartment.id}
                                              apartment={apartment}
                                          />

                                      )
                                  )
                                : (

                                    <div className="alert alert-info">

                                        No recently viewed apartments.

                                    </div>

                                )
                        }

                    </div>

                )
            }

        </MainLayout>
    );
}

export default RecentlyViewed;