import {
    MapContainer,
    TileLayer,
    Marker,
    Popup
} from "react-leaflet";

import L from "leaflet";

import { Link } from "react-router-dom";

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({

    iconRetinaUrl:
        "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",

    iconUrl:
        "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",

    shadowUrl:
        "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png"
});

function ApartmentMap({
    apartments
}) {

    if (
        !apartments ||
        apartments.length === 0
    ) {

        return null;
    }

    const center = [

        apartments[0].latitude,

        apartments[0].longitude
    ];

    return (

        <MapContainer

            center={center}

            zoom={13}

            style={{
                height: "500px",
                width: "100%"
            }}
        >

            <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {
                apartments.map(
                    apartment => (

                        <Marker

                            key={
                                apartment.id
                            }

                            position={[

                                apartment.latitude,

                                apartment.longitude
                            ]}
                        >

                            <Popup>

                                <h6>
                                    {
                                        apartment.title
                                    }
                                </h6>

                                <p>

                                    ৳ {
                                        apartment.price?.toLocaleString()
                                    }

                                </p>

                                <Link
                                    to={`/apartments/${apartment.id}`}
                                >
                                    View Details
                                </Link>

                            </Popup>

                        </Marker>

                    )
                )
            }

        </MapContainer>
    );
}

export default ApartmentMap;