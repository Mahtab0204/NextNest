import axiosInstance from "../api/axios";

const getAllUsers = () => {
    return axiosInstance.get(
        "/admin/users"
    );
};

const getUserById = (id) => {
    return axiosInstance.get(
        `/admin/users/${id}`
    );
};

const getOwnerDetails = (id) => {
    return axiosInstance.get(
        `/admin/owners/${id}`
    );
};

const activateUser = (id) => {
    return axiosInstance.put(
        `/admin/users/${id}/activate`
    );
};

const deactivateUser = (id) => {
    return axiosInstance.put(
        `/admin/users/${id}/deactivate`
    );
};

const deleteUser = (id) => {
    return axiosInstance.delete(
        `/admin/users/${id}`
    );
};

const adminUserService = {

    getAllUsers,

    getUserById,

    getOwnerDetails,

    activateUser,

    deactivateUser,

    deleteUser
};

export default adminUserService;