import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";

import MainLayout from "../../layouts/MainLayout";
import apartmentService from "../../services/apartmentService";
import adminService from "../../services/adminService";

function AdminApartmentList() {

    const [apartments, setApartments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [keyword, setKeyword] = useState("");
    const [selectedStatus, setSelectedStatus] =useState("ALL");

    const loadApartments = async () => {

        try {

            const response =
                await apartmentService.getApartments();

            setApartments(
                response.data.content || response.data
            );

        } catch (error) {

            toast.error(
                "Failed to load apartments"
            );

        } finally {

            setLoading(false);

        }
    };

    useEffect(() => {

        loadApartments();

    }, []);


    const handleApprove = async (id) => {

        try {

            await apartmentService.approveApartment(id);

            toast.success(
                "Apartment approved"
            );

            loadApartments();

        } catch {

            toast.error(
                "Approval failed"
            );
        }
    };

    const handleReject = async (id) => {

        try {

            await apartmentService.rejectApartment(id);

            toast.success(
                "Apartment rejected"
            );

            loadApartments();

        } catch {

            toast.error(
                "Rejection failed"
            );
        }
    };

    const handleSearch = async () => {

    try {

        if (!keyword.trim()) {

            loadApartments();
            return;
        }

        const response =
            await adminService
                .searchApartments(
                    keyword
                );

        setApartments(
            response.data
        );

    } catch (error) {

        toast.error(
            "Search failed"
        );
    }
};

const handleKeyDown = (e) => {

    if (e.key === "Enter") {

        handleSearch();
    }
};

const handleFilter =
    async (status) => {

    setSelectedStatus(status);

    try {

        if (status === "ALL") {

            loadApartments();

            return;
        }

        const response =
            await adminService
                .getApartmentsByStatus(
                    status
                );

        setApartments(
            response.data
        );

    } catch {

        toast.error(
            "Failed to load apartments"
        );
    }
};

    return (

        <MainLayout>

            <div className="d-flex justify-content-between align-items-center mb-4">

                <h2>
                    Manage Apartments
                </h2>

            </div>

          <div className="card shadow border-0 mb-4">

    <div className="card-body">

        <div className="row g-2">

            <div className="col-md-9">

                <input
                    type="text"
                    className="form-control"
                    placeholder="
Search by Apartment ID,
Title,
Owner Name,
Email,
Phone..."
                    value={keyword}
                    onChange={(e) =>
                        setKeyword(
                            e.target.value
                        )
                    }
                    onKeyDown={
                        handleKeyDown
                    }
                />

            </div>

            <div className="col-md-3">

                <div className="col-md-3 d-flex gap-2">

    <button
        className="btn btn-primary w-100"
        onClick={handleSearch}
    >
        Search
    </button>

    <button
        className="btn btn-secondary"
        onClick={() => {

            setKeyword("");
            loadApartments();

        }}
    >
        Reset
    </button>

</div>

            </div>

        </div>

    </div>

</div>

<div className="mb-4 d-flex gap-2">

    <button
        className={`btn ${
            selectedStatus === "ALL"
            ? "btn-dark"
            : "btn-outline-dark"
        }`}
        onClick={() =>
            handleFilter("ALL")
        }
    >
        All
    </button>

    <button
        className={`btn ${
            selectedStatus === "PENDING"
            ? "btn-warning"
            : "btn-outline-warning"
        }`}
        onClick={() =>
            handleFilter("PENDING")
        }
    >
        Pending
    </button>

    <button
        className={`btn ${
            selectedStatus === "APPROVED"
            ? "btn-success"
            : "btn-outline-success"
        }`}
        onClick={() =>
            handleFilter("APPROVED")
        }
    >
        Approved
    </button>

    <button
        className={`btn ${
            selectedStatus === "REJECTED"
            ? "btn-danger"
            : "btn-outline-danger"
        }`}
        onClick={() =>
            handleFilter("REJECTED")
        }
    >
        Rejected
    </button>

</div>

            {
                loading ? (

                    <div className="text-center">

                        <div className="spinner-border text-primary" />

                    </div>

                ) : (

                    <div className="table-responsive">

                        <table className="table table-bordered table-hover align-middle">

                            <thead className="table-dark">

                                <tr>

                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Purpose</th>
                                    <th>Price</th>
                                    <th>Approval Status</th>
                                    <th width="320">
                                        Actions
                                    </th>

                                </tr>

                            </thead>

                            <tbody>

                                {
                                    apartments.map(apartment => (

                                        <tr key={apartment.id}>

                                            <td>
                                                {apartment.id}
                                            </td>

                                            <td>
                                                {apartment.title}
                                            </td>

                                            <td>
                                                {apartment.purpose}
                                            </td>

                                            <td>
                                                ৳ {apartment.price?.toLocaleString()}
                                            </td>

                                            <td>

                                                <span
                                                    className={`badge ${
                                                        apartment.approvalStatus === "APPROVED"
                                                            ? "bg-success"
                                                            : apartment.approvalStatus === "REJECTED"
                                                            ? "bg-danger"
                                                            : "bg-warning text-dark"
                                                    }`}
                                                >
                                                    {
                                                        apartment.approvalStatus
                                                    }
                                                </span>

                                            </td>

                                            <td>

                                                <Link
                                                    to={`/admin/apartments/${apartment.id}`}
                                                    className="btn btn-info btn-sm me-2"
                                                >
                                                    View Details
                                                </Link>

                                                <button
                                                    className="btn btn-success btn-sm me-2"
                                                    onClick={() =>
                                                        handleApprove(
                                                            apartment.id
                                                        )
                                                    }
                                                >
                                                    Approve
                                                </button>

                                                <button
                                                    className="btn btn-danger btn-sm"
                                                    onClick={() =>
                                                        handleReject(
                                                            apartment.id
                                                        )
                                                    }
                                                >
                                                    Reject
                                                </button>

                                            </td>

                                        </tr>

                                    ))
                                }

                            </tbody>

                        </table>

                    </div>

                )
            }

        </MainLayout>
    );
}

export default AdminApartmentList;