import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import inquiryService from "../../services/inquiryService";

function MyInquiries() {

    const [inquiries, setInquiries] =
        useState([]);

    const [loading, setLoading] =
        useState(true);

    useEffect(() => {

        loadInquiries();

    }, []);

    const loadInquiries = async () => {

        try {

            const response =
                await inquiryService
                    .getMyInquiries();

            setInquiries(
                response.data
            );

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);
        }
    };

    return (

        <MainLayout>

            <h2 className="mb-4">
                My Inquiries
            </h2>

            {
                loading ? (

                    <div className="text-center">

                        <div
                            className="spinner-border text-primary"
                        />

                    </div>

                ) : (

                    <div className="card shadow border-0">

                        <div className="card-body">

                            <table className="table table-hover">

                                <thead>

                                    <tr>

                                        <th>
                                            Apartment
                                        </th>

                                        <th>
                                            Message
                                        </th>

                                        <th>
                                            Status
                                        </th>

                                        <th>
                                            Date
                                        </th>

                                        <th>
                                            Chat
                                        </th>

                                    </tr>

                                </thead>

                                <tbody>

                                    {
                                        inquiries.length > 0 ? (

                                            inquiries.map(
                                                inquiry => (

                                                    <tr
                                                        key={inquiry.id}
                                                    >

                                                        <td>
                                                            {
                                                                inquiry.apartmentTitle
                                                            }
                                                        </td>

                                                        <td>
                                                            {
                                                                inquiry.message
                                                            }
                                                        </td>

                                                        <td>

                                                            <span
                                                                className={
                                                                    `badge ${
                                                                        inquiry.status === "PENDING"
                                                                            ? "bg-warning text-dark"
                                                                            : inquiry.status === "ACCEPTED"
                                                                            ? "bg-success"
                                                                            : "bg-danger"
                                                                    }`
                                                                }
                                                            >

                                                                {
                                                                    inquiry.status
                                                                }

                                                            </span>

                                                        </td>

                                                        <td>

                                                            {
                                                                new Date(
                                                                    inquiry.createdAt
                                                                ).toLocaleDateString()
                                                            }

                                                        </td>

                                                        <td>

                                                            {
                                                                inquiry.status === "ACCEPTED" ? (

                                                                    <Link
                                                                        to={`/messages/${inquiry.id}`}
                                                                        className="btn btn-primary btn-sm"
                                                                    >
                                                                        Open Chat
                                                                    </Link>

                                                                ) : (

                                                                    <button
                                                                        className="btn btn-secondary btn-sm"
                                                                        disabled
                                                                    >
                                                                        Waiting
                                                                    </button>

                                                                )
                                                            }

                                                        </td>

                                                    </tr>

                                                )
                                            )

                                        ) : (

                                            <tr>

                                                <td
                                                    colSpan="5"
                                                    className="text-center text-muted"
                                                >
                                                    No inquiries found
                                                </td>

                                            </tr>

                                        )
                                    }

                                </tbody>

                            </table>

                        </div>

                    </div>

                )
            }

        </MainLayout>

    );
}

export default MyInquiries;