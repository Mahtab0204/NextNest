// src/components/PromoteApartmentModal.jsx

import { useState } from "react";
import featuredService from "../services/featuredService";
import { useNavigate } from "react-router-dom";

function PromoteApartmentModal({
    apartment,
    onClose,
    onSuccess
}) {

    const [loading, setLoading] =
        useState(false);

    const [plan, setPlan] =
        useState("SEVEN_DAYS");

    const planPrices = {
        SEVEN_DAYS: 99,
        FIFTEEN_DAYS: 199,
        THIRTY_DAYS: 299
    };

   

const navigate = useNavigate();

const handleContinue = () => {

    navigate(
        `/owner/promote/${apartment.id}`,
        {
            state: {
                apartment,
                plan,
                amount: planPrices[plan]
            }
        }
    );

    onClose();
};

    return (

        <div
            className="modal d-block"
            style={{
                background:
                    "rgba(0,0,0,0.5)"
            }}
        >

            <div className="modal-dialog">

                <div className="modal-content">

                    <div className="modal-header">

                        <h5 className="modal-title">

                            ⭐ Promote Apartment

                        </h5>

                        <button
                            className="btn-close"
                            onClick={onClose}
                        />

                    </div>

                    <div className="modal-body">

                        <h6>

                            {apartment.title}

                        </h6>

                        <hr />

                        <div className="mb-3">

                            <label className="form-label">

                                Featured Plan

                            </label>

                            <select
                                className="form-select"
                                value={plan}
                                onChange={(e) =>
                                    setPlan(
                                        e.target.value
                                    )
                                }
                            >

                                <option value="SEVEN_DAYS">
                                    7 Days - ৳99
                                </option>

                                <option value="FIFTEEN_DAYS">
                                    15 Days - ৳199
                                </option>

                                <option value="THIRTY_DAYS">
                                    30 Days - ৳299
                                </option>

                            </select>

                        </div>

                        <div className="alert alert-info">

                            Amount:
                            <strong>

                                {" "}
                                ৳{planPrices[plan]}

                            </strong>

                        </div>

                    </div>

                    <div className="modal-footer">

                        <button
                            className="btn btn-secondary"
                            onClick={onClose}
                        >
                            Cancel
                        </button>

                       <button
    className="btn btn-warning"
    onClick={handleContinue}
>
    Continue To Payment →
</button>

                    </div>

                </div>

            </div>

        </div>
    );
}

export default PromoteApartmentModal;