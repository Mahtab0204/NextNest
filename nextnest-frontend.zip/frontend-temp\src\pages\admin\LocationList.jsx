import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import locationService from "../../services/locationService";

function LocationList() {

    const [locations, setLocations] =
        useState([]);

    const [loading, setLoading] =
        useState(true);

    useEffect(() => {

        loadLocations();

    }, []);

    const loadLocations = async () => {

        try {

            const response =
                await locationService
                    .getLocations();

            setLocations(
                response.data
            );

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);
        }
    };

    const handleDelete =
        async (id) => {

            const confirmDelete =
                window.confirm(
                    "Delete this location?"
                );

            if (!confirmDelete)
                return;

            try {

                await locationService
                    .deleteLocation(id);

                alert(
                    "Location deleted successfully"
                );

                loadLocations();

            } catch (error) {

                console.error(error);

                alert(
                    "Failed to delete location"
                );
            }
        };

    return (

        <MainLayout>

            <div className="container">

                <div className="d-flex justify-content-between align-items-center mb-4">

                    <h2>
                        Manage Locations
                    </h2>

                    <Link
                        to="/admin/locations/create"
                        className="btn btn-primary"
                    >
                        Add Location
                    </Link>

                </div>

                {
                    loading ? (

                        <div className="text-center">

                            <div className="spinner-border text-primary" />

                        </div>

                    ) : (

                        <div className="table-responsive">

                            <table className="table table-bordered table-hover">

                                <thead>

                                    <tr>

                                        <th>ID</th>
                                        <th>City</th>
                                        <th>Area</th>
                                        <th>Sub Area</th>
                                        <th>Actions</th>

                                    </tr>

                                </thead>

                                <tbody>

                                    {
                                        locations.map(
                                            location => (

                                                <tr
                                                    key={location.id}
                                                >

                                                    <td>
                                                        {location.id}
                                                    </td>

                                                    <td>
                                                        {location.city}
                                                    </td>

                                                    <td>
                                                        {location.area}
                                                    </td>

                                                    <td>
                                                        {location.subArea}
                                                    </td>

                                                    <td>

                                                        <Link
                                                            to={`/admin/locations/edit/${location.id}`}
                                                            className="btn btn-warning btn-sm me-2"
                                                        >
                                                            Edit
                                                        </Link>

                                                        <button
                                                            className="btn btn-danger btn-sm"
                                                            onClick={() =>
                                                                handleDelete(
                                                                    location.id
                                                                )
                                                            }
                                                        >
                                                            Delete
                                                        </button>

                                                    </td>

                                                </tr>

                                            )
                                        )
                                    }

                                </tbody>

                            </table>

                        </div>

                    )
                }

            </div>

        </MainLayout>

    );
}

export default LocationList;