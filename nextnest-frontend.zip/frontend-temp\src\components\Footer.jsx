import { Link } from "react-router-dom";

function Footer() {
    return (
        <footer className="bg-dark text-white mt-5">

            {/* Main Footer */}
            <div className="container py-5">

                <div className="row g-4">

                    {/* Brand */}
                    <div className="col-lg-5 col-md-6">

                        <h3 className="fw-bold mb-3">
                            🏠 NextNest
                        </h3>

                        <p className="text-white-50 mb-4">
                            Find your perfect apartment for rent or sale
                            across Dhaka city with NextNest.
                        </p>

                        <div className="d-flex gap-2">

                            <span className="badge bg-primary px-3 py-2">
                                🏢 Apartments
                            </span>

                            <span className="badge bg-success px-3 py-2">
                                🏠 Rent
                            </span>

                            <span className="badge bg-warning text-dark px-3 py-2">
                                💰 Buy
                            </span>

                        </div>

                    </div>

                    {/* Quick Links */}
                    <div className="col-lg-3 col-md-6">

                        <h5 className="fw-bold mb-3">
                            Quick Links
                        </h5>

                        <ul className="list-unstyled">

                            <li className="mb-2">
                                <Link
                                    to="/"
                                    className="text-white-50 text-decoration-none"
                                >
                                    🏠 Home
                                </Link>
                            </li>

                            <li className="mb-2">
                                <Link
                                    to="/rent"
                                    className="text-white-50 text-decoration-none"
                                >
                                    🏢 Rent Apartments
                                </Link>
                            </li>

                            <li className="mb-2">
                                <Link
                                    to="/buy"
                                    className="text-white-50 text-decoration-none"
                                >
                                    💰 Buy Apartments
                                </Link>
                            </li>

                            <li className="mb-2">
                                <Link
                                    to="/login"
                                    className="text-white-50 text-decoration-none"
                                >
                                    🔐 Login
                                </Link>
                            </li>

                            <li>
                                <Link
                                    to="/register"
                                    className="text-white-50 text-decoration-none"
                                >
                                    ✨ Create Account
                                </Link>
                            </li>

                        </ul>

                    </div>

                    {/* Contact */}
                    <div className="col-lg-4 col-md-6">

                        <h5 className="fw-bold mb-3">
                            Contact Us
                        </h5>

                        <div className="text-white-50">

                            <p className="mb-3">
                                📧 support@nextnest.com
                            </p>

                            <p className="mb-3">
                                📞 +880 1XXXXXXXXX
                            </p>

                            <p className="mb-0">
                                📍 Dhaka, Bangladesh
                            </p>

                        </div>

                    </div>

                </div>

                <hr className="border-secondary my-4" />

                {/* Bottom */}
                <div className="row align-items-center">

                    <div className="col-md-6 text-center text-md-start">

                        <p className="text-white-50 mb-0">
                            © 2026 <strong className="text-white">
                                NextNest
                            </strong>. All Rights Reserved.
                        </p>

                    </div>

                    <div className="col-md-6 text-center text-md-end mt-2 mt-md-0">

                        <span className="text-white-50 small">
                            Your next home starts here 🏡
                        </span>

                    </div>

                </div>

            </div>

        </footer>
    );
}

export default Footer;