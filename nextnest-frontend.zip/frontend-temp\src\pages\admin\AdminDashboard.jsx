import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import adminService from "../../services/adminService";

function AdminDashboard() {

    const navigate = useNavigate();

    const [stats, setStats] = useState({
        totalUsers: 0,
        totalOwners: 0,
        totalApartments: 0,
        pendingApartments: 0,
        approvedApartments: 0,
        rejectedApartments: 0,
        totalInquiries: 0
    });

    const [pendingApartments, setPendingApartments] = useState([]);

    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);

    useEffect(() => {
        loadDashboard();
    }, []);

    // ----------------------------------------
    // Load Dashboard
    // ----------------------------------------

    const loadDashboard = async () => {

        try {

            setLoading(true);

            const [statsResponse, pendingResponse] =
                await Promise.all([
                    adminService.getDashboardStats(),
                    adminService.getRecentPendingApartments()
                ]);

            setStats(statsResponse.data);
            setPendingApartments(pendingResponse.data);

        } catch (error) {

            console.error("Dashboard loading error:", error);

        } finally {

            setLoading(false);

        }
    };

    // ----------------------------------------
    // Refresh Dashboard
    // ----------------------------------------

    const handleRefresh = async () => {

        try {

            setRefreshing(true);

            const [statsResponse, pendingResponse] =
                await Promise.all([
                    adminService.getDashboardStats(),
                    adminService.getRecentPendingApartments()
                ]);

            setStats(statsResponse.data);
            setPendingApartments(pendingResponse.data);

        } catch (error) {

            console.error(error);

        } finally {

            setRefreshing(false);

        }
    };

    // ----------------------------------------
    // Calculate approval percentage
    // ----------------------------------------

    const approvalPercentage =
        stats.totalApartments > 0
            ? Math.round(
                (stats.approvedApartments /
                    stats.totalApartments) *
                100
            )
            : 0;

    // ----------------------------------------
    // Stat Cards
    // ----------------------------------------

    const statCards = [

        {
            title: "Total Users",
            value: stats.totalUsers,
            icon: "👥",
            color: "primary",
            description: "Registered users"
        },

        {
            title: "Property Owners",
            value: stats.totalOwners,
            icon: "🏠",
            color: "info",
            description: "Active owners"
        },

        {
            title: "Total Apartments",
            value: stats.totalApartments,
            icon: "🏢",
            color: "success",
            description: "Property listings"
        },

        {
            title: "Total Inquiries",
            value: stats.totalInquiries,
            icon: "📩",
            color: "purple",
            description: "Customer inquiries"
        }

    ];

    return (

        <MainLayout>

            <div className="container-fluid py-4">

                {/* ===================================== */}
                {/* HEADER */}
                {/* ===================================== */}

                <div
                    className="card border-0 shadow-lg rounded-4 mb-4 overflow-hidden"
                    style={{
                        background:
                            "linear-gradient(135deg, #0d6efd 0%, #6610f2 100%)"
                    }}
                >

                    <div className="card-body p-4 p-lg-5 text-white">

                        <div className="row align-items-center">

                            <div className="col-lg-8">

                                <div className="d-flex align-items-center mb-2">

                                    <div
                                        className="bg-white bg-opacity-25 rounded-circle d-flex align-items-center justify-content-center me-3"
                                        style={{
                                            width: "55px",
                                            height: "55px"
                                        }}
                                    >
                                        👨‍💼
                                    </div>

                                    <div>

                                        <h2 className="fw-bold mb-0">
                                            Admin Dashboard
                                        </h2>

                                        <small className="opacity-75">
                                            Property Management Control Center
                                        </small>

                                    </div>

                                </div>

                                <p className="mb-0 mt-3 opacity-75">
                                    Monitor users, properties, approvals and
                                    inquiries from one place.
                                </p>

                            </div>

                            <div className="col-lg-4 text-lg-end mt-4 mt-lg-0">

                                <button
                                    className="btn btn-light px-4 py-2 rounded-pill shadow-sm"
                                    onClick={handleRefresh}
                                    disabled={refreshing}
                                >

                                    {refreshing ? (
                                        <>
                                            <span
                                                className="spinner-border spinner-border-sm me-2"
                                            />
                                            Refreshing...
                                        </>
                                    ) : (
                                        <>
                                            🔄 Refresh Dashboard
                                        </>
                                    )}

                                </button>

                            </div>

                        </div>

                    </div>

                </div>


                {/* ===================================== */}
                {/* LOADING */}
                {/* ===================================== */}

                {loading ? (

                    <div className="text-center py-5">

                        <div
                            className="spinner-border text-primary"
                            style={{
                                width: "3rem",
                                height: "3rem"
                            }}
                        />

                        <p className="text-muted mt-3">
                            Loading dashboard...
                        </p>

                    </div>

                ) : (

                    <>

                        {/* ===================================== */}
                        {/* STAT CARDS */}
                        {/* ===================================== */}

                        <div className="row g-4 mb-4">

                            {statCards.map((card) => (

                                <div
                                    className="col-xl-3 col-md-6"
                                    key={card.title}
                                >

                                    <div
                                        className="card border-0 shadow-sm rounded-4 h-100"
                                        style={{
                                            transition:
                                                "transform 0.2s ease"
                                        }}
                                        onMouseEnter={(e) => {
                                            e.currentTarget.style.transform =
                                                "translateY(-5px)";
                                        }}
                                        onMouseLeave={(e) => {
                                            e.currentTarget.style.transform =
                                                "translateY(0)";
                                        }}
                                    >

                                        <div className="card-body p-4">

                                            <div className="d-flex justify-content-between align-items-start">

                                                <div>

                                                    <p className="text-muted mb-1">
                                                        {card.title}
                                                    </p>

                                                    <h2 className="fw-bold mb-1">
                                                        {card.value?.toLocaleString()}
                                                    </h2>

                                                    <small className="text-muted">
                                                        {card.description}
                                                    </small>

                                                </div>

                                                <div
                                                    className={`bg-${card.color} bg-opacity-10 rounded-4 d-flex align-items-center justify-content-center`}
                                                    style={{
                                                        width: "55px",
                                                        height: "55px",
                                                        fontSize: "25px"
                                                    }}
                                                >
                                                    {card.icon}
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            ))}

                        </div>


                        {/* ===================================== */}
                        {/* APPROVAL OVERVIEW */}
                        {/* ===================================== */}

                        <div className="row g-4 mb-4">

                            <div className="col-lg-8">

                                <div className="card border-0 shadow-sm rounded-4 h-100">

                                    <div className="card-body p-4">

                                        <div className="d-flex justify-content-between align-items-center mb-4">

                                            <div>

                                                <h5 className="fw-bold mb-1">
                                                    🏢 Property Approval Overview
                                                </h5>

                                                <small className="text-muted">
                                                    Current apartment listing status
                                                </small>

                                            </div>

                                            <span className="badge bg-primary rounded-pill px-3 py-2">
                                                {approvalPercentage}% Approved
                                            </span>

                                        </div>


                                        {/* Progress */}

                                        <div className="progress mb-4"
                                            style={{
                                                height: "12px"
                                            }}
                                        >

                                            <div
                                                className="progress-bar bg-success"
                                                style={{
                                                    width: `${approvalPercentage}%`
                                                }}
                                            />

                                        </div>


                                        <div className="row g-3">

                                            <div className="col-md-4">

                                                <div className="p-3 rounded-4 bg-warning bg-opacity-10">

                                                    <div className="d-flex justify-content-between">

                                                        <span>
                                                            ⏳ Pending
                                                        </span>

                                                        <strong className="text-warning">
                                                            {stats.pendingApartments}
                                                        </strong>

                                                    </div>

                                                </div>

                                            </div>


                                            <div className="col-md-4">

                                                <div className="p-3 rounded-4 bg-success bg-opacity-10">

                                                    <div className="d-flex justify-content-between">

                                                        <span>
                                                            ✅ Approved
                                                        </span>

                                                        <strong className="text-success">
                                                            {stats.approvedApartments}
                                                        </strong>

                                                    </div>

                                                </div>

                                            </div>


                                            <div className="col-md-4">

                                                <div className="p-3 rounded-4 bg-danger bg-opacity-10">

                                                    <div className="d-flex justify-content-between">

                                                        <span>
                                                            ❌ Rejected
                                                        </span>

                                                        <strong className="text-danger">
                                                            {stats.rejectedApartments}
                                                        </strong>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>


                            {/* Quick Actions */}

                            <div className="col-lg-4">

                                <div className="card border-0 shadow-sm rounded-4 h-100">

                                    <div className="card-body p-4">

                                        <h5 className="fw-bold mb-1">
                                            ⚡ Quick Actions
                                        </h5>

                                        <p className="text-muted small mb-4">
                                            Frequently used admin tools
                                        </p>


                                        <button
                                            className="btn btn-outline-primary w-100 mb-2 text-start"
                                            onClick={() =>
                                                navigate(
                                                    "/admin/apartments"
                                                )
                                            }
                                        >
                                            🏢 Review Apartments
                                        </button>


                                        <Link
                                            to="/admin/users"
                                            className="btn btn-outline-success w-100 mb-2 text-start"
                                        >
                                            👥 Manage Users
                                        </Link>


                                        <Link
                                            to="/admin/locations"
                                            className="btn btn-outline-info w-100 text-start"
                                        >
                                            📍 Manage Locations
                                        </Link>

                                    </div>

                                </div>

                            </div>

                        </div>


                        {/* ===================================== */}
                        {/* PENDING APARTMENTS */}
                        {/* ===================================== */}

                        <div className="card border-0 shadow-sm rounded-4 mb-4">

                            <div className="card-body p-4">

                                <div className="d-flex justify-content-between align-items-center mb-4">

                                    <div>

                                        <h4 className="fw-bold mb-1">
                                            ⏳ Recent Pending Apartments
                                        </h4>

                                        <p className="text-muted mb-0">
                                            Listings waiting for admin approval
                                        </p>

                                    </div>

                                    <button
                                        className="btn btn-outline-primary rounded-pill px-3"
                                        onClick={() =>
                                            navigate(
                                                "/admin/apartments"
                                            )
                                        }
                                    >
                                        View All →
                                    </button>

                                </div>


                                {pendingApartments.length === 0 ? (

                                    <div className="text-center py-5">

                                        <div
                                            style={{
                                                fontSize: "50px"
                                            }}
                                        >
                                            🎉
                                        </div>

                                        <h5 className="fw-bold mt-3">
                                            All caught up!
                                        </h5>

                                        <p className="text-muted">
                                            There are no pending apartments
                                            waiting for approval.
                                        </p>

                                    </div>

                                ) : (

                                    <div className="row g-3">

                                        {pendingApartments.map(
                                            (apartment) => (

                                                <div
                                                    className="col-lg-6"
                                                    key={apartment.id}
                                                >

                                                    <div
                                                        className="border rounded-4 p-3 h-100"
                                                        style={{
                                                            transition:
                                                                "all 0.2s ease"
                                                        }}
                                                        onMouseEnter={(e) => {
                                                            e.currentTarget.style.transform =
                                                                "translateY(-3px)";
                                                            e.currentTarget.style.boxShadow =
                                                                "0 8px 20px rgba(0,0,0,0.08)";
                                                        }}
                                                        onMouseLeave={(e) => {
                                                            e.currentTarget.style.transform =
                                                                "translateY(0)";
                                                            e.currentTarget.style.boxShadow =
                                                                "none";
                                                        }}
                                                    >

                                                        <div className="d-flex justify-content-between align-items-start">

                                                            <div>

                                                                <span className="badge bg-warning text-dark mb-2">
                                                                    ⏳ Pending
                                                                </span>

                                                                <h5 className="fw-bold mb-1">
                                                                    {apartment.title}
                                                                </h5>

                                                                <div className="text-muted small">
                                                                    🏠 {apartment.propertyType || "Property"}
                                                                </div>

                                                                <div className="text-muted small mt-1">
                                                                    📍 {apartment.locationName || apartment.address || "Location unavailable"}
                                                                </div>

                                                            </div>


                                                            <div className="text-end">

                                                                <h5 className="text-primary fw-bold mb-1">
                                                                    ৳ {apartment.price?.toLocaleString()}
                                                                </h5>

                                                                <small className="text-muted">
                                                                    {apartment.purpose}
                                                                </small>

                                                            </div>

                                                        </div>


                                                        <hr />


                                                        <div className="d-flex justify-content-between align-items-center">

                                                            <div className="small text-muted">

                                                                {apartment.bedrooms != null && (
                                                                    <>
                                                                        🛏 {apartment.bedrooms}
                                                                    </>
                                                                )}

                                                                {"  "}

                                                                {apartment.bathrooms != null && (
                                                                    <>
                                                                        🛁 {apartment.bathrooms}
                                                                    </>
                                                                )}

                                                                {"  "}

                                                                {apartment.sizeSqFt != null && (
                                                                    <>
                                                                        📐 {apartment.sizeSqFt} sqft
                                                                    </>
                                                                )}

                                                            </div>


                                                            <button
                                                                className="btn btn-primary btn-sm rounded-pill px-3"
                                                                onClick={() =>
                                                                    navigate(
                                                                        `/admin/apartments/${apartment.id}`
                                                                    )
                                                                }
                                                            >
                                                                Review →
                                                            </button>

                                                        </div>

                                                    </div>

                                                </div>

                                            )
                                        )}

                                    </div>

                                )}

                            </div>

                        </div>


                        {/* ===================================== */}
                        {/* MANAGEMENT SECTION */}
                        {/* ===================================== */}

                        <div className="mb-3">

                            <h4 className="fw-bold">
                                🛠 Management
                            </h4>

                            <p className="text-muted">
                                Manage the core components of your
                                property platform.
                            </p>

                        </div>


                        <div className="row g-4">

                            {/* Locations */}

                            <div className="col-lg-4">

                                <Link
                                    to="/admin/locations"
                                    className="text-decoration-none text-dark"
                                >

                                    <div
                                        className="card border-0 shadow-sm rounded-4 h-100"
                                        style={{
                                            transition:
                                                "transform 0.2s ease"
                                        }}
                                        onMouseEnter={(e) => {
                                            e.currentTarget.style.transform =
                                                "translateY(-5px)";
                                        }}
                                        onMouseLeave={(e) => {
                                            e.currentTarget.style.transform =
                                                "translateY(0)";
                                        }}
                                    >

                                        <div className="card-body p-4">

                                            <div
                                                className="rounded-4 bg-info bg-opacity-10 d-flex align-items-center justify-content-center mb-3"
                                                style={{
                                                    width: "60px",
                                                    height: "60px",
                                                    fontSize: "28px"
                                                }}
                                            >
                                                📍
                                            </div>

                                            <h5 className="fw-bold">
                                                Manage Locations
                                            </h5>

                                            <p className="text-muted">
                                                Create, edit and delete
                                                property locations.
                                            </p>

                                            <span className="text-primary fw-semibold">
                                                Open Locations →
                                            </span>

                                        </div>

                                    </div>

                                </Link>

                            </div>


                            {/* Users */}

                            <div className="col-lg-4">

                                <Link
                                    to="/admin/users"
                                    className="text-decoration-none text-dark"
                                >

                                    <div
                                        className="card border-0 shadow-sm rounded-4 h-100"
                                        style={{
                                            transition:
                                                "transform 0.2s ease"
                                        }}
                                        onMouseEnter={(e) => {
                                            e.currentTarget.style.transform =
                                                "translateY(-5px)";
                                        }}
                                        onMouseLeave={(e) => {
                                            e.currentTarget.style.transform =
                                                "translateY(0)";
                                        }}
                                    >

                                        <div className="card-body p-4">

                                            <div
                                                className="rounded-4 bg-success bg-opacity-10 d-flex align-items-center justify-content-center mb-3"
                                                style={{
                                                    width: "60px",
                                                    height: "60px",
                                                    fontSize: "28px"
                                                }}
                                            >
                                                👥
                                            </div>

                                            <h5 className="fw-bold">
                                                Manage Users
                                            </h5>

                                            <p className="text-muted">
                                                View, activate, suspend and
                                                manage owners and customers.
                                            </p>

                                            <span className="text-success fw-semibold">
                                                Manage Users →
                                            </span>

                                        </div>

                                    </div>

                                </Link>

                            </div>


                            {/* Apartments */}

                            <div className="col-lg-4">

                                <div
                                    className="card border-0 shadow-sm rounded-4 h-100"
                                    style={{
                                        transition:
                                            "transform 0.2s ease",
                                        cursor: "pointer"
                                    }}
                                    onClick={() =>
                                        navigate(
                                            "/admin/apartments"
                                        )
                                    }
                                    onMouseEnter={(e) => {
                                        e.currentTarget.style.transform =
                                            "translateY(-5px)";
                                    }}
                                    onMouseLeave={(e) => {
                                        e.currentTarget.style.transform =
                                            "translateY(0)";
                                    }}
                                >

                                    <div className="card-body p-4">

                                        <div
                                            className="rounded-4 bg-primary bg-opacity-10 d-flex align-items-center justify-content-center mb-3"
                                            style={{
                                                width: "60px",
                                                height: "60px",
                                                fontSize: "28px"
                                            }}
                                        >
                                            🏢
                                        </div>

                                        <h5 className="fw-bold">
                                            Manage Apartments
                                        </h5>

                                        <p className="text-muted">
                                            Review, approve and reject
                                            apartment listings.
                                        </p>

                                        <span className="text-primary fw-semibold">
                                            Manage Apartments →
                                        </span>

                                    </div>

                                </div>

                            </div>

                        </div>


                        {/* ===================================== */}
                        {/* FOOTER */}
                        {/* ===================================== */}

                        <div className="text-center text-muted mt-5 mb-3">

                            <small>
                                🏡 Property Management System •
                                Admin Control Center
                            </small>

                        </div>

                    </>

                )}

            </div>

        </MainLayout>

    );
}

export default AdminDashboard;