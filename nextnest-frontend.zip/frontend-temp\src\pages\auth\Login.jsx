import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import MainLayout from "../../layouts/MainLayout";
import authService from "../../services/authService";
import { saveToken } from "../../utils/token";
import useAuth from "../../hooks/useAuth";

function Login() {
    const { login } = useAuth();
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        email: "",
        password: ""
    });

    const handleChange = (e) => {

        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        try {

            const response =
                await authService.login(formData);

                localStorage.setItem(
    "token",
    response.accessToken
);

login(
    {
        userId: response.userId,
        fullName: response.fullName,
        email: response.email,
        role: response.role
    },
    response.accessToken
);

            console.log(response);

            saveToken(response.accessToken);

            const role = response.role;

            if(role === "CUSTOMER"){
                toast.success(
    "Login Successful"
);
                navigate("/customer/dashboard");
            }
            else if(role === "OWNER"){
                toast.success(
    "Login Successful"
);
                navigate("/owner/dashboard");
            }
            else if(role === "ADMIN"){
                toast.success(
    "Login Successful"
);
                navigate("/admin/dashboard");
            }

        } catch (error) {

            console.error(error);

          toast.error(
    error?.response?.data?.message ||
    "Invalid email or password"
);
        }
    };

    return (
        <MainLayout>

            <div className="row justify-content-center">

                <div className="col-md-5">

                    <div className="card shadow">

                        <div className="card-body p-4">

                            <h2 className="text-center mb-4">
                                Login
                            </h2>

                            <form onSubmit={handleSubmit}>

                                <div className="mb-3">

                                    <label>Email</label>

                                    <input
                                        type="email"
                                        className="form-control"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="mb-3">

                                    <label>Password</label>

                                    <input
                                        type="password"
                                        className="form-control"
                                        name="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                    />

                                </div>

                                <div className="text-end mb-3">

    <button
        type="button"
        className="btn btn-link p-0"
        onClick={() =>
            navigate("/forgot-password")
        }
    >
        Forgot Password?
    </button>

</div>

                                <button
                                    type="submit"
                                    className="btn btn-primary w-100"
                                >
                                    Login
                                </button>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default Login;