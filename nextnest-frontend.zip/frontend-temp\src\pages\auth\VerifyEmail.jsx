import {
    useState,
    useEffect,
    useRef
} from "react";

import {
    useLocation,
    useNavigate
} from "react-router-dom";

import { toast } from "react-toastify";

import MainLayout from "../../layouts/MainLayout";
import authService from "../../services/authService";

function VerifyEmail() {

    const navigate = useNavigate();

    const location = useLocation();

    const email =
        location.state?.email || "";

    const [otpValues, setOtpValues] =
        useState(
            ["", "", "", "", "", ""]
        );

    const [countdown, setCountdown] =
        useState(120);

    const inputRefs =
        useRef([]);

    useEffect(() => {

        if (!email) {

            navigate("/register");

        }

    }, [email, navigate]);

    useEffect(() => {

        if (countdown <= 0) {
            return;
        }

        const timer =
            setInterval(() => {

                setCountdown(
                    prev => prev - 1
                );

            }, 1000);

        return () =>
            clearInterval(timer);

    }, [countdown]);

    const handleOtpChange = (
        value,
        index
    ) => {

        if (!/^\d*$/.test(value)) {
            return;
        }

        const updatedOtp =
            [...otpValues];

        updatedOtp[index] =
            value;

        setOtpValues(
            updatedOtp
        );

        if (
            value &&
            index < 5
        ) {

            inputRefs.current[
                index + 1
            ]?.focus();
        }
    };

    const handleKeyDown = (
        e,
        index
    ) => {

        if (
            e.key === "Backspace" &&
            !otpValues[index] &&
            index > 0
        ) {

            inputRefs.current[
                index - 1
            ]?.focus();
        }
    };

    const handleVerify = async (e) => {

        e.preventDefault();

        try {

            const otp =
                otpValues.join("");

            await authService.verifyEmail({
                email,
                otp
            });

            toast.success(
                "Email verified successfully"
            );

            navigate("/login");

        } catch (error) {

            toast.error(
                error?.response?.data?.message ||
                "Verification failed"
            );
        }
    };

    const handleResendOtp = async () => {

        try {

            await authService.resendOtp(
                email
            );

            setCountdown(120);

            toast.success(
                "OTP sent successfully"
            );

        } catch (error) {

            toast.error(
                error?.response?.data?.message ||
                "Failed to resend OTP"
            );
        }
    };

    return (

        <MainLayout>

            <div className="row justify-content-center">

                <div className="col-md-5">

                    <div className="card shadow">

                        <div className="card-body p-4">

                            <h2 className="text-center mb-3">
                                Verify Email
                            </h2>

                            <p className="text-center text-muted">

                                Verification code sent to

                                <br />

                                <strong>
                                    {email}
                                </strong>

                            </p>

                            <form
                                onSubmit={handleVerify}
                            >

                                <div
                                    className="
                                    d-flex
                                    justify-content-center
                                    gap-2
                                    mb-4"
                                >

                                    {
                                        otpValues.map(
                                            (
                                                digit,
                                                index
                                            ) => (

                                                <input
                                                    key={index}
                                                    type="text"
                                                    maxLength="1"
                                                    value={digit}
                                                    ref={(el) =>
                                                        inputRefs.current[index] = el
                                                    }
                                                    onChange={(e) =>
                                                        handleOtpChange(
                                                            e.target.value,
                                                            index
                                                        )
                                                    }
                                                    onKeyDown={(e) =>
                                                        handleKeyDown(
                                                            e,
                                                            index
                                                        )
                                                    }
                                                    className="
                                                    form-control
                                                    text-center
                                                    fw-bold"
                                                    style={{
                                                        width: "55px",
                                                        height: "55px",
                                                        fontSize: "22px"
                                                    }}
                                                />

                                            )
                                        )
                                    }

                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-success w-100"
                                >
                                    Verify Email
                                </button>

                            </form>

                            {
                                countdown > 0 ? (

                                    <p
                                        className="
                                        text-center
                                        text-muted
                                        mt-3"
                                    >

                                        Resend OTP in{" "}

                                        {
                                            Math.floor(
                                                countdown / 60
                                            )
                                        }

                                        :

                                        {
                                            String(
                                                countdown % 60
                                            ).padStart(
                                                2,
                                                "0"
                                            )
                                        }

                                    </p>

                                ) : (

                                    <button
                                        className="
                                        btn
                                        btn-link
                                        w-100
                                        mt-3"
                                        onClick={
                                            handleResendOtp
                                        }
                                    >
                                        Resend OTP
                                    </button>

                                )
                            }

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default VerifyEmail;