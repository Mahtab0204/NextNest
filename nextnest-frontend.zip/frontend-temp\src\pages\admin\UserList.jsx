import { useEffect, useState } from "react";
import {useNavigate} from "react-router-dom";
import MainLayout from "../../layouts/MainLayout";
import adminUserService from "../../services/adminUserService";

function UserList() {
    const navigate = useNavigate();

    const [users, setUsers] = useState([]);

    const [loading, setLoading] = useState(true);

    const [search, setSearch] = useState("");

    const [roleFilter, setRoleFilter] = useState("");

    const [statusFilter, setStatusFilter] = useState("");

    // ----------------------------------------
    // Load Users
    // ----------------------------------------

    useEffect(() => {

        loadUsers();

    }, []);

    const loadUsers = async () => {

        try {

            setLoading(true);

            const response =
                await adminUserService.getAllUsers();

            setUsers(response.data);

        } catch (error) {

            console.error("Failed to load users:", error);

        } finally {

            setLoading(false);

        }
    };

    // ----------------------------------------
    // Activate User
    // ----------------------------------------

    const handleActivate = async (id) => {

        try {

            await adminUserService.activateUser(id);

            await loadUsers();

        } catch (error) {

            console.error(error);

            alert(
                error?.response?.data?.message ||
                "Failed to activate user."
            );

        }
    };

    // ----------------------------------------
    // Deactivate User
    // ----------------------------------------

    const handleDeactivate = async (id) => {

        try {

            await adminUserService.deactivateUser(id);

            await loadUsers();

        } catch (error) {

            console.error(error);

            alert(
                error?.response?.data?.message ||
                "Failed to suspend user."
            );

        }
    };

    // ----------------------------------------
    // Delete User
    // ----------------------------------------

    const handleDelete = async (id) => {

        if (
            !window.confirm(
                "Are you sure you want to delete this user?"
            )
        ) {
            return;
        }

        try {

            await adminUserService.deleteUser(id);

            await loadUsers();

        } catch (error) {

            console.error(error);

            alert(
                error?.response?.data?.message ||
                "Failed to delete user."
            );

        }
    };

    // ----------------------------------------
    // Filter Users
    // ----------------------------------------

    const filteredUsers = users.filter((user) => {

        const searchText =
            search.trim().toLowerCase();

        const matchesSearch =
            searchText === "" ||

            user.fullName
                ?.toLowerCase()
                .includes(searchText) ||

            user.email
                ?.toLowerCase()
                .includes(searchText);

        const matchesRole =
            roleFilter === "" ||
            user.role === roleFilter;

        const matchesStatus =
            statusFilter === "" ||
            user.accountStatus === statusFilter;

        return (
            matchesSearch &&
            matchesRole &&
            matchesStatus
        );

    });

    // ----------------------------------------
    // Reset Filters
    // ----------------------------------------

    const resetFilters = () => {

        setSearch("");
        setRoleFilter("");
        setStatusFilter("");

    };

    // ----------------------------------------
    // Role Badge
    // ----------------------------------------

    const getRoleBadge = (role) => {

        switch (role) {

            case "ADMIN":
                return (
                    <span className="badge bg-danger rounded-pill px-3">
                        🛡 Admin
                    </span>
                );

            case "OWNER":
                return (
                    <span className="badge bg-primary rounded-pill px-3">
                        🏠 Owner
                    </span>
                );

            case "CUSTOMER":
                return (
                    <span className="badge bg-info text-dark rounded-pill px-3">
                        👤 Customer
                    </span>
                );

            default:
                return (
                    <span className="badge bg-secondary rounded-pill px-3">
                        {role || "Unknown"}
                    </span>
                );

        }

    };

    // ----------------------------------------
    // Status Badge
    // ----------------------------------------

    const getStatusBadge = (status) => {

        switch (status) {

            case "ACTIVE":
                return (
                    <span className="badge bg-success rounded-pill px-3">
                        ● Active
                    </span>
                );

            case "SUSPENDED":
                return (
                    <span className="badge bg-warning text-dark rounded-pill px-3">
                        ● Suspended
                    </span>
                );

            case "PENDING_VERIFICATION":
                return (
                    <span className="badge bg-secondary rounded-pill px-3">
                        ● Pending
                    </span>
                );

            default:
                return (
                    <span className="badge bg-light text-dark border rounded-pill px-3">
                        {status || "Unknown"}
                    </span>
                );

        }

    };

    // ----------------------------------------
    // Loading
    // ----------------------------------------

    if (loading) {

        return (

            <MainLayout>

                <div
                    className="container py-5 text-center"
                >

                    <div
                        className="spinner-border text-primary"
                        style={{
                            width: "3rem",
                            height: "3rem"
                        }}
                    />

                    <p className="text-muted mt-3">
                        Loading users...
                    </p>

                </div>

            </MainLayout>
        );
    }

    // ----------------------------------------
    // UI
    // ----------------------------------------

    return (

        <MainLayout>

            <div className="container-fluid py-4">

                {/* ================================= */}
                {/* PAGE HEADER */}
                {/* ================================= */}

                <div
                    className="card border-0 shadow-sm rounded-4 mb-4 overflow-hidden"
                >

                    <div className="card-body p-4">

                        <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">

                            <div>

                                <div className="d-flex align-items-center">

                                    <div
                                        className="bg-primary bg-opacity-10 rounded-4 d-flex align-items-center justify-content-center me-3"
                                        style={{
                                            width: "60px",
                                            height: "60px",
                                            fontSize: "28px"
                                        }}
                                    >
                                        👥
                                    </div>

                                    <div>

                                        <h2 className="fw-bold mb-1">
                                            Manage Users
                                        </h2>

                                        <p className="text-muted mb-0">
                                            View and manage all platform users
                                        </p>

                                    </div>

                                </div>

                            </div>

                            <button
                                className="btn btn-outline-primary rounded-pill px-4"
                                onClick={loadUsers}
                            >
                                🔄 Refresh
                            </button>

                        </div>

                    </div>

                </div>


                {/* ================================= */}
                {/* FILTER CARD */}
                {/* ================================= */}

                <div
                    className="card border-0 shadow-sm rounded-4 mb-4"
                >

                    <div className="card-body p-4">

                        <div className="d-flex justify-content-between align-items-center mb-3">

                            <div>

                                <h5 className="fw-bold mb-1">
                                    🔎 Search & Filter
                                </h5>

                                <small className="text-muted">
                                    Find users by name, email, role or status
                                </small>

                            </div>

                            <span className="badge bg-primary rounded-pill px-3 py-2">

                                {filteredUsers.length} users

                            </span>

                        </div>


                        <div className="row g-3">

                            {/* Search */}

                            <div className="col-lg-5">

                                <label className="form-label fw-semibold">
                                    Search
                                </label>

                                <div className="input-group">

                                    <span className="input-group-text bg-white">
                                        🔍
                                    </span>

                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Search by name or email..."
                                        value={search}
                                        onChange={(e) =>
                                            setSearch(
                                                e.target.value
                                            )
                                        }
                                    />

                                </div>

                            </div>


                            {/* Role */}

                            <div className="col-lg-3">

                                <label className="form-label fw-semibold">
                                    Role
                                </label>

                                <select
                                    className="form-select"
                                    value={roleFilter}
                                    onChange={(e) =>
                                        setRoleFilter(
                                            e.target.value
                                        )
                                    }
                                >

                                    <option value="">
                                        All Roles
                                    </option>

                                    <option value="CUSTOMER">
                                        Customer
                                    </option>

                                    <option value="OWNER">
                                        Owner
                                    </option>

                                    <option value="ADMIN">
                                        Admin
                                    </option>

                                </select>

                            </div>


                            {/* Status */}

                            <div className="col-lg-3">

                                <label className="form-label fw-semibold">
                                    Account Status
                                </label>

                                <select
                                    className="form-select"
                                    value={statusFilter}
                                    onChange={(e) =>
                                        setStatusFilter(
                                            e.target.value
                                        )
                                    }
                                >

                                    <option value="">
                                        All Status
                                    </option>

                                    <option value="ACTIVE">
                                        Active
                                    </option>

                                    <option value="SUSPENDED">
                                        Suspended
                                    </option>

                                    <option value="PENDING_VERIFICATION">
                                        Pending Verification
                                    </option>

                                </select>

                            </div>


                            {/* Reset */}

                            <div className="col-lg-1 d-flex align-items-end">

                                <button
                                    className="btn btn-outline-secondary w-100"
                                    onClick={resetFilters}
                                    title="Reset filters"
                                >
                                    ↻
                                </button>

                            </div>

                        </div>

                    </div>

                </div>


                {/* ================================= */}
                {/* USERS TABLE */}
                {/* ================================= */}

                <div
                    className="card border-0 shadow-sm rounded-4"
                >

                    <div className="card-body p-0">

                        <div className="p-4 border-bottom">

                            <div className="d-flex justify-content-between align-items-center">

                                <div>

                                    <h5 className="fw-bold mb-1">
                                        👤 User Accounts
                                    </h5>

                                    <p className="text-muted mb-0">
                                        Showing{" "}
                                        <strong>
                                            {filteredUsers.length}
                                        </strong>{" "}
                                        of{" "}
                                        <strong>
                                            {users.length}
                                        </strong>{" "}
                                        users
                                    </p>

                                </div>

                            </div>

                        </div>


                        <div className="table-responsive">

                            <table className="table table-hover align-middle mb-0">

                                <thead className="table-light">

                                    <tr>

                                        <th className="px-4">
                                            ID
                                        </th>

                                        <th>
                                            User
                                        </th>

                                        <th>
                                            Email
                                        </th>

                                        <th>
                                            Role
                                        </th>

                                        <th>
                                            Status
                                        </th>

                                        <th className="text-end px-4">
                                            Actions
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>

                                    {filteredUsers.length === 0 ? (

                                        <tr>

                                            <td
                                                colSpan="6"
                                                className="text-center py-5"
                                            >

                                                <div
                                                    style={{
                                                        fontSize: "45px"
                                                    }}
                                                >
                                                    🔍
                                                </div>

                                                <h5 className="fw-bold mt-3">
                                                    No users found
                                                </h5>

                                                <p className="text-muted">
                                                    Try changing your
                                                    search or filters.
                                                </p>

                                                <button
                                                    className="btn btn-outline-primary"
                                                    onClick={resetFilters}
                                                >
                                                    Reset Filters
                                                </button>

                                            </td>

                                        </tr>

                                    ) : (

                                        filteredUsers.map(
                                            (user) => (

                                                <tr
                                                    key={user.id}
                                                >

                                                    {/* ID */}

                                                    <td className="px-4">

                                                        <span className="text-muted">
                                                            #{user.id}
                                                        </span>

                                                    </td>


                                                    {/* User */}

                                                    <td>

                                                        <div className="d-flex align-items-center">

                                                            <div
                                                                className="rounded-circle bg-primary bg-opacity-10 d-flex align-items-center justify-content-center me-3"
                                                                style={{
                                                                    width: "42px",
                                                                    height: "42px"
                                                                }}
                                                            >
                                                                👤
                                                            </div>

                                                            <div>

                                                                <div className="fw-semibold">
                                                                    {user.fullName || "Unnamed User"}
                                                                </div>

                                                                <small className="text-muted">
                                                                    User ID: {user.id}
                                                                </small>

                                                            </div>

                                                        </div>

                                                    </td>


                                                    {/* Email */}

                                                    <td>

                                                        <span className="text-muted">
                                                            {user.email}
                                                        </span>

                                                    </td>


                                                    {/* Role */}

                                                    <td>

                                                        {getRoleBadge(
                                                            user.role
                                                        )}

                                                    </td>


                                                    {/* Status */}

                                                    <td>

                                                        {getStatusBadge(
                                                            user.accountStatus
                                                        )}

                                                    </td>


                                                    {/* Actions */}

                                                    <td className="text-end px-4">

                                                        <div className="d-flex justify-content-end gap-2 flex-wrap">

                                                           <button
    className="btn btn-info btn-sm me-2"
    onClick={() =>
        navigate(
            `/admin/users/${user.id}`
        )
    }
>
    View
</button>
                                                            <button
                                                                className="btn btn-success btn-sm rounded-pill px-3"
                                                                onClick={() =>
                                                                    handleActivate(
                                                                        user.id
                                                                    )
                                                                }
                                                                disabled={
                                                                    user.accountStatus ===
                                                                    "ACTIVE"
                                                                }
                                                            >
                                                                ✓ Activate
                                                            </button>


                                                            <button
                                                                className="btn btn-warning btn-sm rounded-pill px-3"
                                                                onClick={() =>
                                                                    handleDeactivate(
                                                                        user.id
                                                                    )
                                                                }
                                                                disabled={
                                                                    user.accountStatus ===
                                                                    "SUSPENDED"
                                                                }
                                                            >
                                                                ⏸ Suspend
                                                            </button>


                                                            <button
                                                                className="btn btn-outline-danger btn-sm rounded-pill px-3"
                                                                onClick={() =>
                                                                    handleDelete(
                                                                        user.id
                                                                    )
                                                                }
                                                            >
                                                                🗑 Delete
                                                            </button>

                                                        </div>

                                                    </td>

                                                </tr>

                                            )
                                        )

                                    )}

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>


                {/* ================================= */}
                {/* FOOTER */}
                {/* ================================= */}

                <div className="text-center text-muted mt-4 mb-3">

                    <small>
                        👥 User Management •
                        Property Management System
                    </small>

                </div>

            </div>

        </MainLayout>

    );
}

export default UserList;