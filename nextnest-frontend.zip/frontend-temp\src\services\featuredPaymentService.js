import axiosInstance from "../api/axios";

const getOwnerHistory = (ownerId) => {

    return axiosInstance.get(
        `/featured-payments/owner/${ownerId}`
    );
};

const featuredPaymentService = {
    getOwnerHistory
};

export default featuredPaymentService;