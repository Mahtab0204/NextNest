import { Link } from "react-router-dom";
import MainLayout from "../../layouts/MainLayout";

function BrowseApartmentsPage() {

    return (

        <MainLayout>

            <div className="container py-5">

                <h2 className="fw-bold mb-4">
                    Browse Apartments
                </h2>

                <div className="row g-4">

                    <div className="col-md-6">

                        <div className="card shadow h-100">

                            <div className="card-body">

                                <h4>
                                    Apartments For Rent
                                </h4>

                                <p>
                                    Find rental apartments
                                    across Dhaka.
                                </p>

                                <Link
                                    to="/rent"
                                    className="btn btn-primary"
                                >
                                    Browse Rent
                                </Link>

                            </div>

                        </div>

                    </div>

                    <div className="col-md-6">

                        <div className="card shadow h-100">

                            <div className="card-body">

                                <h4>
                                    Apartments For Sale
                                </h4>

                                <p>
                                    Find apartments
                                    available for purchase.
                                </p>

                                <Link
                                    to="/buy"
                                    className="btn btn-success"
                                >
                                    Browse Sale
                                </Link>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </MainLayout>
    );
}

export default BrowseApartmentsPage;